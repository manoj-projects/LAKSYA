<#
  Builds a SELF-CONTAINED production deploy: padakku_pattasu_brand
  (base path /padakku_pattasu_brand/, independent of the /padakku_pattasu/ folder)

  Steps: copy needed files -> strip dev backups -> production api/.env ->
         rebase base path & API to /padakku_pattasu_brand/ (rebase_deploy.php) ->
         write README -> zip.
#>
$ErrorActionPreference = 'Stop'
$root  = 'C:\xampp\htdocs\padakku_pattasu'
$php   = 'C:\xampp\php\php.exe'
$dist  = Join-Path $root 'dist'
$stage = Join-Path $dist 'padakku_pattasu_brand'
$zip   = Join-Path $root 'padakku_pattasu_brand.zip'
$log   = Join-Path $root 'tools\deploy_log.txt'

if (Test-Path $dist) { Remove-Item $dist -Recurse -Force }
New-Item -ItemType Directory -Path $stage | Out-Null

$items = @('.htaccess','api','assets','backend','images','media','index.html',
           'robots.txt','sitemap.xml',
           'padakku_pattasu_price_brand_list_2026.pdf',
           'Padakku_Pattasu_budget_Price_2026.pdf')
foreach ($it in $items) {
    $src = Join-Path $root $it
    if (Test-Path $src) { Copy-Item $src -Destination $stage -Recurse -Force }
}

# Strip dev backups.
Get-ChildItem (Join-Path $stage 'assets') -Include *.bak,*.apibak,*.videobak -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force

# Production env.
$apiStage = Join-Path $stage 'api'
Copy-Item (Join-Path $apiStage '.env.production') (Join-Path $apiStage '.env') -Force

# Rebase base path + API to /padakku_pattasu_brand/.
& $php (Join-Path $root 'tools\rebase_deploy.php') | Out-File $log -Encoding ascii

# Deploy instructions.
$readme = @"
PADAKKU PATTASU - BRAND SITE (SELF-CONTAINED)
=============================================

This build is self-contained at base path /padakku_pattasu_brand/.
It does NOT depend on the /padakku_pattasu/ folder.

Upload the CONTENTS of this folder into the server directory served at
https://www.webwala.co.in/padakku_pattasu_brand/

Checklist
---------
1. Upload all files/folders here, preserving structure.
2. api/.env holds PRODUCTION settings (DB wwwwebwa_padakku_brand,
   CORS for webwala.co.in). Confirm they match the live server.
3. First-time DB setup only: visit
   https://www.webwala.co.in/padakku_pattasu_brand/api/setup.php  (once).
4. SECURITY: change the admin password after first sign-in (phone 9994033148).
5. Frontend calls the API at:
   https://www.webwala.co.in/padakku_pattasu_brand/api/v1

Not included: dev backups, tools/, local dev server file, SQL dumps,
and the local price-list JSON.
"@
[IO.File]::WriteAllText((Join-Path $stage 'DEPLOY_README.txt'), $readme)

# Zip.
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path $stage -DestinationPath $zip -Force

Add-Content $log "zip=$zip exists=$(Test-Path $zip) size=$((Get-Item $zip).Length)"
