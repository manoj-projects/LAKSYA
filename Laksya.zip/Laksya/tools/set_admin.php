<?php
// One-shot: set the admin login to phone 7200267817 / password password@123.
require_once __DIR__ . '/../api/config.php';
require_once __DIR__ . '/../api/db.php';

$phone = '7200267817';
$plain = 'password@123';
$hash  = password_hash($plain, PASSWORD_BCRYPT);

$pdo = getDB();

// Update the existing bootstrap admin (code = ADMIN) in place.
// Role is left untouched so an existing 'root' account keeps its privileges.
$stmt = $pdo->prepare(
    "UPDATE agents
        SET phone = ?, password_hash = ?, password_plain = ?,
            is_active = 1, deleted_at = NULL
      WHERE code = 'ADMIN'"
);
$stmt->execute([$phone, $hash, $plain]);
$rows = $stmt->rowCount();

// If there was no ADMIN row for some reason, create one.
if ($rows === 0) {
    $exists = (int) $pdo->query("SELECT COUNT(*) FROM agents WHERE code = 'ADMIN'")->fetchColumn();
    if ($exists === 0) {
        $ins = $pdo->prepare(
            "INSERT INTO agents (code, name, phone, role, password_hash, password_plain, commission_pct, notes)
             VALUES ('ADMIN', 'Admin', ?, 'admin', ?, ?, 0, 'Admin account')"
        );
        $ins->execute([$phone, $hash, $plain]);
        echo "Created ADMIN row.\n";
    }
}

// Verify.
$row = $pdo->query(
    "SELECT id, code, name, phone, role, is_active, deleted_at, LEFT(password_hash,7) AS hp
       FROM agents WHERE phone = '$phone'"
)->fetch(PDO::FETCH_ASSOC);
echo 'rows_updated=' . $rows . "\n";
echo 'verify=' . json_encode($row) . "\n";
echo 'password_verify=' . (password_verify($plain, $pdo->query("SELECT password_hash FROM agents WHERE phone='$phone'")->fetchColumn()) ? 'OK' : 'FAIL') . "\n";
