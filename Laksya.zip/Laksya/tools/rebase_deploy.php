<?php
/**
 * Rebases the STAGED deploy copy from base path /padakku_pattasu/ to
 * /padakku_pattasu_brand/ so the brand site is fully self-contained
 * (its own assets, router base, image base, API, .htaccess, SEO URLs).
 *
 * Operates only on dist/padakku_pattasu_brand (never the working copy).
 */
declare(strict_types=1);

$stage = 'C:/xampp/htdocs/padakku_pattasu/dist/padakku_pattasu_brand';
$oldSlug = 'padakku_pattasu';
$newSlug = 'padakku_pattasu_brand';
$apiProd = "https://www.webwala.co.in/$newSlug/api/v1";

$report = [];
$edit = function (string $path, array $pairs) use (&$report) {
    if (!is_file($path)) { $report[] = "MISSING $path"; return; }
    $c = (string) file_get_contents($path);
    $before = $c;
    foreach ($pairs as $from => $to) {
        $n = substr_count($c, $from);
        if ($n > 0) { $c = str_replace($from, $to, $c); $report[] = basename($path) . " : [$n] " . substr($from, 0, 48); }
    }
    if ($c !== $before) { file_put_contents($path, $c); }
};

// --- All JS chunks: API url + image base + PDF labels, THEN catch-all base ---
// Order matters: rewrite the localhost API (which contains /padakku_pattasu/)
// to the brand host FIRST, then do the generic /padakku_pattasu/ sweep so the
// host part is not left as localhost.
foreach (glob($stage . '/assets/*.js') as $js) {
    $edit($js, [
        // local dev API -> production brand API
        'http://localhost/padakku_pattasu/api/v1' => $apiProd,
        // image / OG base (Pe) — anchored by trailing quote (no /api after)
        'https://www.webwala.co.in/padakku_pattasu"' => 'https://www.webwala.co.in/padakku_pattasu_brand"',
        // PDF footer brand-URL labels (backtick- and quote-terminated)
        'webwala.co.in/padakku_pattasu`'  => 'webwala.co.in/padakku_pattasu_brand`',
        '"webwala.co.in/padakku_pattasu"' => '"webwala.co.in/padakku_pattasu_brand"',
        // catch-all base path: asset base (kt), router basename, admin
        // placeholder/help text, and any other absolute app-path reference.
        '/padakku_pattasu/' => '/padakku_pattasu_brand/',
    ]);
}

// --- index.html: script/modulepreload/stylesheet asset paths + OG urls ---
$edit($stage . '/index.html', [
    '/padakku_pattasu/' => '/padakku_pattasu_brand/',
]);

// --- root .htaccess: RewriteBase ---
$edit($stage . '/.htaccess', [
    'RewriteBase /padakku_pattasu/' => 'RewriteBase /padakku_pattasu_brand/',
]);

// --- SEO: sitemap + robots ---
$edit($stage . '/sitemap.xml', [ '/padakku_pattasu/' => '/padakku_pattasu_brand/' ]);
$edit($stage . '/robots.txt',  [ '/padakku_pattasu/' => '/padakku_pattasu_brand/' ]);

// ---- guard report ----
$idx = (string) file_get_contents($stage . '/assets/index-C42RHa5R.js');
$html = (string) file_get_contents($stage . '/index.html');
$report[] = '---';
$report[] = 'idx_old_base=' . substr_count($idx, '"/padakku_pattasu/"');
$report[] = 'idx_brand_base=' . substr_count($idx, '"/padakku_pattasu_brand/"');
$report[] = 'idx_localhost=' . substr_count($idx, 'localhost/padakku_pattasu');
$report[] = 'idx_api_brand=' . substr_count($idx, "$newSlug/api/v1");
$report[] = 'idx_Pe_brand=' . substr_count($idx, 'www.webwala.co.in/padakku_pattasu_brand"');
$report[] = 'html_old_assets=' . substr_count($html, '/padakku_pattasu/assets/');
$report[] = 'html_brand_assets=' . substr_count($html, '/padakku_pattasu_brand/assets/');

echo implode("\n", $report) . "\n";
