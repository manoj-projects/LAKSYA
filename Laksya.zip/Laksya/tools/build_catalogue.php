<?php
/**
 * Builds the frontend catalogue array literal (`bt=[...]`) from
 * padakku_pattasu_price_list_2026.json, and replaces the existing `bt=[...]`
 * in assets/index-C42RHa5R.js.
 *
 * Format per category:
 *   ["slug","Name","blurb",active,[["code","name","unit",mrp,price],...]]
 *
 * The special categories combo-pack and gift-boxes are NOT in the price list
 * JSON but are used by other homepage sections, so they are preserved verbatim
 * from the current bundle and appended at the end.
 *
 * Run:  C:\xampp\php\php.exe tools\build_catalogue.php
 */

declare(strict_types=1);

$ROOT = dirname(__DIR__);
$JSON = $ROOT . '/padakku_pattasu_price_list_2026.json';
$BUNDLE = $ROOT . '/assets/index-C42RHa5R.js';

$data = json_decode((string) file_get_contents($JSON), true);
if (!is_array($data) || empty($data['categories'])) {
    fwrite(STDERR, "Invalid price list JSON\n");
    exit(1);
}

/* slugify a category name to a stable kebab-case slug */
function slugify(string $s): string {
    $s = strtolower($s);
    $s = str_replace(['&', "'", '(', ')', '/', '.', ','], [' and ', '', '', '', ' ', '', ''], $s);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim((string) $s, '-');
}

/* JS string literal (single-quoted, minimal escaping) */
function js(string $s): string {
    // keep unicode chars like ½, ", ' — JSON/JS handles them; escape backslash + quote
    return "'" . str_replace(['\\', "'"], ['\\\\', "\\'"], $s) . "'";
}

/* JS number: integer if whole, else decimal (no trailing zeros) */
function jn($n): string {
    $n = (float) $n;
    if (abs($n - round($n)) < 0.0001) {
        return (string) (int) round($n);
    }
    return rtrim(rtrim(sprintf('%.4f', $n), '0'), '.');
}

$cats = [];
foreach ($data['categories'] as $i => $cat) {
    $name = (string) ($cat['category'] ?? '');
    if ($name === '') { continue; }
    $slug = slugify($name);
    $blurb = ''; // price list JSON has no blurb; leave empty
    $active = true;
    $prods = [];
    foreach (($cat['products'] ?? []) as $p) {
        $code = (string) ($p['sl_no'] ?? '');
        $pname = (string) ($p['name'] ?? '');
        $unit = (string) ($p['per'] ?? '');
        $mrp = $p['mrp'] ?? 0;
        $price = $p['discount_price'] ?? 0;
        $prods[] = '[' . js($code) . ',' . js($pname) . ',' . js($unit) . ',' . jn($mrp) . ',' . jn($price) . ']';
    }
    $cats[] = '[' . js($slug) . ',' . js($name) . ',' . js($blurb) . ',' . ($active ? '!0' : '!1') . ',[' . implode(',', $prods) . ']]';
}

/* ---- preserve combo-pack & gift-boxes from the current bundle ---- */
$bundle = (string) file_get_contents($BUNDLE);
$start = strpos($bundle, 'bt=[');
if ($start === false) { fwrite(STDERR, "bt=[ not found\n"); exit(1); }
// find matching close bracket
$i = $start + 3; $depth = 0; $end = -1; $inStr = false; $q = '';
for ($n = strlen($bundle); $i < $n; $i++) {
    $ch = $bundle[$i];
    if ($inStr) { if ($ch === '\\') { $i++; continue; } if ($ch === $q) { $inStr = false; } continue; }
    if ($ch === '"' || $ch === "'" || $ch === '`') { $inStr = true; $q = $ch; continue; }
    if ($ch === '[') { $depth++; } elseif ($ch === ']') { $depth--; if ($depth === 0) { $end = $i; break; } }
}
if ($end === -1) { fwrite(STDERR, "could not match bt array\n"); exit(1); }
$oldLiteral = substr($bundle, $start, $end - $start + 1); // "bt=[...]"
$oldInner = substr($oldLiteral, 4, -1); // inside the outer [ ]

/* Extract the two preserved category tuples by locating their slug markers. */
function extractCategory(string $inner, string $slug): ?string {
    $marker = "[\"$slug\",";
    $pos = strpos($inner, $marker);
    if ($pos === false) {
        $marker = "['$slug',";
        $pos = strpos($inner, $marker);
        if ($pos === false) { return null; }
    }
    // walk brackets from pos
    $depth = 0; $inStr = false; $q = '';
    for ($i = $pos, $n = strlen($inner); $i < $n; $i++) {
        $ch = $inner[$i];
        if ($inStr) { if ($ch === '\\') { $i++; continue; } if ($ch === $q) { $inStr = false; } continue; }
        if ($ch === '"' || $ch === "'" || $ch === '`') { $inStr = true; $q = $ch; continue; }
        if ($ch === '[') { $depth++; } elseif ($ch === ']') { $depth--; if ($depth === 0) { return substr($inner, $pos, $i - $pos + 1); } }
    }
    return null;
}

$preserved = [];
foreach (['combo-pack', 'gift-boxes'] as $slug) {
    $tuple = extractCategory($oldInner, $slug);
    if ($tuple !== null) { $preserved[] = $tuple; }
}

$newInner = implode(',', array_merge($cats, $preserved));
$newLiteral = 'bt=[' . $newInner . ']';

$bundle = substr($bundle, 0, $start) . $newLiteral . substr($bundle, $end + 1);
file_put_contents($BUNDLE, $bundle);

echo 'categories_from_json=' . count($cats) . "\n";
echo 'preserved=' . implode(',', array_map(fn($t) => substr($t, 0, 20), $preserved)) . "\n";
echo 'old_len=' . strlen($oldLiteral) . ' new_len=' . strlen($newLiteral) . "\n";
echo "done\n";
