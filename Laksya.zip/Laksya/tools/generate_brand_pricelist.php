<?php
/**
 * Generates the brand price list PDF from the JSON data, using
 * images/pdf_poster_brand.png as a full-page cover.
 *
 * Output: padakku_pattasu_price_brand_list_2026.pdf at the web root
 * (the "Download Brand Price List" button serves this file).
 *
 * Self-contained: no Composer / external library. A tiny PDF writer is
 * embedded below. The cover image is re-encoded to JPEG with GD so it can
 * be embedded via DCTDecode (no zlib/PNG predictor handling needed).
 *
 * Run:  C:\xampp\php\php.exe tools\generate_brand_pricelist.php
 */

declare(strict_types=1);

/* ------------------------------------------------------------------ paths */
$ROOT      = dirname(__DIR__);
$JSON_PATH = $ROOT . '/padakku_pattasu_price_list_2026.json';
$POSTER    = $ROOT . '/images/pdf_poster_brand.png';
$OUT       = $ROOT . '/padakku_pattasu_price_brand_list_2026.pdf';

/* ------------------------------------------------------------- load data */
if (!is_file($JSON_PATH)) {
    fwrite(STDERR, "Data file not found: $JSON_PATH\n");
    exit(1);
}
$data = json_decode((string) file_get_contents($JSON_PATH), true);
if (!is_array($data) || empty($data['categories'])) {
    fwrite(STDERR, "Invalid or empty JSON data.\n");
    exit(1);
}

/* ============================================================== PDF writer */
/**
 * Minimal PDF generator. A4 portrait, points (1 pt = 1/72 inch).
 * Supports: text (Helvetica + Bold), lines, filled rectangles, and one
 * embedded JPEG per image draw. Coordinates use a top-left origin that the
 * writer flips to PDF's bottom-left space.
 */
final class MiniPDF
{
    public float $w = 595.28;   // A4 width  in pt
    public float $h = 841.89;   // A4 height in pt
    private array $objects = []; // id => raw body string
    private array $pages = [];   // page object ids
    private string $content = '';// current page content stream
    private array $images = [];  // key => [id, w, h]
    private int $next = 1;

    private function obj(string $body): int
    {
        $id = $this->next++;
        $this->objects[$id] = $body;
        return $id;
    }

    public function addPage(): void
    {
        if ($this->content !== '') {
            $this->flushPage();
        }
        $this->content = '';
    }

    private function flushPage(): void
    {
        $stream = $this->content;
        $len = strlen($stream);
        $contentId = $this->obj("<< /Length $len >>\nstream\n$stream\nendstream");
        // Page object references are patched after we know Resources id.
        $this->pages[] = ['content' => $contentId];
    }

    /* --------- drawing helpers (top-left origin, y grows downward) ------- */
    private function y(float $top): float { return $this->h - $top; }

    public function rect(float $x, float $top, float $w, float $h, array $rgb): void
    {
        [$r, $g, $b] = array_map(fn($c) => $c / 255, $rgb);
        $y = $this->y($top + $h);
        $this->content .= sprintf("%.3F %.3F %.3F rg\n%.2F %.2F %.2F %.2F re f\n", $r, $g, $b, $x, $y, $w, $h);
    }

    public function line(float $x1, float $t1, float $x2, float $t2, array $rgb, float $wd = 0.5): void
    {
        [$r, $g, $b] = array_map(fn($c) => $c / 255, $rgb);
        $this->content .= sprintf("%.3F %.3F %.3F RG\n%.2F w\n%.2F %.2F m %.2F %.2F l S\n",
            $r, $g, $b, $wd, $x1, $this->y($t1), $x2, $this->y($t2));
    }

    public function text(float $x, float $top, string $s, float $size, bool $bold = false, array $rgb = [0,0,0]): void
    {
        [$r, $g, $b] = array_map(fn($c) => $c / 255, $rgb);
        $font = $bold ? '/F2' : '/F1';
        // baseline sits ~size*0.8 below the given top
        $y = $this->y($top + $size * 0.80);
        $esc = $this->escape($s);
        $this->content .= sprintf("%.3F %.3F %.3F rg\nBT %s %.2F Tf %.2F %.2F Td (%s) Tj ET\n",
            $r, $g, $b, $font, $size, $x, $y, $esc);
    }

    /** Returns text width in pt for layout (Helvetica metrics approximation). */
    public function textWidth(string $s, float $size): float
    {
        // Average Helvetica advance ~0.52em; good enough for truncation checks.
        return strlen($s) * $size * 0.50;
    }

    private function escape(string $s): string
    {
        // Encode to WinAnsi-ish Latin-1; drop characters outside it to avoid
        // broken glyphs (e.g. the ½ and " curly chars become ASCII fallbacks).
        $s = strtr($s, [
            '½' => '1/2', '¼' => '1/4', '¾' => '3/4',
            '’' => "'", '‘' => "'", '“' => '"', '”' => '"', '–' => '-', '—' => '-',
            '₹' => 'Rs.', '°' => ' deg',
        ]);
        $conv = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE', $s);
        if ($conv !== false) { $s = $conv; }
        return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', '', ''], $s);
    }

    /** Draw a Flate-compressed raw RGB image to fill the whole current page. */
    public function imageFull(string $flateRgb, int $iw, int $ih): void
    {
        $key = 'Im' . (count($this->images) + 1);
        $id = $this->obj(
            "<< /Type /XObject /Subtype /Image /Width $iw /Height $ih "
            . "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode "
            . "/Length " . strlen($flateRgb) . " >>\nstream\n$flateRgb\nendstream"
        );
        $this->images[$key] = $id;
        // Fit (contain) within the page, centered, on a white page.
        $scale = min($this->w / $iw, $this->h / $ih);
        $dw = $iw * $scale; $dh = $ih * $scale;
        $ox = ($this->w - $dw) / 2; $oy = ($this->h - $dh) / 2;
        $this->content .= sprintf("q\n%.2F 0 0 %.2F %.2F %.2F cm\n/%s Do\nQ\n",
            $dw, $dh, $ox, $oy, $key);
    }

    public function output(string $path): void
    {
        if ($this->content !== '') { $this->flushPage(); }

        // Shared font + image resource dictionary.
        $f1 = $this->obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
        $f2 = $this->obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
        $xobjs = '';
        foreach ($this->images as $key => $id) { $xobjs .= "/$key $id 0 R "; }
        $resBody = "<< /Font << /F1 $f1 0 R /F2 $f2 0 R >>";
        if ($xobjs !== '') { $resBody .= " /XObject << $xobjs>>"; }
        $resBody .= " >>";
        $resId = $this->obj($resBody);

        // Pages tree (reserve id first).
        $pagesId = $this->next++;
        $kids = [];
        foreach ($this->pages as $p) {
            $pid = $this->obj(sprintf(
                "<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2F %.2F] /Resources %d 0 R /Contents %d 0 R >>",
                $pagesId, $this->w, $this->h, $resId, $p['content']
            ));
            $kids[] = "$pid 0 R";
        }
        $this->objects[$pagesId] = sprintf(
            "<< /Type /Pages /Count %d /Kids [%s] >>", count($kids), implode(' ', $kids)
        );
        $catId = $this->obj("<< /Type /Catalog /Pages $pagesId 0 R >>");

        // Serialize.
        $out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [];
        for ($i = 1; $i < $this->next; $i++) {
            $offsets[$i] = strlen($out);
            $out .= "$i 0 obj\n{$this->objects[$i]}\nendobj\n";
        }
        $xref = strlen($out);
        $count = $this->next; // objects 0..next-1
        $out .= "xref\n0 $count\n0000000000 65535 f \n";
        for ($i = 1; $i < $this->next; $i++) {
            $out .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $out .= "trailer\n<< /Size $count /Root $catId 0 R >>\nstartxref\n$xref\n%%EOF";

        file_put_contents($path, $out);
    }
}

/* ========================================================= helper: money */
function money($n): string
{
    $n = (float) $n;
    // whole number if no fractional part, else one decimal
    if (abs($n - round($n)) < 0.005) {
        return 'Rs.' . number_format($n, 0);
    }
    return 'Rs.' . number_format($n, 1);
}

/* ========================================= pure-PHP PNG -> raw RGB loader */
/**
 * Decodes an 8-bit truecolor (color type 2) or truecolor+alpha (6) PNG into
 * Flate-compressed raw RGB bytes suitable for a PDF image XObject.
 * Uses only zlib (gzuncompress) + manual PNG unfiltering — no GD required.
 * Returns [flateRgb, width, height] or null if the PNG is unsupported.
 */
function png_to_flate_rgb(string $path): ?array
{
    if (!is_file($path) || !function_exists('gzuncompress')) {
        return null;
    }
    $d = (string) file_get_contents($path);
    if (substr($d, 0, 8) !== "\x89PNG\r\n\x1a\n") {
        return null;
    }
    $w = unpack('N', substr($d, 16, 4))[1];
    $h = unpack('N', substr($d, 20, 4))[1];
    $bitDepth = ord($d[24]);
    $colorType = ord($d[25]);
    if ($bitDepth !== 8 || !in_array($colorType, [2, 6], true)) {
        return null; // only 8-bit RGB / RGBA supported
    }
    $channels = $colorType === 6 ? 4 : 3;

    // Concatenate all IDAT chunk data.
    $idat = '';
    $pos = 8;
    $len = strlen($d);
    while ($pos + 8 <= $len) {
        $clen = unpack('N', substr($d, $pos, 4))[1];
        $type = substr($d, $pos + 4, 4);
        $cdata = substr($d, $pos + 8, $clen);
        if ($type === 'IDAT') {
            $idat .= $cdata;
        } elseif ($type === 'IEND') {
            break;
        }
        $pos += 12 + $clen; // length + type + data + crc
    }
    if ($idat === '') {
        return null;
    }
    $raw = @gzuncompress($idat);
    if ($raw === false) {
        return null;
    }

    // Reverse PNG scanline filters.
    $bpp = $channels;          // bytes per pixel
    $stride = $w * $bpp;       // bytes per scanline (excluding filter byte)
    $out = '';                 // unfiltered image bytes
    $prev = str_repeat("\x00", $stride);
    $rp = 0;
    for ($y = 0; $y < $h; $y++) {
        $filter = ord($raw[$rp]); $rp++;
        $line = substr($raw, $rp, $stride);
        $rp += $stride;
        $cur = $line;
        switch ($filter) {
            case 0: // None
                break;
            case 1: // Sub
                for ($i = $bpp; $i < $stride; $i++) {
                    $cur[$i] = chr((ord($cur[$i]) + ord($cur[$i - $bpp])) & 0xFF);
                }
                break;
            case 2: // Up
                for ($i = 0; $i < $stride; $i++) {
                    $cur[$i] = chr((ord($cur[$i]) + ord($prev[$i])) & 0xFF);
                }
                break;
            case 3: // Average
                for ($i = 0; $i < $stride; $i++) {
                    $a = $i >= $bpp ? ord($cur[$i - $bpp]) : 0;
                    $b = ord($prev[$i]);
                    $cur[$i] = chr((ord($cur[$i]) + (($a + $b) >> 1)) & 0xFF);
                }
                break;
            case 4: // Paeth
                for ($i = 0; $i < $stride; $i++) {
                    $a = $i >= $bpp ? ord($cur[$i - $bpp]) : 0;
                    $b = ord($prev[$i]);
                    $c = $i >= $bpp ? ord($prev[$i - $bpp]) : 0;
                    $p = $a + $b - $c;
                    $pa = abs($p - $a); $pb = abs($p - $b); $pc = abs($p - $c);
                    if ($pa <= $pb && $pa <= $pc) { $pr = $a; }
                    elseif ($pb <= $pc) { $pr = $b; }
                    else { $pr = $c; }
                    $cur[$i] = chr((ord($cur[$i]) + $pr) & 0xFF);
                }
                break;
            default:
                return null; // unknown filter
        }
        $out .= $cur;
        $prev = $cur;
    }

    // Drop alpha channel (flatten onto white) if present, producing pure RGB.
    if ($channels === 4) {
        $rgb = '';
        $n = $w * $h;
        for ($i = 0, $o = 0; $i < $n; $i++, $o += 4) {
            $a = ord($out[$o + 3]);
            if ($a === 255) {
                $rgb .= $out[$o] . $out[$o + 1] . $out[$o + 2];
            } else {
                // alpha blend over white
                $r = (ord($out[$o]) * $a + 255 * (255 - $a)) / 255;
                $g = (ord($out[$o + 1]) * $a + 255 * (255 - $a)) / 255;
                $b = (ord($out[$o + 2]) * $a + 255 * (255 - $a)) / 255;
                $rgb .= chr((int) round($r)) . chr((int) round($g)) . chr((int) round($b));
            }
        }
        $out = $rgb;
    }

    return [gzcompress($out, 6), $w, $h];
}

/* ================================================================ render */
$pdf = new MiniPDF();

/* ---- Cover page: full poster image (pure-PHP PNG decode, no GD) ---- */
$coverDrawn = false;
$cover = png_to_flate_rgb($POSTER);
if ($cover !== null) {
    [$flate, $iw, $ih] = $cover;
    $pdf->addPage();
    $pdf->rect(0, 0, $pdf->w, $pdf->h, [255, 255, 255]);
    $pdf->imageFull($flate, $iw, $ih);
    $coverDrawn = true;
}
if (!$coverDrawn) {
    // Fallback cover without image.
    $pdf->addPage();
    $pdf->rect(0, 0, $pdf->w, $pdf->h, [11, 2, 8]);
    $pdf->text(60, 300, (string) ($data['brand'] ?? 'Padakku Pattasu'), 40, true, [255, 193, 7]);
    $pdf->text(60, 360, (string) ($data['title'] ?? ''), 16, false, [255, 255, 255]);
    $pdf->text(60, 390, (string) ($data['season'] ?? ''), 14, false, [255, 213, 79]);
}

/* ======================================================= GOLDEN RICH THEME */
$ML = 40; $MR = 40; $MT = 70; $MB = 52;
$pageW = $pdf->w; $pageH = $pdf->h;
$contentBottom = $pageH - $MB;

// Column x positions (SL, Name, Per, MRP, Offer).
$cSL   = $ML + 10;
$cName = $ML + 42;
$cPer  = $pageW - $MR - 200;
$cMRP  = $pageW - $MR - 118;
$cOff  = $pageW - $MR - 58;

// Palette — deep charcoal + layered golds for a rich, premium look.
$INK      = [18, 14, 10];     // near-black page background
$INK2     = [30, 24, 16];     // panel background
$GOLD      = [214, 170, 78];  // primary gold
$GOLD_HI   = [245, 221, 150]; // bright highlight gold
$GOLD_DEEP = [168, 123, 44];  // deep antique gold
$CREAM     = [250, 246, 236]; // row text / light panel
$CREAM_DIM = [206, 198, 180];
$ROW_A     = [38, 31, 21];    // zebra row dark
$ROW_B     = [46, 38, 26];    // zebra row darker
$GREEN     = [120, 190, 120]; // offer price (soft gold-green glow)
$MUTED     = [150, 140, 120];

$brand   = (string) ($data['brand'] ?? 'Padakku Pattasu');
$title   = (string) ($data['title'] ?? '');
$season  = (string) ($data['season'] ?? '');
$discount= (int) ($data['discount_percent'] ?? 0);
$wa      = (string) ($data['contact_whatsapp'] ?? '');
$totProd = (int) ($data['total_products'] ?? 0);
$totCat  = (int) ($data['total_categories'] ?? count($data['categories']));

$cursorY = 0.0;
$pageNo  = 0;

/* Fake a gold "gradient" bar by stacking thin rects from deep to highlight. */
$goldBar = function (float $x, float $top, float $w, float $h) use ($pdf, $GOLD_DEEP, $GOLD, $GOLD_HI) {
    $steps = 8;
    for ($i = 0; $i < $steps; $i++) {
        $t = $i / ($steps - 1);
        // interpolate GOLD_DEEP -> GOLD -> GOLD_HI
        if ($t < 0.5) { $a = $GOLD_DEEP; $b = $GOLD; $k = $t / 0.5; }
        else { $a = $GOLD; $b = $GOLD_HI; $k = ($t - 0.5) / 0.5; }
        $r = $a[0] + ($b[0] - $a[0]) * $k;
        $g = $a[1] + ($b[1] - $a[1]) * $k;
        $bl = $a[2] + ($b[2] - $a[2]) * $k;
        $pdf->rect($x, $top + $h * $t, $w, $h / $steps + 0.6, [(int)$r, (int)$g, (int)$bl]);
    }
};

$startListPage = function () use (
    $pdf, &$cursorY, &$pageNo, $ML, $MR, $MT, $pageW, $pageH, $brand, $season,
    $discount, $INK, $INK2, $GOLD, $GOLD_HI, $GOLD_DEEP, $CREAM, $CREAM_DIM, $goldBar
) {
    $pdf->addPage();
    $pageNo++;

    // Full charcoal background.
    $pdf->rect(0, 0, $pageW, $pageH, $INK);

    // Decorative double gold frame.
    $fx = 20; $fy = 20; $fw = $pageW - 40; $fh = $pageH - 40;
    $pdf->line($fx, $fy, $fx + $fw, $fy, $GOLD_DEEP, 1.4);
    $pdf->line($fx, $fy + $fh, $fx + $fw, $fy + $fh, $GOLD_DEEP, 1.4);
    $pdf->line($fx, $fy, $fx, $fy + $fh, $GOLD_DEEP, 1.4);
    $pdf->line($fx + $fw, $fy, $fx + $fw, $fy + $fh, $GOLD_DEEP, 1.4);
    $pdf->line($fx + 3, $fy + 3, $fx + $fw - 3, $fy + 3, $GOLD, 0.5);
    $pdf->line($fx + 3, $fy + $fh - 3, $fx + $fw - 3, $fy + $fh - 3, $GOLD, 0.5);
    $pdf->line($fx + 3, $fy + 3, $fx + 3, $fy + $fh - 3, $GOLD, 0.5);
    $pdf->line($fx + $fw - 3, $fy + 3, $fx + $fw - 3, $fy + $fh - 3, $GOLD, 0.5);

    // Header: brand on a thin gold rule.
    $pdf->text($ML, 34, strtoupper($brand), 13, true, $GOLD_HI);
    $right = $season . ($discount ? "   |   FLAT {$discount}% OFF" : '');
    $pdf->text($pageW - $MR - $pdf->textWidth($right, 9), 36, $right, 9, false, $CREAM_DIM);
    $goldBar($ML, 50, $pageW - $ML - $MR, 2.2);

    $cursorY = $MT;
};

$drawColHeader = function () use (
    $pdf, &$cursorY, $ML, $MR, $pageW, $cSL, $cName, $cPer, $cMRP, $cOff,
    $INK2, $GOLD_HI, $GOLD_DEEP
) {
    $x = $ML; $w = $pageW - $ML - $MR; $h = 17;
    $pdf->rect($x, $cursorY, $w, $h, $INK2);
    $pdf->line($x, $cursorY + $h, $x + $w, $cursorY + $h, $GOLD_DEEP, 0.8);
    $c = $GOLD_HI;
    $pdf->text($cSL, $cursorY + 5, '#', 8, true, $c);
    $pdf->text($cName, $cursorY + 5, 'PRODUCT', 8, true, $c);
    $pdf->text($cPer, $cursorY + 5, 'PER', 8, true, $c);
    $pdf->text($cMRP, $cursorY + 5, 'MRP', 8, true, $c);
    $pdf->text($cOff, $cursorY + 5, 'OFFER', 8, true, $c);
    $cursorY += $h + 3;
};

$footer = function () use ($pdf, &$pageNo, $ML, $MR, $pageW, $pageH, $MB, $wa, $MUTED, $GOLD_DEEP, $GOLD_HI, $goldBar) {
    $fy = $pageH - $MB + 16;
    $goldBar($ML, $fy - 8, $pageW - $ML - $MR, 1.6);
    $left = $wa ? ('WhatsApp / Call  ' . $wa) : '';
    $pdf->text($ML, $fy, $left, 8.5, true, $GOLD_HI);
    $mid = 'Prices inclusive of flat discount - while stocks last';
    $pdf->text(($pageW - $pdf->textWidth($mid, 7.5)) / 2, $fy + 0.5, $mid, 7.5, false, $MUTED);
    $pg = 'Page ' . $pageNo;
    $pdf->text($pageW - $MR - $pdf->textWidth($pg, 8), $fy, $pg, 8, false, $MUTED);
};

/* ---- Intro / title block on first list page ---- */
$startListPage();
$pdf->text($ML, $cursorY, $title !== '' ? $title : 'Price List', 16, true, $GOLD_HI);
$cursorY += 24;
$sub = trim(sprintf('%d products  -  %d categories', $totProd, $totCat));
$pdf->text($ML, $cursorY, $sub, 10, false, $CREAM_DIM);

// Golden "FLAT 80% OFF" badge on the right of the intro.
if ($discount) {
    $bw = 150; $bx = $pageW - $MR - $bw; $by = $cursorY - 16; $bh = 30;
    $goldBar($bx, $by, $bw, $bh);
    $pdf->rect($bx + 1.5, $by + 1.5, $bw - 3, $bh - 3, $INK);
    $badge = "FLAT {$discount}% OFF";
    $pdf->text($bx + ($bw - $pdf->textWidth($badge, 13)) / 2, $by + 9, $badge, 13, true, $GOLD_HI);
}
$cursorY += 22;
$drawColHeader();

$rowH = 15.5;

foreach ($data['categories'] as $cat) {
    $catName = strtoupper((string) ($cat['category'] ?? ''));
    $products = $cat['products'] ?? [];
    if (!is_array($products) || !$products) { continue; }

    if ($cursorY + 24 + $rowH > $contentBottom) {
        $footer();
        $startListPage();
        $drawColHeader();
    }

    // Category band — dark panel with gold left tab + gold label.
    $x = $ML; $w = $pageW - $ML - $MR; $h = 20;
    $pdf->rect($x, $cursorY, $w, $h, $INK2);
    $goldBar($x, $cursorY, 4, $h); // gold accent tab
    $pdf->line($x, $cursorY + $h, $x + $w, $cursorY + $h, $GOLD_DEEP, 0.6);
    $label = ($cat['category_no'] ?? '') !== '' ? ($cat['category_no'] . '.   ' . $catName) : $catName;
    $pdf->text($cSL, $cursorY + 6, $label, 10.5, true, $GOLD_HI);
    $cnt = count($products);
    $cntTxt = $cnt . ' item' . ($cnt === 1 ? '' : 's');
    $pdf->text($pageW - $MR - $pdf->textWidth($cntTxt, 8.5), $cursorY + 6.5, $cntTxt, 8.5, false, $CREAM_DIM);
    $cursorY += $h + 3;

    $zebra = false;
    foreach ($products as $p) {
        if ($cursorY + $rowH > $contentBottom) {
            $footer();
            $startListPage();
            $drawColHeader();
            $pdf->text($cSL, $cursorY, $catName . ' (contd.)', 9, true, $GOLD);
            $cursorY += 15;
        }

        // Zebra rows in two dark tones for a rich table feel.
        $pdf->rect($ML, $cursorY - 1, $pageW - $ML - $MR, $rowH, $zebra ? $ROW_B : $ROW_A);
        $zebra = !$zebra;

        $sl   = (string) ($p['sl_no'] ?? '');
        $name = (string) ($p['name'] ?? '');
        $per  = (string) ($p['per'] ?? '');
        $mrp  = money($p['mrp'] ?? 0);
        $off  = money($p['discount_price'] ?? 0);

        $maxNameW = $cPer - $cName - 6;
        while ($name !== '' && $pdf->textWidth($name, 9) > $maxNameW) {
            $name = substr($name, 0, -1);
        }

        $pdf->text($cSL,   $cursorY + 2.5, $sl,  8.5, false, $MUTED);
        $pdf->text($cName, $cursorY + 2.5, $name, 9, false, $CREAM);
        $pdf->text($cPer,  $cursorY + 2.5, $per, 8, false, $CREAM_DIM);
        // MRP struck through (muted).
        $pdf->text($cMRP,  $cursorY + 2.5, $mrp, 8.5, false, $MUTED);
        $mw = $pdf->textWidth($mrp, 8.5);
        $pdf->line($cMRP, $cursorY + 7.5, $cMRP + $mw, $cursorY + 7.5, $MUTED, 0.6);
        // Offer price — bold bright gold.
        $pdf->text($cOff,  $cursorY + 2.5, $off, 9.5, true, $GOLD_HI);

        $cursorY += $rowH;
    }

    // Thin gold separator after each category.
    $pdf->line($ML, $cursorY + 2, $pageW - $MR, $cursorY + 2, $GOLD_DEEP, 0.4);
    $cursorY += 9;
}

$footer();

$pdf->output($OUT);

$size = is_file($OUT) ? filesize($OUT) : 0;
echo "OK wrote " . basename($OUT) . " ({$size} bytes), cover=" . ($coverDrawn ? 'image' : 'fallback') . "\n";
