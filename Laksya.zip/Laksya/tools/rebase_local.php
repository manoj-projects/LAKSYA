<?php
/**
 * Rebases THIS working copy (C:/xampp/htdocs/Laksya) in place from the baked-in
 * base path /padakku_pattasu/ to /Laksya/, and points the frontend API at the
 * local XAMPP API for this folder. This lets the copy run self-contained at
 * http://localhost/Laksya/ without colliding with the /padakku_pattasu/ folder.
 *
 * Every file touched is backed up once to <file>.lakbak before the first edit,
 * so the rebase is reversible.
 *
 * Run: C:\xampp\php\php.exe tools\rebase_local.php
 */
declare(strict_types=1);

$root   = 'C:/xampp/htdocs/Laksya';
$apiNew = 'http://localhost/Laksya/api/v1';

$report = [];
$edit = function (string $path, array $pairs) use (&$report): void {
    if (!is_file($path)) { $report[] = "MISSING $path"; return; }
    $c = (string) file_get_contents($path);
    $before = $c;
    foreach ($pairs as $from => $to) {
        $n = substr_count($c, $from);
        if ($n > 0) {
            $c = str_replace($from, $to, $c);
            $report[] = basename($path) . " : [$n] " . substr($from, 0, 52);
        }
    }
    if ($c !== $before) {
        $bak = $path . '.lakbak';
        if (!is_file($bak)) { copy($path, $bak); }
        file_put_contents($path, $c);
    }
};

// --- All JS chunks: local API first, THEN the catch-all base-path sweep ---
// Order matters: rewrite the localhost API (which itself contains
// /padakku_pattasu/) before the generic sweep so the host part stays intact.
foreach (glob($root . '/assets/*.js') as $js) {
    $edit($js, [
        // local dev API -> this folder's local API
        'http://localhost/padakku_pattasu/api/v1' => $apiNew,
        // production API (if any chunk still has it) -> local API too
        'https://www.webwala.co.in/padakku_pattasu/api/v1' => $apiNew,
        // image / OG base (quote-terminated, no /api after)
        'https://www.webwala.co.in/padakku_pattasu"' => 'https://www.webwala.co.in/Laksya"',
        // PDF footer brand-URL labels (backtick- and quote-terminated)
        'webwala.co.in/padakku_pattasu`'  => 'webwala.co.in/Laksya`',
        '"webwala.co.in/padakku_pattasu"' => '"webwala.co.in/Laksya"',
        // catch-all base path: asset base, router basename, admin placeholder
        // text, and any other absolute app-path reference.
        '/padakku_pattasu/' => '/Laksya/',
    ]);
}

// --- index.html: script/modulepreload/stylesheet asset paths + OG urls ---
$edit($root . '/index.html', [
    '/padakku_pattasu/' => '/Laksya/',
]);

// --- root .htaccess: RewriteBase ---
$edit($root . '/.htaccess', [
    'RewriteBase /padakku_pattasu/' => 'RewriteBase /Laksya/',
]);

// --- SEO: sitemap + robots ---
$edit($root . '/sitemap.xml', ['/padakku_pattasu/' => '/Laksya/']);
$edit($root . '/robots.txt',  ['/padakku_pattasu/' => '/Laksya/']);

// ---- guard report ----
$idx  = (string) file_get_contents($root . '/assets/index-C42RHa5R.js');
$html = (string) file_get_contents($root . '/index.html');
$report[] = '---';
$report[] = 'idx_old_base='   . substr_count($idx, '"/padakku_pattasu/"');
$report[] = 'idx_new_base='   . substr_count($idx, '"/Laksya/"');
$report[] = 'idx_old_api='    . substr_count($idx, 'localhost/padakku_pattasu/api');
$report[] = 'idx_new_api='    . substr_count($idx, 'localhost/Laksya/api');
$report[] = 'html_old_assets='. substr_count($html, '/padakku_pattasu/assets/');
$report[] = 'html_new_assets='. substr_count($html, '/Laksya/assets/');

echo implode("\n", $report) . "\n";
