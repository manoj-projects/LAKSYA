<?php
/**
 * Seeds dummy bills into the LOCAL database so Orders / Confirmed Orders /
 * Receivables / Finance / Dashboard have realistic data to show.
 *
 * Safe to re-run: each run appends a fresh batch of bills (new bill numbers).
 * Run:  C:\xampp\php\php.exe tools\seed_bills.php
 */
declare(strict_types=1);

require_once __DIR__ . '/../api/config.php';
require_once __DIR__ . '/../api/db.php';
require_once __DIR__ . '/../api/lib/numbering.php';

mt_srand(20261004);

// Guard: only run against the local development database.
if (APP_ENVIRONMENT !== 'development') {
    fwrite(STDERR, "Refusing to seed: APP_ENVIRONMENT is not 'development'.\n");
    exit(1);
}

// ---- Pull a pool of active products to build line items from.
$products = fetchAll(
    "SELECT id, product_code, name, unit, mrp, price
     FROM products
     WHERE is_active = 1 AND deleted_at IS NULL AND price > 0
     ORDER BY id LIMIT 120"
);
if (count($products) < 5) {
    fwrite(STDERR, "Not enough products to seed bills (found " . count($products) . ").\n");
    exit(1);
}

// ---- Admin agent (optional) for agent_id.
$adminId = fetchValue("SELECT id FROM agents WHERE role = 'admin' AND deleted_at IS NULL ORDER BY id LIMIT 1");
$adminId = $adminId !== null ? (int) $adminId : null;

// ---- Dummy customers.
$customerSeed = [
    ['Karthik Raja',    '9842011001', 'Chennai',    '600042'],
    ['Priya Sundaram',  '9842011002', 'Madurai',    '625001'],
    ['Manoj Kumar',     '9842011003', 'Coimbatore', '641001'],
    ['Deepa Venkat',    '9842011004', 'Trichy',     '620001'],
    ['Rajesh Mohan',    '9842011005', 'Chennai',    '600028'],
    ['Santhosh P',      '9842011006', 'Sivakasi',   '626189'],
    ['Anitha Lakshmi',  '9842011007', 'Salem',      '636001'],
    ['Vikram J',        '9842011008', 'Bangalore',  '560001'],
];
$customerIds = [];
foreach ($customerSeed as [$name, $phone, $city, $pin]) {
    $customerIds[] = insertId(
        "INSERT INTO customers (phone, name, city, pincode, address, created_at)
         VALUES (?, ?, ?, ?, ?, NOW())",
        [$phone, $name, $city, $pin, "$city, Tamil Nadu"]
    );
}

// ---- Bill plan: status + payment distribution (15 bills).
$plan = [
    ['confirmed', 'paid'],    ['confirmed', 'partial'], ['confirmed', 'unpaid'],
    ['packed',    'paid'],    ['packed',    'partial'], ['packed',    'unpaid'],
    ['dispatched','paid'],    ['dispatched','unpaid'],
    ['delivered', 'paid'],    ['delivered', 'paid'],    ['delivered', 'partial'],
    ['confirmed', 'paid'],    ['delivered', 'paid'],
    ['draft',     'unpaid'],  ['cancelled', 'unpaid'],
];

$made = 0; $createdBills = [];
beginTransaction();
try {
    foreach ($plan as $i => [$status, $payState]) {
        // Build 2–6 random line items.
        $lineCount = mt_rand(2, 6);
        $picked = (array) array_rand($products, min($lineCount, count($products)));
        $subtotal = 0.0; $itemCount = 0; $lines = [];
        foreach ($picked as $pi) {
            $p = $products[$pi];
            $qty = mt_rand(1, 10);
            $price = (float) $p['price'];
            $lineTotal = round($price * $qty, 2);
            $subtotal += $lineTotal;
            $itemCount++;
            $lines[] = [$p, $qty, $price, $lineTotal];
        }
        $packing = mt_rand(0, 1) ? (float) (mt_rand(0, 4) * 50) : 0.0;
        $discountPct = mt_rand(0, 1) ? 0.0 : (float) mt_rand(2, 8);
        $discountAmt = round($subtotal * $discountPct / 100, 2);
        $total = round($subtotal - $discountAmt + $packing, 2);

        $amountPaid = $payState === 'paid' ? $total
            : ($payState === 'partial' ? round($total * 0.4, 2) : 0.0);

        // Spread created_at over the last ~45 days.
        $daysAgo = mt_rand(0, 45);
        $hour = mt_rand(9, 20);
        $createdAt = date('Y-m-d H:i:s', strtotime("-{$daysAgo} days {$hour}:" . mt_rand(10, 59) . ":00"));

        $custId = $customerIds[array_rand($customerIds)];
        $agentId = (mt_rand(0, 1) && $adminId) ? $adminId : null;
        $billNo = next_bill_no();

        $orderId = insertId(
            "INSERT INTO orders
                (bill_no, customer_id, agent_id, status, payment_status,
                 subtotal, discount_pct, discount_amount, packing_charges, total,
                 amount_paid, item_count, delivery_address, delivery_pincode,
                 stock_applied, created_at, updated_at)
             VALUES (?,?,?,?,?, ?,?,?,?,?, ?,?,?,?, ?,?,?)",
            [
                $billNo, $custId, $agentId, $status, $payState,
                $subtotal, $discountPct, $discountAmt, $packing, $total,
                $amountPaid, $itemCount, null, null,
                in_array($status, ['confirmed','packed','dispatched','delivered'], true) ? 1 : 0,
                $createdAt, $createdAt,
            ]
        );

        foreach ($lines as [$p, $qty, $price, $lineTotal]) {
            execute(
                "INSERT INTO order_items
                    (order_id, product_id, product_code, name, unit, mrp, price, qty, line_total)
                 VALUES (?,?,?,?,?,?,?,?,?)",
                [$orderId, (int) $p['id'], $p['product_code'], $p['name'], $p['unit'],
                 (float) $p['mrp'], $price, $qty, $lineTotal]
            );
        }

        // Status history event.
        execute(
            "INSERT INTO order_status_events (order_id, status, note, actor_id, created_at)
             VALUES (?,?,?,?,?)",
            [$orderId, $status, 'Seeded dummy bill', $agentId, $createdAt]
        );

        // Payment row for paid/partial.
        if ($amountPaid > 0) {
            execute(
                "INSERT INTO payments (order_id, amount, mode, reference, note, actor_id, received_at)
                 VALUES (?,?,?,?,?,?,?)",
                [$orderId, $amountPaid, mt_rand(0,1) ? 'cash' : 'upi', null, 'Seeded payment', $agentId, $createdAt]
            );
        }

        $createdBills[] = "$billNo [$status/$payState] total=" . number_format($total, 2);
        $made++;
    }
    commit();
} catch (Throwable $e) {
    rollback();
    fwrite(STDERR, "Seed failed: " . $e->getMessage() . "\n");
    exit(1);
}

echo "Seeded $made dummy bills:\n";
foreach ($createdBills as $b) echo "  $b\n";

// Totals snapshot.
$totOrders = fetchValue("SELECT COUNT(*) FROM orders WHERE deleted_at IS NULL");
$revenue = fetchValue("SELECT COALESCE(SUM(total),0) FROM orders WHERE deleted_at IS NULL AND status IN ('confirmed','packed','dispatched','delivered')");
echo "DB now has $totOrders orders; revenue (confirmed+) = " . number_format((float) $revenue, 2) . "\n";
