<?php
/**
 * Repoints the hardcoded production API base URL to the local XAMPP API.
 * Backs up each file (.apibak) before writing.
 *
 * Run: C:\xampp\php\php.exe tools\repoint_api.php
 */
declare(strict_types=1);

$dir  = 'C:/xampp/htdocs/padakku_pattasu/assets';
$from = 'https://www.webwala.co.in/padakku_pattasu/api/v1';
$to   = 'http://localhost/padakku_pattasu/api/v1';

$total = 0;
foreach (glob($dir . '/*.js') as $f) {
    $src = (string) file_get_contents($f);
    $n = substr_count($src, $from);
    if ($n === 0) { continue; }
    copy($f, $f . '.apibak');
    $src = str_replace($from, $to, $src);
    file_put_contents($f, $src);
    $total += $n;
    echo basename($f) . ": replaced $n\n";
}
echo "total=$total\n";
