/* =====================================================================
   Laksya Crackers — Header + Hero behaviour overrides
   ---------------------------------------------------------------------
   Reversible DOM patcher loaded from index.html. It does NOT touch the
   minified bundle; it reacts to what the bundle renders:

     1. Stamps data-lak-header / data-lak-hero so laksya-theme.css can
        scope its re-skin tightly.
     2. Collapses the two price-list buttons ("Download Brand Price List"
        + "Budget Price List") into ONE "Download Price List" button that
        points at Laksya_Crackers_Price_List_2026.pdf.
     3. Swaps the hero product image to images/about.png.

   Because the storefront is a React SPA that re-renders on navigation, a
   MutationObserver re-applies the patch whenever the DOM changes. All
   operations are idempotent and guarded, so repeated runs are safe.
   ===================================================================== */
(function () {
  "use strict";

  // Base path this deploy is served under (…/Laksya/). Derived from the
  // document URL so it keeps working regardless of host.
  var BASE = (function () {
    var m = window.location.pathname.match(/^(.*\/Laksya\/)/);
    return m ? m[1] : "/Laksya/";
  })();

  var PDF_URL = BASE + "Laksya_Crackers_Price_List_2026.pdf";
  var ABOUT_IMG = BASE + "images/about.png";

  function findHero() {
    // The hero is the first full-height section with the grid layout the
    // bundle uses (lg:grid-cols-[1fr_1.1fr]). Fall back to the first
    // <section> that contains a price-list link.
    var byGrid = document.querySelector(
      'section .grid.lg\\:grid-cols-\\[1fr_1\\.1fr\\]'
    );
    if (byGrid) {
      var sec = byGrid.closest("section");
      if (sec) return sec;
    }
    var links = document.querySelectorAll('a[href*="Price"], a[href*="price"]');
    for (var i = 0; i < links.length; i++) {
      var s = links[i].closest("section");
      if (s) return s;
    }
    return null;
  }

  function patchHeader() {
    var header = document.querySelector("header.sticky") ||
      document.querySelector("header");
    if (header && !header.hasAttribute("data-lak-header")) {
      header.setAttribute("data-lak-header", "");
    }
  }

  function patchHero() {
    var hero = findHero();
    if (!hero) return;
    if (!hero.hasAttribute("data-lak-hero")) {
      hero.setAttribute("data-lak-hero", "");
    }

    // --- Price-list buttons -------------------------------------------
    var anchors = hero.querySelectorAll("a[href]");
    var primary = null;
    anchors.forEach(function (a) {
      var href = a.getAttribute("href") || "";
      var txt = (a.textContent || "").toLowerCase();
      var isPriceList =
        /price.*list|budget|brand/i.test(txt) ||
        /price.*list|budget_|_price_|brand_list/i.test(href);
      if (!isPriceList) return;

      if (!primary) {
        // Keep the first price-list anchor as the single download button.
        primary = a;
        a.setAttribute("data-lak-download", "");
        a.setAttribute("href", PDF_URL);
        a.setAttribute("target", "_blank");
        a.setAttribute("rel", "noopener");
        // Replace label text, preserving a leading icon.
        if (a.textContent.trim() !== "📄 Download Price List") {
          a.textContent = "📄 Download Price List";
        }
      } else {
        // Any further price-list buttons (budget / brand duplicate) go.
        a.style.display = "none";
        a.setAttribute("data-lak-hidden", "");
      }
    });

    // --- Hero image ---------------------------------------------------
    // The right-column product image. Swap its source to about.png once.
    var imgs = hero.querySelectorAll("img");
    imgs.forEach(function (img) {
      if (img.getAttribute("data-lak-img") === "1") return;
      var src = img.getAttribute("src") || "";
      // Target the large hero sticker (width ~520 / sticker_4) only.
      if (/sticker|about/i.test(src) || img.width >= 400) {
        img.setAttribute("src", ABOUT_IMG);
        img.setAttribute("srcset", "");
        img.setAttribute("data-lak-img", "1");
        img.setAttribute("alt", "Laksya Crackers");
      }
    });
  }

  function apply() {
    try {
      patchHeader();
      patchHero();
    } catch (e) {
      /* never let the patch break the page */
    }
  }

  // Initial run + re-run on DOM mutations (SPA re-renders / navigation).
  var scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    window.requestAnimationFrame(function () {
      scheduled = false;
      apply();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", apply);
  } else {
    apply();
  }

  var obs = new MutationObserver(schedule);
  obs.observe(document.documentElement, { childList: true, subtree: true });

  // Also re-apply on history navigation (React Router).
  window.addEventListener("popstate", schedule);
})();
