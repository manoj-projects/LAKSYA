function d(t){if(t==null)return"";const e=String(t);return/[",\n]/.test(e)?`"${e.replace(/"/g,'""')}"`:e}function b(t,e,r){const s=e.map(o=>d(o.header)).join(","),a=r.map(o=>e.map(u=>d(u.value(o))).join(",")).join(`
`),i=new Blob(["\uFEFF"+s+`
`+a],{type:"text/csv;charset=utf-8;"}),c=URL.createObjectURL(i),n=document.createElement("a");n.href=c,n.download=t.endsWith(".csv")?t:`${t}.csv`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(c)}export{b as d};
