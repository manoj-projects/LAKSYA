$files = @(
  'index.html','.htaccess','robots.txt','sitemap.xml',
  'api\config.php','api\routes\finance.php',
  'assets\index-C42RHa5R.js','assets\Catalogue-CNn431tR.js','assets\ComboPacks-XS4RxUBW.js',
  'assets\GiftBoxes-jweM36Cv.js','assets\Contact-l57H9Xu2.js','assets\Gallery-DKrh9SuH.js',
  'assets\PaymentInformation-Co2h3cK9.js','assets\Settlement-DBPQcsZD.js','assets\TrackEstimate-Dc_P3hOF.js',
  'assets\pdf-vendor-kSEqkmOY.js'
)
$lits = @(
  '/padakku_pattasu/',
  'localhost/padakku_pattasu',
  'http://localhost/padakku_pattasu/api/v1',
  'www.webwala.co.in/padakku_pattasu"',
  'www.webwala.co.in/padakku_pattasu`',
  '"webwala.co.in/padakku_pattasu"',
  'webwala.co.in/padakku_pattasu`',
  '/padakku_pattasu/images/',
  'Padakku Pattasu Crackers',
  'Padakku Pattasu',
  'padakkupattasu@gmail.com',
  '"padakkupattasu"',
  '+919994033148',
  '919994033148',
  '99940 33148',
  '9994033148'
)
foreach ($f in $files) {
  if (-not (Test-Path $f)) { "MISSING: $f"; continue }
  $c = Get-Content -Raw -LiteralPath $f
  "===== $f ====="
  foreach ($l in $lits) {
    $n = ([regex]::Matches($c, [regex]::Escape($l))).Count
    if ($n -gt 0) { "{0,4}  {1}" -f $n, $l }
  }
  ""
}
