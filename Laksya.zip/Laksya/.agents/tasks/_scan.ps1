$patterns = @('Padakku Pattasu','padakku_pattasu','9994033148')
foreach ($pat in $patterns) {
  "===== $pat ====="
  Get-ChildItem -Recurse -File | Where-Object { $_.FullName -notmatch '\\dist\\' -and $_.FullName -notmatch '\\.agents\\' } | ForEach-Object {
    $c = (Select-String -Path $_.FullName -Pattern $pat -SimpleMatch -AllMatches -ErrorAction SilentlyContinue | Measure-Object).Count
    if ($c -gt 0) { "{0,4}  {1}" -f $c, (Resolve-Path -Relative $_.FullName) }
  }
  ""
}
