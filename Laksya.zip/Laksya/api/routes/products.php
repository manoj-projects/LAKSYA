<?php
// Catalogue, storefront data, gift boxes, combo packs.

/** Shapes a product row (joined with its category) into ProductOut. */
function product_out(array $p): array
{
    $mrp = (float) $p['mrp'];
    $disc = $mrp > 0 ? (int) round(($mrp - (float) $p['price']) / $mrp * 100) : 0;
    return [
        'id' => (int) $p['id'],
        'product_code' => $p['product_code'],
        'name' => $p['name'],
        'name_tamil' => $p['name_tamil'],
        'category_id' => (int) $p['category_id'],
        'category_slug' => $p['category_slug'] ?? null,
        'category_name' => $p['category_name'] ?? null,
        'unit' => $p['unit'],
        'mrp' => money($p['mrp']),
        'price' => money($p['price']),
        'is_active' => (bool) $p['is_active'],
        'description' => $p['description'],
        'video_url' => $p['video_url'],
        'discount_pct' => $disc,
        'deleted_at' => $p['deleted_at'],
    ];
}

function product_with_category(int $id): ?array
{
    return fetchOne(
        'SELECT p.*, c.slug AS category_slug, c.name AS category_name
         FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.id = ?',
        [$id]
    );
}

// ============================= PUBLIC =============================

$routes[] = ['GET', '/categories', function () {
    respond(array_map(fn($c) => [
        'id' => (int) $c['id'],
        'slug' => $c['slug'],
        'name' => $c['name'],
        'blurb' => $c['blurb'],
        'sort_order' => (int) $c['sort_order'],
    ], fetchAll('SELECT * FROM categories ORDER BY sort_order, name')));
}];

$routes[] = ['GET', '/storefront-data', function () {
    $outOfStock = array_column(fetchAll(
        'SELECT p.product_code FROM products p
         JOIN stock_items s ON s.product_id = p.id
         WHERE s.on_hand <= 0 AND p.deleted_at IS NULL'
    ), 'product_code');

    $inactive = array_column(fetchAll(
        'SELECT product_code FROM products WHERE is_active = 0 AND deleted_at IS NULL'
    ), 'product_code');

    $products = [];
    foreach (fetchAll('SELECT product_code, mrp, price, name, name_tamil FROM products WHERE deleted_at IS NULL AND is_active = 1') as $p) {
        $products[$p['product_code']] = [
            'mrp' => (float) $p['mrp'],
            'price' => (float) $p['price'],
            'name' => $p['name'],
            'name_tamil' => $p['name_tamil'],
        ];
    }

    respond(['out_of_stock' => $outOfStock, 'inactive' => $inactive, 'products' => $products]);
}];

$routes[] = ['GET', '/video-links', function () {
    $map = [];
    foreach (fetchAll(
        "SELECT product_code, video_url FROM products
         WHERE video_url IS NOT NULL AND video_url != '' AND deleted_at IS NULL AND is_active = 1"
    ) as $r) {
        $map[$r['product_code']] = $r['video_url'];
    }
    respond($map);
}];

// Maps the public ?type= param to a counter prefix. Defaults to PRICELIST so the
// original (untyped) calls keep counting the generated price list.
function pricelist_counter_prefix(): string
{
    return qp('type') === 'brand' ? 'BRANDLIST' : 'PRICELIST';
}

$routes[] = ['POST', '/pricelist-download', function () {
    $prefix = pricelist_counter_prefix();
    execute(
        'INSERT INTO bill_counters (prefix, counter_value) VALUES (?, 1)
         ON DUPLICATE KEY UPDATE counter_value = counter_value + 1',
        [$prefix]
    );
    respond(['detail' => 'tracked']);
}];

$routes[] = ['GET', '/pricelist-downloads', function () {
    // Returns both counters so the dashboard can show them separately, plus the
    // legacy `count` (generated price list) for backward compatibility.
    $price = (int) (fetchValue("SELECT counter_value FROM bill_counters WHERE prefix = 'PRICELIST'") ?? 0);
    $brand = (int) (fetchValue("SELECT counter_value FROM bill_counters WHERE prefix = 'BRANDLIST'") ?? 0);
    respond(['count' => $price, 'price_list' => $price, 'brand_list' => $brand]);
}];

// ============================= GIFT BOXES =============================

$routes[] = ['GET', '/gift-boxes', function () {
    respond(array_map(fn($r) => [
        'id' => (int) $r['id'], 'product_code' => $r['product_code'], 'label' => $r['label'],
        'image_url' => $r['image_url'], 'sort_order' => (int) $r['sort_order'],
    ], fetchAll('SELECT * FROM gift_boxes WHERE is_active = 1 ORDER BY sort_order, id')));
}];

$routes[] = ['GET', '/gift-boxes/all', function () {
    requireManager();
    respond(array_map(fn($r) => [
        'id' => (int) $r['id'], 'product_code' => $r['product_code'], 'label' => $r['label'],
        'image_url' => $r['image_url'], 'sort_order' => (int) $r['sort_order'], 'is_active' => (bool) $r['is_active'],
    ], fetchAll('SELECT * FROM gift_boxes ORDER BY sort_order, id')));
}];

$routes[] = ['POST', '/gift-boxes', function () {
    requireManager();
    $id = insertId(
        'INSERT INTO gift_boxes (product_code, label, image_url, sort_order) VALUES (?, ?, ?, ?)',
        [qp('product_code'), qp('label'), qp('image_url'), qpInt('sort_order', 0)]
    );
    respond(['id' => $id, 'detail' => "Gift box '" . qp('label') . "' added."], 201);
}];

$routes[] = ['PATCH', '/gift-boxes/{id}', function ($p) {
    requireManager();
    $sets = [];
    $params = [];
    foreach (['label', 'image_url', 'product_code'] as $f) {
        $v = qp($f);
        if ($v !== null) { $sets[] = "$f = ?"; $params[] = $v; }
    }
    if (qp('sort_order') !== null) { $sets[] = 'sort_order = ?'; $params[] = qpInt('sort_order'); }
    if (qpBool('is_active') !== null) { $sets[] = 'is_active = ?'; $params[] = qpBool('is_active') ? 1 : 0; }
    if (!$sets) { error('Gift box not found.', 404); }
    $params[] = (int) $p['id'];
    if (execute('UPDATE gift_boxes SET ' . implode(', ', $sets) . ' WHERE id = ?', $params) === 0
        && !fetchOne('SELECT id FROM gift_boxes WHERE id = ?', [(int) $p['id']])) {
        error('Gift box not found.', 404);
    }
    respond(['detail' => 'Gift box updated.']);
}];

$routes[] = ['DELETE', '/gift-boxes/{id}', function ($p) {
    requireManager();
    if (!fetchOne('SELECT id FROM gift_boxes WHERE id = ?', [(int) $p['id']])) {
        error('Gift box not found.', 404);
    }
    execute('DELETE FROM gift_boxes WHERE id = ?', [(int) $p['id']]);
    respond(['detail' => 'Gift box removed.']);
}];

// ============================= COMBO PACKS =============================

$routes[] = ['GET', '/combo-packs', function () {
    respond(array_map(fn($r) => [
        'id' => (int) $r['id'], 'product_code' => $r['product_code'], 'label' => $r['label'],
        'image_url' => $r['image_url'], 'sort_order' => (int) $r['sort_order'],
    ], fetchAll('SELECT * FROM combo_packs WHERE is_active = 1 ORDER BY sort_order, id')));
}];

$routes[] = ['GET', '/combo-packs/all', function () {
    requireManager();
    respond(array_map(fn($r) => [
        'id' => (int) $r['id'], 'product_code' => $r['product_code'], 'label' => $r['label'],
        'image_url' => $r['image_url'], 'sort_order' => (int) $r['sort_order'], 'is_active' => (bool) $r['is_active'],
    ], fetchAll('SELECT * FROM combo_packs ORDER BY sort_order, id')));
}];

$routes[] = ['POST', '/combo-packs', function () {
    requireManager();
    $id = insertId(
        'INSERT INTO combo_packs (product_code, label, image_url, sort_order) VALUES (?, ?, ?, ?)',
        [qp('product_code'), qp('label'), qp('image_url'), qpInt('sort_order', 0)]
    );
    respond(['id' => $id, 'detail' => "Combo pack '" . qp('label') . "' added."], 201);
}];

$routes[] = ['PATCH', '/combo-packs/{id}', function ($p) {
    requireManager();
    $sets = [];
    $params = [];
    foreach (['label', 'image_url', 'product_code'] as $f) {
        $v = qp($f);
        if ($v !== null) { $sets[] = "$f = ?"; $params[] = $v; }
    }
    if (qp('sort_order') !== null) { $sets[] = 'sort_order = ?'; $params[] = qpInt('sort_order'); }
    if (qpBool('is_active') !== null) { $sets[] = 'is_active = ?'; $params[] = qpBool('is_active') ? 1 : 0; }
    if (!$sets) { error('Combo pack not found.', 404); }
    $params[] = (int) $p['id'];
    if (execute('UPDATE combo_packs SET ' . implode(', ', $sets) . ' WHERE id = ?', $params) === 0
        && !fetchOne('SELECT id FROM combo_packs WHERE id = ?', [(int) $p['id']])) {
        error('Combo pack not found.', 404);
    }
    respond(['detail' => 'Combo pack updated.']);
}];

$routes[] = ['DELETE', '/combo-packs/{id}', function ($p) {
    requireManager();
    if (!fetchOne('SELECT id FROM combo_packs WHERE id = ?', [(int) $p['id']])) {
        error('Combo pack not found.', 404);
    }
    execute('DELETE FROM combo_packs WHERE id = ?', [(int) $p['id']]);
    respond(['detail' => 'Combo pack removed.']);
}];

// ============================= PRODUCTS =============================

$routes[] = ['POST', '/products/bulk-margin', function () {
    $staff = requireManager();
    $marginPct = (float) qp('margin_pct', 50);
    $categoryId = qp('category_id');
    if ($marginPct < 0 || $marginPct > 99) {
        error('Margin must be between 0 and 99', 422);
    }
    $factor = 1 - $marginPct / 100;

    $where = 'deleted_at IS NULL AND is_active = 1';
    $params = [];
    if ($categoryId !== null) {
        $where .= ' AND category_id = ?';
        $params[] = (int) $categoryId;
    }
    $products = fetchAll("SELECT id, mrp, price FROM products WHERE $where", $params);
    $count = 0;
    foreach ($products as $prod) {
        $newPrice = round((float) $prod['mrp'] * $factor, 0, PHP_ROUND_HALF_UP);
        if ((float) $prod['price'] !== $newPrice) {
            execute('UPDATE products SET price = ? WHERE id = ?', [money($newPrice), (int) $prod['id']]);
            $count++;
        }
    }
    audit_log('product.bulk_margin', 'product', 'cat=' . ($categoryId ?? 'all'),
        "Set {$marginPct}% off MRP for $count products", $staff, clientIp());
    respond(['detail' => "Updated $count product prices to {$marginPct}% off MRP."]);
}];

$routes[] = ['POST', '/products/{id}/toggle-stock', function ($p) {
    $staff = requireManager();
    $oos = qpBool('out_of_stock') === true;
    $pid = (int) $p['id'];
    $product = fetchOne('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL', [$pid]);
    if (!$product) {
        error("Product {$p['id']} not found.", 404);
    }
    $existing = fetchOne('SELECT * FROM stock_items WHERE product_id = ?', [$pid]);
    if ($oos) {
        if ($existing) {
            execute('UPDATE stock_items SET on_hand = 0 WHERE product_id = ?', [$pid]);
        } else {
            execute('INSERT INTO stock_items (product_id, on_hand, reorder_level) VALUES (?, 0, 0)', [$pid]);
        }
        $msg = "{$product['name']} marked out of stock.";
    } else {
        if ($existing) {
            execute('UPDATE stock_items SET on_hand = GREATEST(on_hand, 100) WHERE product_id = ?', [$pid]);
        } else {
            execute('INSERT INTO stock_items (product_id, on_hand, reorder_level) VALUES (?, 100, 10)', [$pid]);
        }
        $msg = "{$product['name']} marked in stock.";
    }
    audit_log('product.stock_toggle', 'product', $pid, $msg, $staff, clientIp());
    respond(['detail' => $msg]);
}];

$routes[] = ['POST', '/products/{id}/restore', function ($p) {
    $staff = requireManager();
    $pid = (int) $p['id'];
    $product = fetchOne('SELECT * FROM products WHERE id = ?', [$pid]);
    if (!$product) {
        error("Product {$p['id']} not found.", 404);
    }
    execute('UPDATE products SET deleted_at = NULL, is_active = 1 WHERE id = ?', [$pid]);
    audit_log('product.restore', 'product', $pid, "Restored {$product['product_code']}", $staff, clientIp());
    respond(product_out(product_with_category($pid)));
}];

$routes[] = ['GET', '/products', function () {
    [$page, $pageSize, $offset] = pageParams();
    $search = qp('search');
    $categoryId = qp('category_id');
    $categorySlug = qp('category_slug');
    $isActive = qpBool('is_active');
    $includeDeleted = qpBool('include_deleted') === true;

    $where = $includeDeleted ? '1=1' : 'p.deleted_at IS NULL';
    $params = [];
    if ($search) {
        $where .= ' AND (p.name LIKE ? OR p.product_code LIKE ?)';
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    if ($categoryId !== null) {
        $where .= ' AND p.category_id = ?';
        $params[] = (int) $categoryId;
    }
    if ($categorySlug) {
        $where .= ' AND c.slug = ?';
        $params[] = $categorySlug;
    }
    if ($isActive !== null) {
        $where .= ' AND p.is_active = ?';
        $params[] = $isActive ? 1 : 0;
    }

    $total = (int) fetchValue(
        "SELECT COUNT(*) FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE $where",
        $params
    );
    $rows = fetchAll(
        "SELECT p.*, c.slug AS category_slug, c.name AS category_name
         FROM products p LEFT JOIN categories c ON c.id = p.category_id
         WHERE $where ORDER BY p.name LIMIT ? OFFSET ?",
        array_merge($params, [$pageSize, $offset])
    );
    respond(pageEnvelope(array_map('product_out', $rows), $total, $page, $pageSize));
}];

$routes[] = ['POST', '/products', function () {
    $staff = requireManager();
    $body = getBody();

    $categoryId = (int) requireField($body, 'category_id');
    if (!fetchOne('SELECT id FROM categories WHERE id = ?', [$categoryId])) {
        error("Category $categoryId does not exist.", 422);
    }

    try {
        $id = insertId(
            'INSERT INTO products (product_code, name, name_tamil, category_id, unit, mrp, price, is_active, description, video_url)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                requireField($body, 'product_code'),
                requireField($body, 'name'),
                $body['name_tamil'] ?? null,
                $categoryId,
                $body['unit'] ?? '1Box',
                requireField($body, 'mrp'),
                requireField($body, 'price'),
                array_key_exists('is_active', $body) ? ($body['is_active'] ? 1 : 0) : 1,
                $body['description'] ?? null,
                $body['video_url'] ?? null,
            ]
        );
    } catch (PDOException $e) {
        error("Product code {$body['product_code']} is already in use.", 409);
    }

    $product = product_with_category($id);
    audit_log('product.create', 'product', $id,
        "{$product['product_code']} {$product['name']} @ {$product['price']}", $staff, clientIp());
    respond(product_out($product), 201);
}];

$routes[] = ['GET', '/products/{id}', function ($p) {
    $product = fetchOne(
        'SELECT p.*, c.slug AS category_slug, c.name AS category_name
         FROM products p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.id = ? AND p.deleted_at IS NULL',
        [(int) $p['id']]
    );
    if (!$product) {
        error("Product {$p['id']} not found.", 404);
    }
    respond(product_out($product));
}];

$routes[] = ['PATCH', '/products/{id}', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $pid = (int) $p['id'];
    $product = fetchOne('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL', [$pid]);
    if (!$product) {
        error("Product {$p['id']} not found.", 404);
    }

    if (array_key_exists('category_id', $body)
        && !fetchOne('SELECT id FROM categories WHERE id = ?', [(int) $body['category_id']])) {
        error("Category {$body['category_id']} does not exist.", 422);
    }

    $sets = [];
    $params = [];
    $described = [];
    foreach (['name', 'name_tamil', 'unit', 'mrp', 'price', 'description', 'video_url', 'category_id'] as $f) {
        if (array_key_exists($f, $body)) {
            $sets[] = "$f = ?";
            $params[] = $body[$f];
            $described[] = "$f={$body[$f]}";
        }
    }
    if (array_key_exists('is_active', $body)) {
        $sets[] = 'is_active = ?';
        $params[] = $body['is_active'] ? 1 : 0;
        $described[] = 'is_active=' . ($body['is_active'] ? '1' : '0');
    }
    if ($sets) {
        $params[] = $pid;
        execute('UPDATE products SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
    }
    audit_log('product.update', 'product', $pid, implode(', ', $described) ?: 'no change', $staff, clientIp());
    respond(product_out(product_with_category($pid)));
}];

$routes[] = ['DELETE', '/products/{id}', function ($p) {
    $staff = requireManager();
    $pid = (int) $p['id'];
    $product = fetchOne('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL', [$pid]);
    if (!$product) {
        error("Product {$p['id']} not found.", 404);
    }
    execute('UPDATE products SET deleted_at = NOW(), is_active = 0 WHERE id = ?', [$pid]);
    audit_log('product.delete', 'product', $pid, "Soft-deleted {$product['product_code']}", $staff, clientIp());
    respond(['detail' => "{$product['name']} removed from the catalogue."]);
}];
