<?php
// Finance & management endpoints: receivables, collections by mode, expenses,
// commission payouts, and a profit summary. All manager+.

/** Inclusive date window helper (mirrors reports.php). */
function fin_window(string $column, array &$params): string
{
    $clause = '';
    $from = qp('date_from');
    $to = qp('date_to');
    if ($from) { $clause .= " AND $column >= ?"; $params[] = $from . ' 00:00:00'; }
    if ($to) { $clause .= " AND $column <= ?"; $params[] = $to . ' 23:59:59'; }
    return $clause;
}

// ------------------------------------------------------- receivables (unpaid)

$routes[] = ['GET', '/finance/receivables', function () {
    requireManager();
    // Every live bill with an outstanding balance, biggest/oldest first.
    $rows = fetchAll(
        "SELECT o.id, o.bill_no, o.status, o.payment_status, o.total, o.amount_paid,
                (o.total - o.amount_paid) AS balance_due, o.created_at,
                c.name AS customer_name, c.phone AS customer_phone,
                a.name AS agent_name,
                DATEDIFF(NOW(), o.created_at) AS age_days
         FROM orders o
         JOIN customers c ON c.id = o.customer_id
         LEFT JOIN agents a ON a.id = o.agent_id
         WHERE o.deleted_at IS NULL
           AND o.status IN ('confirmed','packed','dispatched','delivered')
           AND (o.total - o.amount_paid) > 0
         ORDER BY (o.total - o.amount_paid) DESC, o.created_at ASC"
    );

    $items = array_map(fn($r) => [
        'id' => (int) $r['id'],
        'bill_no' => $r['bill_no'],
        'status' => $r['status'],
        'payment_status' => $r['payment_status'],
        'customer_name' => $r['customer_name'],
        'customer_phone' => $r['customer_phone'],
        'agent_name' => $r['agent_name'],
        'total' => money($r['total']),
        'amount_paid' => money($r['amount_paid']),
        'balance_due' => money($r['balance_due']),
        'age_days' => (int) $r['age_days'],
        'created_at' => $r['created_at'],
    ], $rows);

    $totalOutstanding = array_reduce($rows, fn($s, $r) => $s + (float) $r['balance_due'], 0.0);
    respond([
        'items' => $items,
        'count' => count($items),
        'total_outstanding' => money($totalOutstanding),
    ]);
}];

// --------------------------------------------- settlement (Rajam cost vs PP)

// Compares what the customer pays (PP selling price) against what the goods
// cost from the supplier, Rajam Trading Company. Rajam's net rate is a fixed
// 2/3 of the Padakku Pattasu selling price (derived from Rajam's 80% list vs
// PP's 80% list — PP price = 1.5 x Rajam cost across the catalogue), so the
// cost is computed inline from each line's unit price. No supplier-cost table
// is needed.
$routes[] = ['GET', '/finance/settlement', function () {
    requireManager();
    $p = [];
    $w = fin_window('o.created_at', $p);
    $rows = fetchAll(
        "SELECT o.id, o.bill_no, o.created_at,
                c.name AS customer_name, c.phone AS customer_phone,
                a.name AS agent_name,
                COALESCE(SUM(oi.qty),0) AS pieces,
                COALESCE(SUM(oi.line_total),0) AS pp_price,
                COALESCE(SUM(ROUND(oi.price * 2 / 3, 2) * oi.qty),0) AS rajam_price
         FROM orders o
         JOIN customers c ON c.id = o.customer_id
         LEFT JOIN agents a ON a.id = o.agent_id
         JOIN order_items oi ON oi.order_id = o.id
         WHERE o.deleted_at IS NULL
           AND o.status IN ('confirmed','packed','dispatched','delivered') $w
         GROUP BY o.id, o.bill_no, o.created_at, c.name, c.phone, a.name
         ORDER BY o.created_at DESC",
        $p
    );

    $items = [];
    $tPp = 0.0; $tRajam = 0.0;
    foreach ($rows as $r) {
        $pp = (float) $r['pp_price'];
        $rajam = (float) $r['rajam_price'];
        $margin = $pp - $rajam;
        $tPp += $pp; $tRajam += $rajam;
        $items[] = [
            'id' => (int) $r['id'],
            'bill_no' => $r['bill_no'],
            'created_at' => $r['created_at'],
            'customer_name' => $r['customer_name'],
            'customer_phone' => $r['customer_phone'],
            'agent_name' => $r['agent_name'],
            'pieces' => (int) $r['pieces'],
            'pp_price' => money($pp),
            // jm_* keys carry the Rajam figures (the UI reads jm_* for the
            // single "Rajam" column after the JM/AK -> Rajam rename).
            'jm_price' => money($rajam),
            'jm_margin' => money($margin),
            'jm_margin_pct' => $pp > 0 ? (int) round($margin / $pp * 100) : 0,
        ];
    }
    $tMargin = $tPp - $tRajam;
    respond([
        'items' => $items,
        'total_pp_price' => money($tPp),
        'total_jm_price' => money($tRajam),
        'total_jm_margin' => money($tMargin),
        'total_jm_margin_pct' => $tPp > 0 ? (int) round($tMargin / $tPp * 100) : 0,
    ]);
}];

// -------------------------------------------------- collections by payment mode

$routes[] = ['GET', '/finance/collections', function () {
    requireManager();
    $p = [];
    $w = fin_window('received_at', $p);
    $rows = fetchAll(
        "SELECT mode, COUNT(*) AS cnt, COALESCE(SUM(amount),0) AS total
         FROM payments WHERE 1=1 $w GROUP BY mode ORDER BY total DESC",
        $p
    );
    $byMode = array_map(fn($r) => [
        'mode' => $r['mode'],
        'count' => (int) $r['cnt'],
        'total' => money($r['total']),
    ], $rows);
    $grand = array_reduce($rows, fn($s, $r) => $s + (float) $r['total'], 0.0);

    // Daily collected (all modes), oldest-first for charting.
    $p2 = [];
    $w2 = fin_window('received_at', $p2);
    $daily = fetchAll(
        "SELECT DATE(received_at) AS day, COALESCE(SUM(amount),0) AS total
         FROM payments WHERE 1=1 $w2 GROUP BY DATE(received_at) ORDER BY day DESC LIMIT 60",
        $p2
    );
    $daily = array_reverse($daily);

    respond([
        'period_from' => qp('date_from') ?: null,
        'period_to' => qp('date_to') ?: null,
        'by_mode' => $byMode,
        'total_collected' => money($grand),
        'daily' => array_map(fn($r) => ['day' => $r['day'], 'total' => money($r['total'])], $daily),
    ]);
}];

// --------------------------------------------------- profit / margin summary

$routes[] = ['GET', '/finance/profit', function () {
    requireManager();
    $p = [];
    $w = fin_window('o.created_at', $p);
    // Revenue from sold line items (confirmed+). Supplier cost tracking has been
    // removed, so there is no COGS/gross-profit — net profit is revenue minus
    // expenses in the window.
    $row = fetchOne(
        "SELECT COALESCE(SUM(oi.line_total),0) AS revenue,
                COALESCE(SUM(oi.qty),0) AS pieces
         FROM order_items oi
         JOIN orders o ON o.id = oi.order_id
         WHERE o.deleted_at IS NULL
           AND o.status IN ('confirmed','packed','dispatched','delivered') $w",
        $p
    );
    $revenue = (float) $row['revenue'];

    // Expenses in the same window.
    $pe = [];
    $we = fin_window('spent_on', $pe);
    $expenses = (float) fetchValue("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE 1=1 $we", $pe);

    $netProfit = $revenue - $expenses;

    respond([
        'period_from' => qp('date_from') ?: null,
        'period_to' => qp('date_to') ?: null,
        'revenue' => money($revenue),
        'expenses' => money($expenses),
        'net_profit' => money($netProfit),
        'net_margin_pct' => $revenue > 0 ? (int) round($netProfit / $revenue * 100) : 0,
        'pieces_sold' => (int) $row['pieces'],
    ]);
}];

// -------------------------------------------------------------- expenses CRUD

$routes[] = ['GET', '/finance/expenses', function () {
    requireManager();
    [$page, $pageSize, $offset] = pageParams();
    $p = [];
    $w = fin_window('spent_on', $p);
    $category = qp('category');
    if ($category) { $w .= ' AND category = ?'; $p[] = $category; }

    $total = (int) fetchValue("SELECT COUNT(*) FROM expenses WHERE 1=1 $w", $p);
    $sum = (float) fetchValue("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE 1=1 $w", $p);
    $rows = fetchAll(
        "SELECT e.*, a.name AS actor_name FROM expenses e
         LEFT JOIN agents a ON a.id = e.actor_id
         WHERE 1=1 $w ORDER BY e.spent_on DESC, e.id DESC LIMIT ? OFFSET ?",
        array_merge($p, [$pageSize, $offset])
    );
    $items = array_map(fn($r) => [
        'id' => (int) $r['id'],
        'spent_on' => $r['spent_on'],
        'category' => $r['category'],
        'amount' => money($r['amount']),
        'note' => $r['note'],
        'actor_label' => $r['actor_name'],
        'created_at' => $r['created_at'],
    ], $rows);
    $env = pageEnvelope($items, $total, $page, $pageSize);
    $env['total_amount'] = money($sum);
    respond($env);
}];

$routes[] = ['POST', '/finance/expenses', function () {
    $staff = requireManager();
    $body = getBody();
    $spentOn = $body['spent_on'] ?? date('Y-m-d');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $spentOn)) {
        error('spent_on must be a YYYY-MM-DD date.', 422);
    }
    $category = trim((string) requireField($body, 'category'));
    $amount = (float) requireField($body, 'amount');
    if ($amount <= 0) {
        error('Amount must be greater than zero.', 422);
    }
    $id = insertId(
        'INSERT INTO expenses (spent_on, category, amount, note, actor_id) VALUES (?, ?, ?, ?, ?)',
        [$spentOn, $category, money($amount), $body['note'] ?? null, $staff['id']]
    );
    audit_log('expense.create', 'expense', $id, "$category " . money($amount) . " on $spentOn", $staff, clientIp());
    respond(['id' => $id, 'detail' => 'Expense recorded.'], 201);
}];

$routes[] = ['DELETE', '/finance/expenses/{id}', function ($p) {
    $staff = requireManager();
    $row = fetchOne('SELECT * FROM expenses WHERE id = ?', [(int) $p['id']]);
    if (!$row) {
        error('Expense not found.', 404);
    }
    execute('DELETE FROM expenses WHERE id = ?', [(int) $p['id']]);
    audit_log('expense.delete', 'expense', $p['id'], "{$row['category']} " . money($row['amount']), $staff, clientIp());
    respond(['detail' => 'Expense removed.']);
}];

// ----------------------------------------------------- commission payouts

// Per-agent commission earned (from revenue) minus what's already been paid out.
$routes[] = ['GET', '/finance/commissions', function () {
    requireManager();
    $rows = fetchAll(
        "SELECT a.id AS agent_id, a.code, a.name, a.commission_pct,
                COALESCE(o.revenue, 0) AS revenue,
                COALESCE(pay.paid, 0) AS paid
         FROM agents a
         LEFT JOIN (
             SELECT agent_id, SUM(total) AS revenue FROM orders
             WHERE deleted_at IS NULL AND status IN ('confirmed','packed','dispatched','delivered')
             GROUP BY agent_id
         ) o ON o.agent_id = a.id
         LEFT JOIN (
             SELECT agent_id, SUM(amount) AS paid FROM commission_payouts GROUP BY agent_id
         ) pay ON pay.agent_id = a.id
         WHERE a.deleted_at IS NULL AND a.role = 'agent'
         ORDER BY COALESCE(o.revenue,0) DESC, a.name"
    );
    $items = [];
    $totalDue = 0.0;
    foreach ($rows as $r) {
        $rev = (float) $r['revenue'];
        $pct = (float) $r['commission_pct'];
        $earned = round($rev * $pct / 100, 2, PHP_ROUND_HALF_UP);
        $paid = (float) $r['paid'];
        $due = max(0, $earned - $paid);
        $totalDue += $due;
        $items[] = [
            'agent_id' => (int) $r['agent_id'],
            'code' => $r['code'],
            'name' => $r['name'],
            'commission_pct' => money($pct),
            'revenue' => money($rev),
            'earned' => money($earned),
            'paid' => money($paid),
            'due' => money($due),
        ];
    }
    respond(['items' => $items, 'total_due' => money($totalDue)]);
}];

$routes[] = ['GET', '/finance/commissions/{agent_id}/payouts', function ($p) {
    requireManager();
    $rows = fetchAll(
        "SELECT po.*, a.name AS actor_name FROM commission_payouts po
         LEFT JOIN agents a ON a.id = po.actor_id
         WHERE po.agent_id = ? ORDER BY po.paid_on DESC, po.id DESC",
        [(int) $p['agent_id']]
    );
    respond(array_map(fn($r) => [
        'id' => (int) $r['id'],
        'amount' => money($r['amount']),
        'paid_on' => $r['paid_on'],
        'note' => $r['note'],
        'actor_label' => $r['actor_name'],
        'created_at' => $r['created_at'],
    ], $rows));
}];

$routes[] = ['POST', '/finance/commissions/{agent_id}/payouts', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $agentId = (int) $p['agent_id'];
    $agent = fetchOne('SELECT * FROM agents WHERE id = ? AND deleted_at IS NULL', [$agentId]);
    if (!$agent) {
        error('Agent not found.', 404);
    }
    $amount = (float) requireField($body, 'amount');
    if ($amount <= 0) {
        error('Payout amount must be greater than zero.', 422);
    }
    $paidOn = $body['paid_on'] ?? date('Y-m-d');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $paidOn)) {
        error('paid_on must be a YYYY-MM-DD date.', 422);
    }
    $id = insertId(
        'INSERT INTO commission_payouts (agent_id, amount, paid_on, note, actor_id) VALUES (?, ?, ?, ?, ?)',
        [$agentId, money($amount), $paidOn, $body['note'] ?? null, $staff['id']]
    );
    audit_log('commission.payout', 'agent', $agentId, money($amount) . " paid to {$agent['name']} on $paidOn", $staff, clientIp());
    respond(['id' => $id, 'detail' => 'Payout recorded.'], 201);
}];

$routes[] = ['DELETE', '/finance/commissions/payouts/{id}', function ($p) {
    $staff = requireManager();
    $row = fetchOne('SELECT * FROM commission_payouts WHERE id = ?', [(int) $p['id']]);
    if (!$row) {
        error('Payout not found.', 404);
    }
    execute('DELETE FROM commission_payouts WHERE id = ?', [(int) $p['id']]);
    audit_log('commission.payout_delete', 'agent', $row['agent_id'], 'Reversed payout ' . money($row['amount']), $staff, clientIp());
    respond(['detail' => 'Payout removed.']);
}];
