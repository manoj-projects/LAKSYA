<?php
// Bills: create, edit, track, pay, trash. Includes the public tracking lookup.

// ------------------------------------------------------------------- public

$routes[] = ['GET', '/orders/track/{bill_no}', function ($p) {
    $order = order_by_bill_no($p['bill_no']);
    $events = fetchAll(
        'SELECT e.*, a.name AS actor_name, a.code AS actor_code
         FROM order_status_events e LEFT JOIN agents a ON a.id = e.actor_id
         WHERE e.order_id = ? ORDER BY e.id',
        [(int) $order['id']]
    );
    respond([
        'bill_no' => $order['bill_no'],
        'status' => $order['status'],
        'placed_on' => $order['created_at'],
        'item_count' => (int) $order['item_count'],
        'transport_name' => $order['transport_name'],
        'docket_no' => $order['docket_no'],
        'dispatched_at' => $order['dispatched_at'],
        'delivered_at' => $order['delivered_at'],
        'timeline' => array_map(function ($e) {
            $e['actor_label'] = $e['actor_name'] ? ($e['actor_name'] . ' (' . $e['actor_code'] . ')') : null;
            return status_event_out($e);
        }, $events),
    ]);
}];

// -------------------------------------------------------------------- staff

$routes[] = ['GET', '/orders', function () {
    $agent = requireAuth();
    [$page, $pageSize, $offset] = pageParams();
    $search = qp('search');
    $status = qp('status');
    $paymentStatus = qp('payment_status');
    $agentId = qp('agent_id');
    $dateFrom = qp('date_from');
    $dateTo = qp('date_to');
    $trashed = qpBool('trashed') === true;

    $where = $trashed ? 'o.deleted_at IS NOT NULL' : 'o.deleted_at IS NULL';
    $params = [];

    if (strtolower($agent['role']) === 'agent') {
        $where .= ' AND (o.agent_id = ? OR o.agent_id IS NULL)';
        $params[] = (int) $agent['id'];
    } elseif ($agentId !== null) {
        $where .= ' AND o.agent_id = ?';
        $params[] = (int) $agentId;
    }
    if ($status) { $where .= ' AND o.status = ?'; $params[] = strtolower($status); }
    if ($paymentStatus) { $where .= ' AND o.payment_status = ?'; $params[] = strtolower($paymentStatus); }
    if ($dateFrom) { $where .= ' AND o.created_at >= ?'; $params[] = $dateFrom . ' 00:00:00'; }
    if ($dateTo) { $where .= ' AND o.created_at <= ?'; $params[] = $dateTo . ' 23:59:59'; }
    if ($search) {
        $where .= ' AND (o.bill_no LIKE ? OR cu.name LIKE ? OR cu.phone LIKE ? OR cu.pincode LIKE ? OR o.docket_no LIKE ?)';
        $params = array_merge($params, array_fill(0, 5, "%$search%"));
    }

    $base = 'FROM orders o JOIN customers cu ON cu.id = o.customer_id LEFT JOIN agents a ON a.id = o.agent_id WHERE ' . $where;
    $total = (int) fetchValue("SELECT COUNT(*) $base", $params);
    $rows = fetchAll(
        "SELECT o.*, cu.name AS customer_name, cu.phone AS customer_phone, a.name AS agent_name,
                (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) AS line_count
         $base ORDER BY o.id DESC LIMIT ? OFFSET ?",
        array_merge($params, [$pageSize, $offset])
    );

    $items = array_map(fn($o) => [
        'id' => (int) $o['id'],
        'bill_no' => $o['bill_no'],
        'status' => $o['status'],
        'payment_status' => $o['payment_status'],
        'customer_id' => (int) $o['customer_id'],
        'customer_name' => $o['customer_name'],
        'customer_phone' => $o['customer_phone'],
        'agent_id' => $o['agent_id'] !== null ? (int) $o['agent_id'] : null,
        'agent_name' => $o['agent_name'],
        'item_count' => (int) $o['item_count'],
        'line_count' => (int) $o['line_count'],
        'total' => money($o['total']),
        'amount_paid' => money($o['amount_paid']),
        'balance_due' => money(order_balance_due($o)),
        'created_at' => $o['created_at'],
        'deleted_at' => $o['deleted_at'],
    ], $rows);
    respond(pageEnvelope($items, $total, $page, $pageSize));
}];

$routes[] = ['POST', '/orders', function () {
    $agent = requireAuth();
    $body = getBody();

    if (!empty($body['customer_id'])) {
        $customer = customer_require((int) $body['customer_id']);
    } elseif (!empty($body['customer']) && is_array($body['customer'])) {
        $customerId = customer_get_or_create($body['customer']);
        $customer = fetchOne('SELECT * FROM customers WHERE id = ?', [$customerId]);
    } else {
        error('Provide either customer_id or a customer object', 422);
    }

    if (array_key_exists('delivery_pincode', $body)) {
        validatePincode($body['delivery_pincode']);
    }

    // An agent's bills are always booked to themselves.
    $agentId = strtolower($agent['role']) === 'agent' ? (int) $agent['id'] : ($body['agent_id'] ?? null);

    $orderId = order_create([
        'customer_id' => (int) $customer['id'],
        'agent_id' => $agentId,
        'items' => $body['items'] ?? [],
        'discount_pct' => (float) ($body['discount_pct'] ?? 0),
        'packing_charges' => (float) ($body['packing_charges'] ?? 0),
        'coupon_code' => $body['coupon_code'] ?? null,
        'delivery_address' => $body['delivery_address'] ?? $customer['address'],
        'delivery_pincode' => $body['delivery_pincode'] ?? $customer['pincode'],
        'notes' => $body['notes'] ?? null,
        'confirm' => !empty($body['confirm']),
        'actor' => $agent,
        'ip_address' => clientIp(),
    ]);

    respond(order_out($orderId), 201);
}];

$routes[] = ['GET', '/orders/{id}', function ($p) {
    $agent = requireAuth();
    $includeDeleted = qpBool('include_deleted') === true;
    $order = order_require((int) $p['id'], $includeDeleted);
    if (strtolower($agent['role']) === 'agent'
        && $order['agent_id'] !== null && (int) $order['agent_id'] !== (int) $agent['id']) {
        error('This bill belongs to another agent.', 403);
    }
    respond(order_out((int) $p['id'], $includeDeleted));
}];

$routes[] = ['PATCH', '/orders/{id}', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $order = order_require((int) $p['id']);
    if (array_key_exists('delivery_pincode', $body)) {
        validatePincode($body['delivery_pincode']);
    }
    $updateArgs = [
        'items' => array_key_exists('items', $body) ? $body['items'] : null,
        'discount_pct' => array_key_exists('discount_pct', $body) ? $body['discount_pct'] : null,
        'packing_charges' => array_key_exists('packing_charges', $body) ? $body['packing_charges'] : null,
        'delivery_address' => $body['delivery_address'] ?? null,
        'delivery_pincode' => $body['delivery_pincode'] ?? null,
        'transport_name' => $body['transport_name'] ?? null,
        'docket_no' => $body['docket_no'] ?? null,
        'notes' => $body['notes'] ?? null,
        'actor' => $staff,
    ];
    // Only touch the agent mapping when the client explicitly sends it, so an
    // unrelated edit (transport, notes) never clears an existing agent. An explicit
    // null unassigns; a number (re)assigns.
    if (array_key_exists('agent_id', $body)) {
        $updateArgs['agent_id'] = $body['agent_id'] !== null ? (int) $body['agent_id'] : null;
        $updateArgs['agent_id_present'] = true;
    }
    order_update($order, $updateArgs);
    respond(order_out((int) $p['id']));
}];

// Sets/edits the customer ON A SINGLE BILL. Renaming here forks to a separate
// customer for the same phone (so other bills on that number are NOT renamed);
// address/pincode edits apply to that phone+name identity.
$routes[] = ['POST', '/orders/{id}/customer', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $order = order_require((int) $p['id']);

    $current = fetchOne('SELECT * FROM customers WHERE id = ?', [(int) $order['customer_id']]);
    $phone = validatePhone($body['phone'] ?? ($current['phone'] ?? null));
    $name = isset($body['name']) ? trim((string) $body['name']) : (string) ($current['name'] ?? '');
    if (array_key_exists('pincode', $body)) {
        validatePincode($body['pincode']);
    }

    // Resolve (or create) the customer for this phone + name.
    $custId = customer_get_or_create([
        'phone' => $phone,
        'name' => $name !== '' ? $name : null,
        'address' => $body['address'] ?? null,
        'city' => $body['city'] ?? null,
        'pincode' => $body['pincode'] ?? null,
    ]);

    // Persist the edited details onto that resolved identity.
    execute(
        'UPDATE customers SET name = ?, address = ?, city = ?, pincode = ? WHERE id = ?',
        [
            $name !== '' ? $name : null,
            $body['address'] ?? null,
            $body['city'] ?? null,
            $body['pincode'] ?? null,
            $custId,
        ]
    );

    // Point only this bill at the resolved customer.
    if ((int) $custId !== (int) $order['customer_id']) {
        execute('UPDATE orders SET customer_id = ? WHERE id = ?', [$custId, (int) $order['id']]);
    }

    audit_log('order.customer', 'order', $order['id'], "Customer set to " . ($name ?: '—') . " ($phone)", $staff, clientIp());
    respond(order_out((int) $p['id']));
}];

$routes[] = ['POST', '/orders/{id}/status', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $newStatus = strtolower((string) requireField($body, 'status'));
    $order = order_require((int) $p['id']);
    order_change_status($order, $newStatus, $staff, $body['note'] ?? null);
    respond(order_out((int) $p['id']));
}];

$routes[] = ['POST', '/orders/{id}/payments', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $order = order_require((int) $p['id']);
    $paymentId = order_add_payment($order, $body, $staff);
    $payment = fetchOne('SELECT * FROM payments WHERE id = ?', [$paymentId]);
    $payment['actor_label'] = $staff['name'];
    respond(payment_out($payment), 201);
}];

$routes[] = ['POST', '/orders/{id}/restore', function ($p) {
    $staff = requireManager();
    $order = order_require((int) $p['id'], true);
    order_restore($order, $staff);
    respond(order_out((int) $p['id'], true));
}];

$routes[] = ['DELETE', '/orders/{id}', function ($p) {
    $staff = requireManager();
    $order = order_require((int) $p['id']);
    order_soft_delete($order, $staff);
    respond(['detail' => "{$order['bill_no']} moved to trash."]);
}];
