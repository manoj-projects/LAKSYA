<?php
// Stock levels, adjustments, alerts, and the movement ledger.

/** Builds a StockRow from a product row, its (optional) stock row, and committed qty. */
function inv_row(array $product, ?array $stock, int $committed): array
{
    $onHand = $stock ? (int) $stock['on_hand'] : 0;
    $reorder = $stock ? (int) $stock['reorder_level'] : 0;
    $available = $onHand - $committed;
    return [
        'product_id' => (int) $product['id'],
        'product_code' => $product['product_code'],
        'name' => $product['name'],
        'category_name' => $product['category_name'] ?? '',
        'unit' => $product['unit'],
        'price' => money($product['price']),
        'tracked' => $stock !== null,
        'on_hand' => $onHand,
        'reorder_level' => $reorder,
        'committed' => $committed,
        'available' => $available,
        'state' => stock_state($stock !== null, $available, $reorder),
        'location' => $stock['location'] ?? null,
    ];
}

$routes[] = ['GET', '/inventory', function () {
    requireManager();
    [$page, $pageSize, $offset] = pageParams();
    $view = qp('view', 'alerts');
    if (!in_array($view, ['all', 'tracked', 'untracked', 'alerts'], true)) {
        error('view must be one of: all, tracked, untracked, alerts', 422);
    }
    $search = qp('search');
    $categorySlug = qp('category_slug');

    $where = 'p.deleted_at IS NULL';
    $params = [];
    if ($view === 'tracked') {
        $where .= ' AND s.id IS NOT NULL';
    } elseif ($view === 'untracked') {
        $where .= ' AND s.id IS NULL';
    }
    if ($search) {
        $where .= ' AND (p.name LIKE ? OR p.product_code LIKE ?)';
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    if ($categorySlug) {
        $where .= ' AND c.slug = ?';
        $params[] = $categorySlug;
    }

    $rows = fetchAll(
        "SELECT p.*, c.name AS category_name,
                s.id AS stock_id, s.on_hand, s.reorder_level, s.location
         FROM products p
         LEFT JOIN stock_items s ON s.product_id = p.id
         LEFT JOIN categories c ON c.id = p.category_id
         WHERE $where ORDER BY p.name",
        $params
    );

    $committed = stock_committed_map();
    $built = [];
    foreach ($rows as $r) {
        $stock = $r['stock_id'] !== null
            ? ['on_hand' => $r['on_hand'], 'reorder_level' => $r['reorder_level'], 'location' => $r['location']]
            : null;
        $built[] = inv_row($r, $stock, $committed[(int) $r['id']] ?? 0);
    }

    if ($view === 'alerts') {
        $built = array_values(array_filter($built, fn($r) => in_array($r['state'], ['low', 'out'], true)));
    }

    $total = count($built);
    $window = array_slice($built, $offset, $pageSize);
    respond(pageEnvelope($window, $total, $page, $pageSize));
}];

$routes[] = ['GET', '/inventory/alerts', function () {
    requireManager();
    $committed = stock_committed_map();
    $rows = fetchAll(
        'SELECT p.*, c.name AS category_name, s.on_hand, s.reorder_level, s.location
         FROM products p
         JOIN stock_items s ON s.product_id = p.id
         LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.deleted_at IS NULL'
    );
    $out = [];
    foreach ($rows as $r) {
        $row = inv_row($r, ['on_hand' => $r['on_hand'], 'reorder_level' => $r['reorder_level'], 'location' => $r['location']], $committed[(int) $r['id']] ?? 0);
        if (in_array($row['state'], ['low', 'out'], true)) {
            $out[] = $row;
        }
    }
    usort($out, fn($a, $b) => [$a['available'], $a['name']] <=> [$b['available'], $b['name']]);
    respond($out);
}];

$routes[] = ['GET', '/inventory/movements', function () {
    requireManager();
    [$page, $pageSize, $offset] = pageParams();
    $productId = qp('product_id');
    $reference = qp('reference');

    $where = '1=1';
    $params = [];
    if ($productId !== null) {
        $where .= ' AND m.product_id = ?';
        $params[] = (int) $productId;
    }
    if ($reference) {
        $where .= ' AND m.reference = ?';
        $params[] = strtoupper(trim($reference));
    }

    $base = 'FROM stock_movements m
        JOIN products p ON p.id = m.product_id
        LEFT JOIN agents a ON a.id = m.actor_id
        WHERE ' . $where;
    $total = (int) fetchValue("SELECT COUNT(*) $base", $params);
    $rows = fetchAll(
        "SELECT m.*, p.product_code, p.name AS product_name, a.name AS actor_label
         $base ORDER BY m.id DESC LIMIT ? OFFSET ?",
        array_merge($params, [$pageSize, $offset])
    );

    $items = array_map(fn($m) => [
        'id' => (int) $m['id'],
        'product_id' => (int) $m['product_id'],
        'product_code' => $m['product_code'],
        'product_name' => $m['product_name'],
        'delta' => (int) $m['delta'],
        'on_hand_after' => (int) $m['on_hand_after'],
        'reason' => $m['reason'],
        'reference' => $m['reference'],
        'note' => $m['note'],
        'actor_label' => $m['actor_label'],
        'created_at' => $m['created_at'],
    ], $rows);
    respond(pageEnvelope($items, $total, $page, $pageSize));
}];

$routes[] = ['POST', '/inventory/{id}/track', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $pid = (int) $p['id'];

    $product = fetchOne(
        'SELECT p.*, c.name AS category_name FROM products p
         LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.id = ? AND p.deleted_at IS NULL',
        [$pid]
    );
    if (!$product) {
        error("Product {$p['id']} not found.", 404);
    }
    if (stock_get($pid) !== null) {
        error("{$product['name']} is already tracked. Use the adjust endpoint.", 409);
    }

    $onHand = (int) ($body['on_hand'] ?? 0);
    $reorder = (int) ($body['reorder_level'] ?? 0);
    if ($onHand < 0 || $reorder < 0) {
        error('Counts must not be negative.', 422);
    }

    execute(
        'INSERT INTO stock_items (product_id, on_hand, reorder_level, location) VALUES (?, ?, ?, ?)',
        [$pid, $onHand, $reorder, $body['location'] ?? null]
    );
    if ($onHand > 0) {
        execute(
            'INSERT INTO stock_movements (product_id, delta, on_hand_after, reason, note, actor_id)
             VALUES (?, ?, ?, ?, ?, ?)',
            [$pid, $onHand, $onHand, 'opening', 'Opening stock', $staff['id']]
        );
    }
    audit_log('stock.track', 'product', $pid, "Opening $onHand, reorder at $reorder", $staff, clientIp());

    $committed = stock_committed_map();
    respond(inv_row($product, stock_get($pid), $committed[$pid] ?? 0), 201);
}];

$routes[] = ['POST', '/inventory/{id}/adjust', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $pid = (int) $p['id'];
    $delta = (int) requireField($body, 'delta');
    $reason = $body['reason'] ?? 'manual';

    stock_apply_movement($pid, $delta, $reason, $staff, null, $body['note'] ?? null, clientIp());

    $product = fetchOne(
        'SELECT p.*, c.name AS category_name FROM products p
         LEFT JOIN categories c ON c.id = p.category_id WHERE p.id = ?',
        [$pid]
    );
    $committed = stock_committed_map();
    respond(inv_row($product, stock_get($pid), $committed[$pid] ?? 0));
}];

$routes[] = ['PATCH', '/inventory/{id}', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $pid = (int) $p['id'];
    $stock = stock_get($pid);
    if ($stock === null) {
        error('This product is not tracked.', 404);
    }

    $sets = [];
    $params = [];
    $described = [];
    if (array_key_exists('reorder_level', $body)) {
        $sets[] = 'reorder_level = ?';
        $params[] = (int) $body['reorder_level'];
        $described[] = 'reorder_level=' . (int) $body['reorder_level'];
    }
    if (array_key_exists('location', $body)) {
        $sets[] = 'location = ?';
        $params[] = $body['location'];
        $described[] = 'location=' . $body['location'];
    }
    if ($sets) {
        $params[] = $pid;
        execute('UPDATE stock_items SET ' . implode(', ', $sets) . ' WHERE product_id = ?', $params);
    }
    audit_log('stock.settings', 'product', $pid, implode(', ', $described) ?: 'no change', $staff, clientIp());

    $product = fetchOne(
        'SELECT p.*, c.name AS category_name FROM products p
         LEFT JOIN categories c ON c.id = p.category_id WHERE p.id = ?',
        [$pid]
    );
    $committed = stock_committed_map();
    respond(inv_row($product, stock_get($pid), $committed[$pid] ?? 0));
}];

$routes[] = ['DELETE', '/inventory/{id}/track', function ($p) {
    $staff = requireManager();
    $pid = (int) $p['id'];
    if (stock_get($pid) === null) {
        error('This product is not tracked.', 404);
    }
    execute('DELETE FROM stock_items WHERE product_id = ?', [$pid]);
    audit_log('stock.untrack', 'product', $pid, 'Tracking stopped; ledger retained', $staff, clientIp());
    respond(['detail' => 'Stock tracking stopped.']);
}];
