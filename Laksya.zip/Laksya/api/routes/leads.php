<?php
// Leads: public submit plus staff management.

$routes[] = ['GET', '/leads/counts', function () {
    requireAuth();
    $row = fetchOne(
        "SELECT COUNT(*) AS total,
                COALESCE(SUM(CASE WHEN lead_type='estimate' THEN 1 ELSE 0 END),0) AS estimates,
                COALESCE(SUM(CASE WHEN lead_type='order' THEN 1 ELSE 0 END),0) AS orders,
                COALESCE(SUM(CASE WHEN status='converted' THEN 1 ELSE 0 END),0) AS conversions
         FROM leads WHERE deleted_at IS NULL"
    );
    respond([
        'total' => (int) $row['total'],
        'estimates' => (int) $row['estimates'],
        'orders' => (int) $row['orders'],
        'conversions' => (int) $row['conversions'],
    ]);
}];

$routes[] = ['POST', '/leads/public', function () {
    $body = getBody();
    // Source is forced and agent stripped: a public caller must not label itself.
    $body['source'] = 'website';
    $body['agent_id'] = null;

    $leadId = lead_create($body);
    $reference = fetchValue('SELECT reference FROM leads WHERE id = ?', [$leadId]);
    $phone = $body['customer']['phone'] ?? '';
    audit_log('lead.public_submit', 'lead', $reference, "Website enquiry from $phone", null, clientIp());
    // Acknowledgement only — no totals or ids for an anonymous caller.
    respond(['detail' => $reference], 202);
}];

$routes[] = ['GET', '/leads', function () {
    $agent = requireAuth();
    [$page, $pageSize, $offset] = pageParams();
    $search = qp('search');
    $status = qp('status');
    $source = qp('source');
    $agentId = qp('agent_id');
    $leadType = qp('lead_type');
    $dateFrom = qp('date_from');
    $dateTo = qp('date_to');

    $where = 'l.deleted_at IS NULL';
    $params = [];

    if (strtolower($agent['role']) === 'agent') {
        $where .= ' AND (l.agent_id = ? OR l.agent_id IS NULL)';
        $params[] = (int) $agent['id'];
    } elseif ($agentId !== null) {
        $where .= ' AND l.agent_id = ?';
        $params[] = (int) $agentId;
    }
    if ($status) { $where .= ' AND l.status = ?'; $params[] = strtolower($status); }
    if ($source) { $where .= ' AND l.source = ?'; $params[] = strtolower($source); }
    if ($leadType) { $where .= ' AND l.lead_type = ?'; $params[] = $leadType; }
    if ($dateFrom) { $where .= ' AND l.created_at >= ?'; $params[] = $dateFrom . ' 00:00:00'; }
    if ($dateTo) { $where .= ' AND l.created_at <= ?'; $params[] = $dateTo . ' 23:59:59'; }
    if ($search) {
        $where .= ' AND (l.reference LIKE ? OR cu.name LIKE ? OR cu.phone LIKE ?)';
        $params = array_merge($params, array_fill(0, 3, "%$search%"));
    }

    $base = 'FROM leads l JOIN customers cu ON cu.id = l.customer_id WHERE ' . $where;
    $total = (int) fetchValue("SELECT COUNT(*) $base", $params);
    $ids = array_column(
        fetchAll("SELECT l.id $base ORDER BY l.id DESC LIMIT ? OFFSET ?", array_merge($params, [$pageSize, $offset])),
        'id'
    );

    $items = array_map(fn($id) => lead_out((int) $id), $ids);
    respond(pageEnvelope($items, $total, $page, $pageSize));
}];

$routes[] = ['POST', '/leads/{id}/convert', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $lead = lead_require((int) $p['id']);
    if (array_key_exists('delivery_pincode', $body)) {
        validatePincode($body['delivery_pincode']);
    }
    $orderId = lead_convert($lead, $body, $staff);
    respond(order_out($orderId), 201);
}];

$routes[] = ['GET', '/leads/{id}', function ($p) {
    requireAuth();
    respond(lead_out((int) $p['id']));
}];

$routes[] = ['PATCH', '/leads/{id}', function ($p) {
    $agent = requireAuth();
    $body = getBody();
    $lead = lead_require((int) $p['id']);

    if ($lead['status'] === 'converted' && array_key_exists('status', $body)) {
        error("A converted lead's status is fixed. Work on the bill instead.", 409);
    }

    if (array_key_exists('agent_id', $body) && $body['agent_id'] !== null) {
        $target = fetchOne('SELECT id FROM agents WHERE id = ? AND deleted_at IS NULL', [(int) $body['agent_id']]);
        if (!$target) {
            error("Agent {$body['agent_id']} does not exist or is inactive.", 422);
        }
    }

    $sets = [];
    $params = [];
    $described = [];
    if (array_key_exists('agent_id', $body)) {
        $sets[] = 'agent_id = ?';
        $params[] = $body['agent_id'];
        $described[] = $body['agent_id'] === null ? 'assigned to common pool' : "agent={$body['agent_id']}";
    }
    if (array_key_exists('status', $body)) { $sets[] = 'status = ?'; $params[] = strtolower($body['status']); $described[] = 'status=' . strtolower($body['status']); }
    if (array_key_exists('source', $body)) { $sets[] = 'source = ?'; $params[] = strtolower($body['source']); $described[] = 'source=' . strtolower($body['source']); }
    if (array_key_exists('notes', $body)) { $sets[] = 'notes = ?'; $params[] = $body['notes']; $described[] = 'notes'; }
    if (array_key_exists('campaign', $body)) { $sets[] = 'campaign = ?'; $params[] = $body['campaign']; $described[] = 'campaign'; }
    if ($sets) {
        $params[] = (int) $p['id'];
        execute('UPDATE leads SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
    }

    // Patch the shared customer record — only non-null keys are applied.
    if (!empty($body['customer']) && is_array($body['customer'])) {
        $applied = array_filter(
            array_intersect_key($body['customer'], array_flip(['name', 'email', 'address', 'city', 'pincode'])),
            fn($v) => $v !== null
        );
        if (isset($applied['pincode'])) {
            validatePincode($applied['pincode']);
        }
        if ($applied) {
            $cSets = [];
            $cParams = [];
            foreach ($applied as $f => $v) {
                $cSets[] = "$f = ?";
                $cParams[] = $v;
            }
            $cParams[] = (int) $lead['customer_id'];
            execute('UPDATE customers SET ' . implode(', ', $cSets) . ' WHERE id = ?', $cParams);
            $described[] = 'customer(' . implode(', ', array_keys($applied)) . ')';
        }
    }

    audit_log('lead.update', 'lead', $lead['reference'], implode(' · ', $described) ?: 'no change', $agent, clientIp());
    respond(lead_out((int) $p['id']));
}];

$routes[] = ['DELETE', '/leads/{id}', function ($p) {
    $staff = requireManager();
    $lead = lead_require((int) $p['id']);

    // A confirmed lead has a bill behind it. Deleting the lead also trashes that
    // bill so the two never disagree. Both are soft deletes (deleted_at), so the
    // bill can still be restored from the Bills screen if this was a mistake.
    $order = fetchOne('SELECT id, bill_no FROM orders WHERE lead_id = ? AND deleted_at IS NULL LIMIT 1', [(int) $p['id']]);
    if ($order) {
        execute('UPDATE orders SET deleted_at = NOW() WHERE id = ?', [(int) $order['id']]);
        audit_log('order.delete', 'order', $order['bill_no'], "Trashed with lead {$lead['reference']}", $staff, clientIp());
    }

    execute('UPDATE leads SET deleted_at = NOW() WHERE id = ?', [(int) $p['id']]);
    $detail = $order
        ? "{$lead['reference']} and bill {$order['bill_no']} moved to trash."
        : "{$lead['reference']} moved to trash.";
    audit_log('lead.delete', 'lead', $lead['reference'], $order ? "Moved to trash with bill {$order['bill_no']}" : 'Moved to trash', $staff, clientIp());
    respond(['detail' => $detail]);
}];
