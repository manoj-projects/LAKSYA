<?php
// Auth routes: sign in, identity, password change.

/** Shapes an agent row into the AgentOut response object. */
function formatAgent(array $a): array
{
    return [
        'id' => (int) $a['id'],
        'code' => $a['code'],
        'name' => $a['name'],
        'phone' => $a['phone'],
        'email' => $a['email'],
        'area' => $a['area'],
        'role' => strtolower($a['role']),
        'commission_pct' => money($a['commission_pct']),
        'notes' => $a['notes'],
        'is_active' => (bool) $a['is_active'],
        'can_login' => !empty($a['password_hash']) && (bool) $a['is_active'] && $a['deleted_at'] === null,
        'created_at' => $a['created_at'],
    ];
}

$routes[] = ['POST', '/auth/login', function () {
    $body = getBody();
    $phone = $body['phone'] ?? '';
    $password = $body['password'] ?? '';

    // One message for every failure mode, so this cannot enumerate registered numbers.
    $invalid = fn() => error('Incorrect phone or password.', 401);

    if (!$phone || !$password) {
        $invalid();
    }

    $agent = fetchOne(
        'SELECT * FROM agents WHERE phone = ? AND is_active = 1 AND deleted_at IS NULL',
        [$phone]
    );
    $canLogin = $agent && !empty($agent['password_hash']);
    if (!$canLogin || strlen($password) > MAX_PASSWORD_BYTES || !password_verify($password, $agent['password_hash'])) {
        $invalid();
    }

    audit_log('auth.login', 'agent', $agent['id'], 'Signed in', $agent, clientIp());

    respond([
        'access_token' => create_access_token((string) $agent['id'], strtolower($agent['role'])),
        'token_type' => 'bearer',
        'expires_in' => ACCESS_TOKEN_MINUTES * 60,
        'agent' => formatAgent($agent),
    ]);
}];

$routes[] = ['GET', '/auth/me', function () {
    $agent = requireAuth();
    respond(formatAgent($agent));
}];

$routes[] = ['POST', '/auth/change-password', function () {
    $agent = requireAuth();
    $body = getBody();
    $current = $body['current_password'] ?? '';
    $new = $body['new_password'] ?? '';

    if (!password_verify($current, $agent['password_hash'] ?? '')) {
        error('Current password is incorrect.', 400);
    }
    if ($new === $current) {
        error('New password must differ from the current one.', 400);
    }
    if (strlen($new) < 8) {
        error('New password must be at least 8 characters.', 422);
    }
    if (strlen($new) > MAX_PASSWORD_BYTES) {
        error('Password must be at most ' . MAX_PASSWORD_BYTES . ' bytes.', 422);
    }

    execute('UPDATE agents SET password_hash = ?, password_plain = ? WHERE id = ?', [
        password_hash($new, PASSWORD_BCRYPT),
        $new,
        $agent['id'],
    ]);
    audit_log('auth.password_change', 'agent', $agent['id'], 'Changed own password', $agent, clientIp());
    respond(['detail' => 'Password updated.']);
}];
