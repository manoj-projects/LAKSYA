<?php
// Agent management. Admin-only, apart from the leaderboard (manager+) and reads.

$routes[] = ['GET', '/agents', function () {
    $caller = requireAuth();
    $isAdmin = strtolower($caller['role']) === 'admin';
    [$page, $pageSize, $offset] = pageParams();
    $search = qp('search');
    $role = qp('role');
    $isActive = qpBool('is_active');
    // Admins can ask to see removed agents too (so they can review or restore them).
    $includeDeleted = $isAdmin && qpBool('include_deleted') === true;

    $where = $includeDeleted ? '1=1' : 'deleted_at IS NULL';
    $params = [];
    if ($search) {
        $where .= ' AND (name LIKE ? OR phone LIKE ? OR code LIKE ? OR area LIKE ?)';
        $params = array_merge($params, array_fill(0, 4, "%$search%"));
    }
    if ($role) {
        $where .= ' AND role = ?';
        $params[] = strtolower($role);
    }
    if ($isActive !== null) {
        $where .= ' AND is_active = ?';
        $params[] = $isActive ? 1 : 0;
    }

    $total = (int) fetchValue("SELECT COUNT(*) FROM agents WHERE $where", $params);
    $rows = fetchAll(
        "SELECT * FROM agents WHERE $where ORDER BY name LIMIT ? OFFSET ?",
        array_merge($params, [$pageSize, $offset])
    );
    // The plaintext login is only ever revealed to an admin, so an agent hitting
    // this API cannot read another agent's password.
    $items = array_map(function ($a) use ($isAdmin) {
        $out = formatAgent($a);
        if ($isAdmin) {
            $out['password_plain'] = $a['password_plain'];
            $out['deleted_at'] = $a['deleted_at'];
        }
        return $out;
    }, $rows);
    respond(pageEnvelope($items, $total, $page, $pageSize));
}];

/**
 * Returns a code that is free across the WHOLE table (active + soft-deleted), so an
 * INSERT/UPDATE can never trip the UNIQUE index on agents.code. Falls back to an
 * auto-generated PP-AG-N when the preferred code is blank or already taken.
 * $excludeId lets the row being revived keep/replace its own code.
 */
function agents_free_code(string $preferred, int $excludeId = 0): string
{
    $taken = function (string $c) use ($excludeId): bool {
        return (int) fetchValue('SELECT COUNT(*) FROM agents WHERE code = ? AND id <> ?', [$c, $excludeId]) > 0;
    };
    $c = strtoupper(trim($preferred));
    if ($c !== '' && strlen($c) <= 16 && !$taken($c)) {
        return $c;
    }
    for ($n = 1; $n <= 100000; $n++) {
        $cand = 'PP-AG-' . $n; // stays within VARCHAR(16)
        if (!$taken($cand)) {
            return $cand;
        }
    }
    return substr('AG' . time(), 0, 16);
}

$routes[] = ['POST', '/agents', function () {
    $admin = requireAdmin();
    $body = getBody();

    $hash = null;
    if (!empty($body['password'])) {
        if (strlen($body['password']) < 8 || strlen($body['password']) > MAX_PASSWORD_BYTES) {
            error('Password must be between 8 and ' . MAX_PASSWORD_BYTES . ' characters.', 422);
        }
        $hash = password_hash($body['password'], PASSWORD_BCRYPT);
    }

    $phone = $body['phone'] ?? '';
    $email = $body['email'] ?: null;
    $role = strtolower($body['role'] ?? 'agent');
    $plain = !empty($body['password']) ? $body['password'] : null;
    validatePhone($phone);

    // Only a LIVE agent on the same phone (or email) is a genuine clash. The code
    // is auto-corrected below, so it never causes a failure.
    $active = fetchOne(
        "SELECT id FROM agents WHERE deleted_at IS NULL
           AND (phone = ? OR (email IS NOT NULL AND email = ?)) LIMIT 1",
        [$phone, $email]
    );
    if ($active) {
        error('An active agent already uses that phone or email.', 409);
    }

    // Removing an agent is a soft delete, so its phone/code/email still occupy the
    // unique indexes. Re-adding the same phone REVIVES that record; otherwise we
    // insert fresh. In both cases the code is guaranteed unique first.
    $revive = fetchOne(
        'SELECT * FROM agents WHERE deleted_at IS NOT NULL AND phone = ? ORDER BY id DESC LIMIT 1',
        [$phone]
    );
    $excludeId = $revive ? (int) $revive['id'] : 0;
    $code = agents_free_code($body['code'] ?? '', $excludeId);

    // Free an email held by any *other* soft-deleted row (email is unique).
    if ($email) {
        execute('UPDATE agents SET email = NULL WHERE deleted_at IS NOT NULL AND email = ? AND id <> ?', [$email, $excludeId]);
    }

    if ($revive) {
        execute(
            'UPDATE agents SET code = ?, name = ?, email = ?, area = ?, role = ?,
                    password_hash = ?, password_plain = ?, commission_pct = ?, notes = ?,
                    is_active = 1, deleted_at = NULL WHERE id = ?',
            [$code, $body['name'] ?? '', $email, $body['area'] ?? null, $role,
             $hash, $plain, $body['commission_pct'] ?? '0', $body['notes'] ?? null, $excludeId]
        );
        $id = $excludeId;
    } else {
        $id = insertId(
            'INSERT INTO agents (code, name, phone, email, area, role, password_hash, password_plain, commission_pct, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$code, $body['name'] ?? '', $phone, $email, $body['area'] ?? null, $role,
             $hash, $plain, $body['commission_pct'] ?? '0', $body['notes'] ?? null]
        );
    }

    $agent = fetchOne('SELECT * FROM agents WHERE id = ?', [$id]);
    audit_log('agent.create', 'agent', $id, "{$agent['code']} {$agent['name']} as {$agent['role']}", $admin, clientIp());
    respond(formatAgent($agent), 201);
}];

$routes[] = ['GET', '/agents/performance', function () {
    requireManager();
    $rows = fetchAll(
        "SELECT a.id AS agent_id, a.code, a.name, a.commission_pct,
                COALESCE(o.cnt, 0) AS orders,
                COALESCE(o.revenue, 0) AS revenue,
                COALESCE(o.collected, 0) AS collected,
                COALESCE(l.cnt, 0) AS leads,
                COALESCE(l.converted, 0) AS converted_leads
         FROM agents a
         LEFT JOIN (
             SELECT agent_id, COUNT(*) AS cnt, SUM(total) AS revenue, SUM(amount_paid) AS collected
             FROM orders
             WHERE deleted_at IS NULL AND status IN ('confirmed','packed','dispatched','delivered')
             GROUP BY agent_id
         ) o ON o.agent_id = a.id
         LEFT JOIN (
             SELECT agent_id, COUNT(*) AS cnt,
                    SUM(CASE WHEN status='converted' THEN 1 ELSE 0 END) AS converted
             FROM leads WHERE deleted_at IS NULL GROUP BY agent_id
         ) l ON l.agent_id = a.id
         WHERE a.deleted_at IS NULL
         ORDER BY COALESCE(o.revenue, 0) DESC, a.name"
    );

    respond(array_map(function ($r) {
        $rev = (float) $r['revenue'];
        $pct = (float) $r['commission_pct'];
        return [
            'agent_id' => (int) $r['agent_id'],
            'code' => $r['code'],
            'name' => $r['name'],
            'orders' => (int) $r['orders'],
            'revenue' => money($rev),
            'collected' => money($r['collected']),
            'commission_pct' => money($pct),
            'commission_due' => money(round($rev * $pct / 100, 2, PHP_ROUND_HALF_UP)),
            'leads' => (int) $r['leads'],
            'converted_leads' => (int) $r['converted_leads'],
        ];
    }, $rows));
}];

// Self-service dashboard for the signed-in agent: their sales, collections,
// commission, tagged clients, and their rank on the leaderboard. Any authenticated
// staffer can call it; it only ever reports the caller's own scoped figures.
$routes[] = ['GET', '/agents/me/summary', function () {
    $me = requireAuth();
    $id = (int) $me['id'];
    $pct = (float) $me['commission_pct'];

    // My sales and collections.
    $o = fetchOne(
        "SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS revenue, COALESCE(SUM(amount_paid),0) AS collected
         FROM orders
         WHERE agent_id = ? AND deleted_at IS NULL
           AND status IN ('confirmed','packed','dispatched','delivered')",
        [$id]
    );
    $revenue = (float) $o['revenue'];
    $collected = (float) $o['collected'];
    $outstanding = max(0, $revenue - $collected);

    // Commission earned on revenue, minus what has already been paid out.
    $earned = round($revenue * $pct / 100, 2, PHP_ROUND_HALF_UP);
    $paid = (float) fetchValue('SELECT COALESCE(SUM(amount),0) FROM commission_payouts WHERE agent_id = ?', [$id]);
    $due = max(0, $earned - $paid);

    // My leads.
    $l = fetchOne(
        "SELECT COUNT(*) AS cnt, COALESCE(SUM(CASE WHEN status='converted' THEN 1 ELSE 0 END),0) AS converted
         FROM leads WHERE agent_id = ? AND deleted_at IS NULL",
        [$id]
    );

    // Clients tagged to me, with what they owe.
    $clients = fetchAll(
        "SELECT c.name, c.phone,
                COUNT(*) AS bills,
                COALESCE(SUM(o.total),0) AS total,
                COALESCE(SUM(o.amount_paid),0) AS paid,
                COALESCE(SUM(o.total - o.amount_paid),0) AS balance
         FROM orders o JOIN customers c ON c.id = o.customer_id
         WHERE o.agent_id = ? AND o.deleted_at IS NULL
           AND o.status IN ('confirmed','packed','dispatched','delivered')
         GROUP BY c.id, c.name, c.phone
         ORDER BY total DESC",
        [$id]
    );

    // Leaderboard of selling staff by revenue. The bootstrap owner account (code
    // ADMIN) is excluded; everyone else's revenue is shown so agents can compare.
    $board = fetchAll(
        "SELECT a.id, a.name, COALESCE(o.revenue,0) AS revenue, COALESCE(o.cnt,0) AS bills
         FROM agents a
         LEFT JOIN (
             SELECT agent_id, COUNT(*) AS cnt, SUM(total) AS revenue FROM orders
             WHERE deleted_at IS NULL AND status IN ('confirmed','packed','dispatched','delivered')
             GROUP BY agent_id
         ) o ON o.agent_id = a.id
         WHERE a.deleted_at IS NULL AND a.is_active = 1 AND a.code <> 'ADMIN'
         ORDER BY COALESCE(o.revenue,0) DESC, a.name"
    );
    $leaderboard = [];
    $position = 0;
    $i = 0;
    foreach ($board as $b) {
        $i++;
        $mine = (int) $b['id'] === $id;
        if ($mine) {
            $position = $i;
        }
        $leaderboard[] = [
            'rank' => $i,
            'name' => $b['name'],
            'revenue' => money($b['revenue']),
            'bills' => (int) $b['bills'],
            'is_me' => $mine,
        ];
    }

    respond([
        'me' => [
            'id' => $id,
            'name' => $me['name'],
            'code' => $me['code'],
            'commission_pct' => money($pct),
        ],
        'bills' => (int) $o['cnt'],
        'revenue' => money($revenue),
        'collected' => money($collected),
        'outstanding' => money($outstanding),
        'commission_earned' => money($earned),
        'commission_paid' => money($paid),
        'commission_due' => money($due),
        'leads' => (int) $l['cnt'],
        'converted_leads' => (int) $l['converted'],
        'rank' => $position,
        'agent_count' => count($board),
        'leaderboard' => $leaderboard,
        'clients' => array_map(fn($c) => [
            'name' => $c['name'],
            'phone' => $c['phone'],
            'bills' => (int) $c['bills'],
            'total' => money($c['total']),
            'paid' => money($c['paid']),
            'balance' => money($c['balance']),
        ], $clients),
    ]);
}];

$routes[] = ['GET', '/agents/{id}', function ($p) {
    requireManager();
    $agent = fetchOne('SELECT * FROM agents WHERE id = ? AND deleted_at IS NULL', [(int) $p['id']]);
    if (!$agent) {
        error("Agent {$p['id']} not found.", 404);
    }
    respond(formatAgent($agent));
}];

/** Guards against removing or demoting the last active admin. */
function agents_last_admin_check(int $exceptId): void
{
    $remaining = (int) fetchValue(
        "SELECT COUNT(*) FROM agents WHERE role='admin' AND is_active=1 AND deleted_at IS NULL AND id != ?",
        [$exceptId]
    );
    if ($remaining === 0) {
        error('This is the last active admin. Promote another admin first.', 409);
    }
}

$routes[] = ['PATCH', '/agents/{id}', function ($p) {
    $admin = requireAdmin();
    $body = getBody();
    $agent = fetchOne('SELECT * FROM agents WHERE id = ? AND deleted_at IS NULL', [(int) $p['id']]);
    if (!$agent) {
        error("Agent {$p['id']} not found.", 404);
    }

    // Last-admin guard: refuse demoting or deactivating the final admin.
    $newRole = array_key_exists('role', $body) ? strtolower($body['role']) : null;
    $deactivating = array_key_exists('is_active', $body) && !$body['is_active'];
    if (strtolower($agent['role']) === 'admin' && (($newRole !== null && $newRole !== 'admin') || $deactivating)) {
        agents_last_admin_check((int) $agent['id']);
    }

    if (array_key_exists('phone', $body) && $body['phone'] !== null) {
        validatePhone($body['phone']);
    }

    $sets = [];
    $params = [];
    $described = [];
    foreach (['name', 'phone', 'email', 'area', 'notes'] as $f) {
        if (array_key_exists($f, $body)) {
            $sets[] = "$f = ?";
            $params[] = $body[$f];
            $described[] = "$f={$body[$f]}";
        }
    }
    if (array_key_exists('role', $body)) {
        $sets[] = 'role = ?';
        $params[] = strtolower($body['role']);
        $described[] = 'role=' . strtolower($body['role']);
    }
    if (array_key_exists('commission_pct', $body)) {
        $sets[] = 'commission_pct = ?';
        $params[] = $body['commission_pct'];
        $described[] = "commission_pct={$body['commission_pct']}";
    }
    if (array_key_exists('is_active', $body)) {
        $sets[] = 'is_active = ?';
        $params[] = $body['is_active'] ? 1 : 0;
        $described[] = 'is_active=' . ($body['is_active'] ? '1' : '0');
    }

    if ($sets) {
        $params[] = (int) $p['id'];
        try {
            execute('UPDATE agents SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
        } catch (PDOException $e) {
            error('Another agent already uses that phone or email.', 409);
        }
    }

    audit_log('agent.update', 'agent', $p['id'], implode(', ', $described) ?: 'no change', $admin, clientIp());
    $agent = fetchOne('SELECT * FROM agents WHERE id = ?', [(int) $p['id']]);
    respond(formatAgent($agent));
}];

$routes[] = ['POST', '/agents/{id}/password', function ($p) {
    $admin = requireAdmin();
    $body = getBody();
    $new = $body['new_password'] ?? '';
    if (strlen($new) < 8 || strlen($new) > MAX_PASSWORD_BYTES) {
        error('Password must be between 8 and ' . MAX_PASSWORD_BYTES . ' characters.', 422);
    }
    $agent = fetchOne('SELECT * FROM agents WHERE id = ? AND deleted_at IS NULL', [(int) $p['id']]);
    if (!$agent) {
        error("Agent {$p['id']} not found.", 404);
    }
    execute('UPDATE agents SET password_hash = ?, password_plain = ? WHERE id = ?', [password_hash($new, PASSWORD_BCRYPT), $new, (int) $p['id']]);
    audit_log('agent.password_reset', 'agent', $p['id'], "Password changed to \"$new\" by {$admin['code']}", $admin, clientIp());
    respond(['detail' => "Password set for {$agent['name']}."]);
}];

$routes[] = ['DELETE', '/agents/{id}', function ($p) {
    $admin = requireAdmin();
    $agent = fetchOne('SELECT * FROM agents WHERE id = ? AND deleted_at IS NULL', [(int) $p['id']]);
    if (!$agent) {
        error("Agent {$p['id']} not found.", 404);
    }
    if ((int) $agent['id'] === (int) $admin['id']) {
        error('You cannot remove your own account.', 409);
    }
    if (strtolower($agent['role']) === 'admin') {
        agents_last_admin_check((int) $agent['id']);
    }
    execute('UPDATE agents SET is_active = 0, deleted_at = NOW() WHERE id = ?', [(int) $p['id']]);
    audit_log('agent.delete', 'agent', $p['id'], "Deactivated {$agent['code']}", $admin, clientIp());
    respond(['detail' => "{$agent['name']} deactivated."]);
}];

$routes[] = ['POST', '/agents/{id}/restore', function ($p) {
    $admin = requireAdmin();
    $agent = fetchOne('SELECT * FROM agents WHERE id = ?', [(int) $p['id']]);
    if (!$agent) {
        error("Agent {$p['id']} not found.", 404);
    }
    // Refuse if a live agent has since taken this one's phone/code/email.
    $clash = fetchOne(
        "SELECT id FROM agents WHERE deleted_at IS NULL AND id <> ?
           AND (phone = ? OR code = ? OR (email IS NOT NULL AND email = ?)) LIMIT 1",
        [(int) $agent['id'], $agent['phone'], $agent['code'], $agent['email']]
    );
    if ($clash) {
        error('Another active agent now uses this phone, code, or email. Change theirs first.', 409);
    }
    execute('UPDATE agents SET is_active = 1, deleted_at = NULL WHERE id = ?', [(int) $p['id']]);
    audit_log('agent.restore', 'agent', $p['id'], "Restored {$agent['code']} {$agent['name']}", $admin, clientIp());
    respond(['detail' => "{$agent['name']} restored."]);
}];
