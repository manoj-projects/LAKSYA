<?php
// Customer directory with lifetime figures.

$routes[] = ['GET', '/customers', function () {
    requireAuth();
    [$page, $pageSize, $offset] = pageParams();
    $search = qp('search');
    $pincode = qp('pincode');

    $where = 'c.deleted_at IS NULL';
    $params = [];
    if ($search) {
        $where .= ' AND (c.name LIKE ? OR c.phone LIKE ? OR c.city LIKE ?)';
        $params = array_merge($params, array_fill(0, 3, "%$search%"));
    }
    if ($pincode) {
        validatePincode($pincode);
        $where .= ' AND c.pincode = ?';
        $params[] = $pincode;
    }

    $joined = "FROM customers c
        LEFT JOIN (
            SELECT customer_id, COUNT(*) AS cnt, COALESCE(SUM(total),0) AS val, MAX(created_at) AS last_at
            FROM orders
            WHERE deleted_at IS NULL AND status IN ('confirmed','packed','dispatched','delivered')
            GROUP BY customer_id
        ) o ON o.customer_id = c.id
        WHERE $where";

    $total = (int) fetchValue("SELECT COUNT(*) FROM customers c WHERE $where", $params);
    $rows = fetchAll(
        "SELECT c.*, COALESCE(o.cnt,0) AS order_count, COALESCE(o.val,0) AS lifetime_value, o.last_at AS last_order_at
         $joined ORDER BY COALESCE(o.val,0) DESC, c.id DESC LIMIT ? OFFSET ?",
        array_merge($params, [$pageSize, $offset])
    );

    $items = array_map(function ($c) {
        return customer_out($c) + [
            'order_count' => (int) $c['order_count'],
            'lifetime_value' => money($c['lifetime_value']),
            'last_order_at' => $c['last_order_at'],
        ];
    }, $rows);
    respond(pageEnvelope($items, $total, $page, $pageSize));
}];

$routes[] = ['POST', '/customers', function () {
    $staff = requireManager();
    $body = getBody();
    $id = customer_get_or_create($body);
    $customer = fetchOne('SELECT * FROM customers WHERE id = ?', [$id]);
    audit_log('customer.upsert', 'customer', $id,
        trim($customer['phone'] . ' ' . ($customer['name'] ?? '')), $staff, clientIp());
    respond(customer_out($customer), 201);
}];

$routes[] = ['GET', '/customers/{id}', function ($p) {
    requireAuth();
    respond(customer_out(customer_require((int) $p['id'])));
}];

$routes[] = ['PATCH', '/customers/{id}', function ($p) {
    $staff = requireManager();
    $body = getBody();
    $customer = customer_require((int) $p['id']);

    if (array_key_exists('pincode', $body)) {
        validatePincode($body['pincode']);
    }
    // Phone is the natural key but may be corrected; validate and let the UNIQUE
    // index guard against collisions (caught below as a 409).
    if (array_key_exists('phone', $body)) {
        $body['phone'] = validatePhone($body['phone']);
    }

    $sets = [];
    $params = [];
    foreach (['name', 'phone', 'email', 'address', 'city', 'pincode', 'notes'] as $f) {
        if (array_key_exists($f, $body)) {
            $sets[] = "$f = ?";
            $params[] = $body[$f];
        }
    }
    if ($sets) {
        $params[] = (int) $p['id'];
        try {
            execute('UPDATE customers SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
        } catch (PDOException $e) {
            error('Could not update the customer — a conflicting value was supplied.', 409);
        }
    }
    audit_log('customer.update', 'customer', $p['id'], implode(', ', array_keys($body)) ?: 'no change', $staff, clientIp());
    respond(customer_out(fetchOne('SELECT * FROM customers WHERE id = ?', [(int) $p['id']])));
}];

$routes[] = ['DELETE', '/customers/{id}', function ($p) {
    $staff = requireManager();
    $customer = customer_require((int) $p['id']);

    $live = (int) fetchValue(
        'SELECT COUNT(*) FROM orders WHERE customer_id = ? AND deleted_at IS NULL',
        [(int) $p['id']]
    );
    if ($live) {
        error("$live live order(s) reference this customer.", 409);
    }
    execute('UPDATE customers SET deleted_at = NOW() WHERE id = ?', [(int) $p['id']]);
    audit_log('customer.delete', 'customer', $p['id'], "Soft-deleted {$customer['phone']}", $staff, clientIp());
    respond(['detail' => 'Customer removed.']);
}];
