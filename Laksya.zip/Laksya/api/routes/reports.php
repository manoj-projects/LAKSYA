<?php
// Reporting and the audit log. Revenue counts confirmed-or-later bills only.

/** Appends an inclusive date window to a WHERE clause for a timestamp column. */
function report_window(string $column, array &$params): string
{
    $clause = '';
    $from = qp('date_from');
    $to = qp('date_to');
    if ($from) {
        $clause .= " AND $column >= ?";
        $params[] = $from . ' 00:00:00';
    }
    if ($to) {
        $clause .= " AND $column <= ?";
        $params[] = $to . ' 23:59:59';
    }
    return $clause;
}

function report_pct(int|float $n, int|float $d): int
{
    return $d ? (int) round($n / $d * 100) : 0;
}

$routes[] = ['GET', '/reports/summary', function () {
    // Shop-wide revenue is manager+ only; agents use /agents/me/summary instead.
    requireManager();
    $from = qp('date_from');
    $to = qp('date_to');

    // ---- orders in revenue statuses
    $p = [];
    $w = report_window('created_at', $p);
    $o = fetchOne(
        "SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS revenue,
                COALESCE(SUM(amount_paid),0) AS collected, COALESCE(SUM(item_count),0) AS pieces
         FROM orders
         WHERE deleted_at IS NULL AND status IN ('confirmed','packed','dispatched','delivered') $w",
        $p
    );
    $orders = (int) $o['cnt'];
    $revenue = (float) $o['revenue'];
    $collected = (float) $o['collected'];

    // ---- leads
    $p = [];
    $w = report_window('created_at', $p);
    $l = fetchOne(
        "SELECT COUNT(*) AS cnt,
                COALESCE(SUM(CASE WHEN status='converted' THEN 1 ELSE 0 END),0) AS converted,
                COALESCE(SUM(CASE WHEN status='lost' THEN 1 ELSE 0 END),0) AS lost
         FROM leads WHERE deleted_at IS NULL $w",
        $p
    );
    $leads = (int) $l['cnt'];
    $converted = (int) $l['converted'];
    $lostLeads = (int) $l['lost'];

    // ---- outcome breakdown across every non-deleted bill
    $p = [];
    $w = report_window('created_at', $p);
    $counts = [];
    $values = [];
    foreach (fetchAll(
        "SELECT status, COUNT(*) AS cnt, COALESCE(SUM(total),0) AS value
         FROM orders WHERE deleted_at IS NULL $w GROUP BY status",
        $p
    ) as $row) {
        $counts[$row['status']] = (int) $row['cnt'];
        $values[$row['status']] = (float) $row['value'];
    }
    $delivered = $counts['delivered'] ?? 0;
    $cancelled = $counts['cancelled'] ?? 0;
    $draft = $counts['draft'] ?? 0;
    $inProgress = ($counts['confirmed'] ?? 0) + ($counts['packed'] ?? 0) + ($counts['dispatched'] ?? 0);
    $inProgressValue = ($values['confirmed'] ?? 0) + ($values['packed'] ?? 0) + ($values['dispatched'] ?? 0);
    $decided = $delivered + $cancelled + $inProgress;

    // ---- new customers
    $p = [];
    $w = report_window('created_at', $p);
    $newCustomers = (int) fetchValue("SELECT COUNT(*) FROM customers WHERE deleted_at IS NULL $w", $p);

    // ---- stock alerts (point-in-time, ignores the window)
    $alerts = fetchOne(
        "SELECT
            COALESCE(SUM(CASE WHEN (s.on_hand - COALESCE(cm.qty,0)) <= 0 THEN 1 ELSE 0 END),0) AS out_of_stock,
            COALESCE(SUM(CASE WHEN (s.on_hand - COALESCE(cm.qty,0)) > 0
                          AND (s.on_hand - COALESCE(cm.qty,0)) <= s.reorder_level THEN 1 ELSE 0 END),0) AS low_stock
         FROM stock_items s
         JOIN products p ON p.id = s.product_id
         LEFT JOIN (
             SELECT oi.product_id, SUM(oi.qty) AS qty
             FROM order_items oi JOIN orders o ON o.id = oi.order_id
             WHERE o.status IN ('confirmed','packed') AND o.deleted_at IS NULL
             GROUP BY oi.product_id
         ) cm ON cm.product_id = s.product_id
         WHERE p.deleted_at IS NULL"
    );

    respond([
        'period_from' => $from ?: null,
        'period_to' => $to ?: null,
        'leads' => $leads,
        'converted_leads' => $converted,
        'lost_leads' => $lostLeads,
        'open_leads' => max(0, $leads - $converted - $lostLeads),
        'conversion_pct' => report_pct($converted, $leads),
        'orders' => $orders,
        'revenue' => money($revenue),
        'collected' => money($collected),
        'outstanding' => money($revenue - $collected),
        'average_order_value' => money($orders ? round($revenue / $orders, 2, PHP_ROUND_HALF_UP) : 0),
        'pieces_sold' => (int) $o['pieces'],
        'delivered' => $delivered,
        'delivered_value' => money($values['delivered'] ?? 0),
        'in_progress' => $inProgress,
        'in_progress_value' => money($inProgressValue),
        'draft' => $draft,
        'cancelled' => $cancelled,
        'cancelled_value' => money($values['cancelled'] ?? 0),
        'fulfilment_pct' => report_pct($delivered, $decided),
        'new_customers' => $newCustomers,
        'low_stock_count' => (int) $alerts['low_stock'],
        'out_of_stock_count' => (int) $alerts['out_of_stock'],
    ]);
}];

$routes[] = ['GET', '/reports/status-breakdown', function () {
    requireManager();
    $from = qp('date_from');
    $to = qp('date_to');

    $p = [];
    $w = report_window('created_at', $p);
    $orderRows = [];
    foreach (fetchAll(
        "SELECT status, COUNT(*) AS cnt, COALESCE(SUM(total),0) AS value
         FROM orders WHERE deleted_at IS NULL $w GROUP BY status",
        $p
    ) as $r) {
        $orderRows[$r['status']] = [(int) $r['cnt'], (float) $r['value']];
    }

    $p = [];
    $w = report_window('created_at', $p);
    $leadRows = [];
    foreach (fetchAll(
        "SELECT status, COUNT(*) AS cnt FROM leads WHERE deleted_at IS NULL $w GROUP BY status",
        $p
    ) as $r) {
        $leadRows[$r['status']] = (int) $r['cnt'];
    }

    $ORDER_LABELS = [
        'draft' => 'Draft', 'confirmed' => 'Confirmed', 'packed' => 'Packed',
        'dispatched' => 'On the way', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled',
    ];
    $LEAD_LABELS = [
        'new' => 'New', 'contacted' => 'Contacted', 'quoted' => 'Quoted',
        'converted' => 'Won', 'lost' => 'Lost',
    ];

    $ordersOut = [];
    foreach ($ORDER_LABELS as $key => $label) {
        [$cnt, $val] = $orderRows[$key] ?? [0, 0.0];
        $ordersOut[] = ['key' => $key, 'label' => $label, 'count' => $cnt, 'value' => money($val)];
    }
    $leadsOut = [];
    foreach ($LEAD_LABELS as $key => $label) {
        $leadsOut[] = ['key' => $key, 'label' => $label, 'count' => $leadRows[$key] ?? 0, 'value' => money(0)];
    }

    $of = fn($k) => $orderRows[$k] ?? [0, 0.0];
    [$deliveredCount, $deliveredValue] = $of('delivered');
    [$dispatchedCount, $dispatchedValue] = $of('dispatched');
    [$confirmedCount, $confirmedValue] = $of('confirmed');
    [$packedCount, $packedValue] = $of('packed');
    [$cancelledCount, $cancelledValue] = $of('cancelled');

    $preparingCount = $confirmedCount + $packedCount;
    $preparingValue = $confirmedValue + $packedValue;
    $totalBills = $deliveredCount + $dispatchedCount + $preparingCount + $cancelledCount;

    $won = $leadRows['converted'] ?? 0;
    $lost = $leadRows['lost'] ?? 0;
    $totalLeads = array_sum($leadRows);
    $openLeads = $totalLeads - $won - $lost;

    respond([
        'period_from' => $from ?: null,
        'period_to' => $to ?: null,
        'orders' => $ordersOut,
        'leads' => $leadsOut,
        'delivered_count' => $deliveredCount,
        'delivered_value' => money($deliveredValue),
        'in_transit_count' => $dispatchedCount,
        'in_transit_value' => money($dispatchedValue),
        'preparing_count' => $preparingCount,
        'preparing_value' => money($preparingValue),
        'cancelled_count' => $cancelledCount,
        'cancelled_value' => money($cancelledValue),
        'total_bills' => $totalBills,
        'delivered_pct' => report_pct($deliveredCount, $totalBills),
        'leads_won' => $won,
        'leads_open' => $openLeads,
        'leads_lost' => $lost,
        'total_leads' => $totalLeads,
        'leads_won_pct' => report_pct($won, $totalLeads),
        'leads_lost_pct' => report_pct($lost, $totalLeads),
    ]);
}];

$routes[] = ['GET', '/reports/leads-by-agent', function () {
    requireAuth();
    $p = [];
    $w = report_window('l.created_at', $p);
    $rows = fetchAll(
        "SELECT l.agent_id, MIN(a.code) AS code, MIN(a.name) AS name,
                COUNT(l.id) AS leads,
                COALESCE(SUM(CASE WHEN l.status='converted' THEN 1 ELSE 0 END),0) AS converted,
                COALESCE(SUM(CASE WHEN l.status='lost' THEN 1 ELSE 0 END),0) AS lost,
                COALESCE(SUM(l.total),0) AS value
         FROM leads l LEFT JOIN agents a ON a.id = l.agent_id
         WHERE l.deleted_at IS NULL $w
         GROUP BY l.agent_id",
        $p
    );

    $out = [];
    foreach ($rows as $r) {
        $count = (int) $r['leads'];
        $conv = (int) $r['converted'];
        $lost = (int) $r['lost'];
        $out[] = [
            'agent_id' => $r['agent_id'] !== null ? (int) $r['agent_id'] : null,
            'code' => $r['code'] ?? 'COMMON',
            'name' => $r['name'] ?? 'Common (unassigned)',
            'leads' => $count,
            'converted' => $conv,
            'lost' => $lost,
            'open_leads' => $count - $conv - $lost,
            'quoted_value' => money($r['value']),
            'conversion_pct' => report_pct($conv, $count),
        ];
    }
    // Common pool pinned to the top; then most leads first.
    usort($out, fn($a, $b) => [$a['agent_id'] !== null, -$a['leads']] <=> [$b['agent_id'] !== null, -$b['leads']]);
    respond($out);
}];

$routes[] = ['GET', '/reports/sales-daily', function () {
    requireManager();
    $limit = max(1, min(366, qpInt('limit', 60)));
    $p = [];
    $w = report_window('created_at', $p);
    $rows = fetchAll(
        "SELECT DATE(created_at) AS day, COUNT(*) AS orders, COALESCE(SUM(total),0) AS revenue
         FROM orders
         WHERE deleted_at IS NULL AND status IN ('confirmed','packed','dispatched','delivered') $w
         GROUP BY DATE(created_at) ORDER BY day DESC LIMIT $limit",
        $p
    );
    // Query is newest-first for the LIMIT; charts want oldest-first.
    $rows = array_reverse($rows);
    respond(array_map(fn($r) => [
        'day' => $r['day'],
        'orders' => (int) $r['orders'],
        'revenue' => money($r['revenue']),
    ], $rows));
}];

$routes[] = ['GET', '/reports/top-products', function () {
    requireAuth();
    $limit = max(1, min(100, qpInt('limit', 10)));
    $p = [];
    $w = report_window('o.created_at', $p);
    $rows = fetchAll(
        "SELECT oi.product_id, MIN(oi.product_code) AS product_code, MIN(oi.name) AS name,
                COALESCE(SUM(oi.qty),0) AS qty, COALESCE(SUM(oi.line_total),0) AS revenue
         FROM order_items oi JOIN orders o ON o.id = oi.order_id
         WHERE o.deleted_at IS NULL AND o.status IN ('confirmed','packed','dispatched','delivered') $w
         GROUP BY oi.product_id ORDER BY revenue DESC LIMIT $limit",
        $p
    );
    respond(array_map(fn($r) => [
        'product_id' => (int) $r['product_id'],
        'product_code' => $r['product_code'],
        'name' => $r['name'],
        'qty' => (int) $r['qty'],
        'revenue' => money($r['revenue']),
    ], $rows));
}];

$routes[] = ['GET', '/audit', function () {
    requireManager();
    [$page, $pageSize, $offset] = pageParams();
    $action = qp('action');
    $entity = qp('entity');
    $actorId = qp('actor_id');

    $where = '1=1';
    $params = [];
    if ($action) { $where .= ' AND action = ?'; $params[] = $action; }
    if ($entity) { $where .= ' AND entity = ?'; $params[] = $entity; }
    if ($actorId !== null) { $where .= ' AND actor_id = ?'; $params[] = (int) $actorId; }
    $where .= report_window('created_at', $params);

    $total = (int) fetchValue("SELECT COUNT(*) FROM audit_logs WHERE $where", $params);
    $rows = fetchAll(
        "SELECT * FROM audit_logs WHERE $where ORDER BY id DESC LIMIT ? OFFSET ?",
        array_merge($params, [$pageSize, $offset])
    );
    $items = array_map(fn($r) => [
        'id' => (int) $r['id'],
        'actor_id' => $r['actor_id'] !== null ? (int) $r['actor_id'] : null,
        'actor_label' => $r['actor_label'],
        'action' => $r['action'],
        'entity' => $r['entity'],
        'entity_id' => $r['entity_id'],
        'detail' => $r['detail'],
        'ip_address' => $r['ip_address'],
        'created_at' => $r['created_at'],
    ], $rows);
    respond(pageEnvelope($items, $total, $page, $pageSize));
}];
