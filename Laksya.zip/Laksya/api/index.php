<?php
/**
 * Single entry point for every /api/v1/* request.
 *
 * .htaccess rewrites all non-file requests here. The whole request runs inside
 * one database transaction: it commits only if the handler reaches respond(),
 * and rolls back on any error or business-rule rejection. This mirrors the
 * FastAPI get_db dependency so audit rows stay consistent with their change.
 */

require_once __DIR__ . '/helpers.php';

// Service + route dependencies.
require_once __DIR__ . '/lib/audit.php';
require_once __DIR__ . '/lib/pricing.php';
require_once __DIR__ . '/lib/numbering.php';
require_once __DIR__ . '/lib/customers.php';
require_once __DIR__ . '/lib/inventory.php';
require_once __DIR__ . '/lib/orders.php';
require_once __DIR__ . '/lib/leads.php';

handleCORS();

// Commit on success (respond() sets the flag), roll back on anything else.
$GLOBALS['__request_ok'] = false;
register_shutdown_function(static function (): void {
    if (!empty($GLOBALS['__request_ok'])) {
        commit();
    } else {
        rollback();
    }
});

// ---- Resolve the route path, tolerant of whatever folder prefix is deployed.
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$path = parse_url($requestUri, PHP_URL_PATH) ?? '/';
$pos = strpos($path, '/v1');
if ($pos !== false) {
    $path = substr($path, $pos + 3); // everything after ".../v1"
}
$path = rtrim($path, '/');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- Register every route.
$routes = [];
require_once __DIR__ . '/routes/auth.php';
require_once __DIR__ . '/routes/agents.php';
require_once __DIR__ . '/routes/products.php';
require_once __DIR__ . '/routes/customers.php';
require_once __DIR__ . '/routes/leads.php';
require_once __DIR__ . '/routes/orders.php';
require_once __DIR__ . '/routes/inventory.php';
require_once __DIR__ . '/routes/reports.php';
require_once __DIR__ . '/routes/finance.php';

// ---- Health check.
if ($path === '/health' || $path === '') {
    getDB(); // real connection check
    respond(['status' => 'ok', 'environment' => APP_ENVIRONMENT]);
}

// ---- Dispatch, wrapped so service exceptions become clean HTTP responses.
try {
    beginTransaction();

    foreach ($routes as [$routeMethod, $pattern, $handler]) {
        if ($method !== $routeMethod) {
            continue;
        }
        $regex = '#^' . preg_replace('/\{(\w+)\}/', '(?P<$1>[^/]+)', $pattern) . '$#';
        if (preg_match($regex, $path, $matches)) {
            $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
            $handler($params);
            exit; // handler always ends in respond()/error()
        }
    }

    error('Not found', 404);
} catch (ApiException $e) {
    rollback();
    error($e->getMessage(), $e->status);
} catch (PDOException $e) {
    rollback();
    // 23000 = integrity constraint violation. Keep the message generic so raw
    // MySQL table/column names never leak to the caller.
    if (($e->getCode() ?? '') === '23000') {
        error('That change conflicts with an existing record.', 409);
    }
    error('A database error occurred.', 500);
} catch (Throwable $e) {
    rollback();
    error('An unexpected error occurred.', 500);
}
