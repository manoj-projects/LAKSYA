<?php
/**
 * Database connection and query helpers.
 *
 * The connection is opened once per request. Mutating requests are wrapped in a
 * single transaction by index.php (commit on success, rollback on any error),
 * which mirrors the FastAPI get_db dependency so audit rows stay consistent with
 * the change they describe.
 */

require_once __DIR__ . '/config.php';

function getDB(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            // Native prepares so DECIMAL columns come back as strings ("11.00"),
            // matching how the FastAPI backend serialises Decimal on the wire.
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}

function query(string $sql, array $params = []): PDOStatement
{
    $stmt = getDB()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

function fetchAll(string $sql, array $params = []): array
{
    return query($sql, $params)->fetchAll();
}

function fetchOne(string $sql, array $params = []): ?array
{
    $row = query($sql, $params)->fetch();
    return $row === false ? null : $row;
}

/** Scalar value from the first column of the first row, or null. */
function fetchValue(string $sql, array $params = []): mixed
{
    $row = query($sql, $params)->fetch(PDO::FETCH_NUM);
    return $row === false ? null : $row[0];
}

function insertId(string $sql, array $params = []): int
{
    query($sql, $params);
    return (int) getDB()->lastInsertId();
}

function execute(string $sql, array $params = []): int
{
    return query($sql, $params)->rowCount();
}

// ---------------------------------------------------------------- transactions

function beginTransaction(): void
{
    if (!getDB()->inTransaction()) {
        getDB()->beginTransaction();
    }
}

function commit(): void
{
    if (getDB()->inTransaction()) {
        getDB()->commit();
    }
}

function rollback(): void
{
    if (getDB()->inTransaction()) {
        getDB()->rollBack();
    }
}
