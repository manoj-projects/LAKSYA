<?php
/**
 * Minimal JWT (HS256) encode/decode — no external library required.
 *
 * Mirrors backend/app/core/security.py: claims are sub (agent id), role, iat, exp.
 */

require_once __DIR__ . '/config.php';

function base64url_encode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode(string $data): string
{
    return base64_decode(strtr($data, '-_', '+/'));
}

/** Issues a token for an agent id and role. */
function create_access_token(string $subject, string $role): string
{
    $now = time();
    return jwt_encode([
        'sub' => $subject,
        'role' => $role,
        'iat' => $now,
        'exp' => $now + ACCESS_TOKEN_MINUTES * 60,
    ]);
}

function jwt_encode(array $payload): string
{
    $header = base64url_encode(json_encode(['typ' => 'JWT', 'alg' => JWT_ALGO]));
    $body = base64url_encode(json_encode($payload));
    $sig = base64url_encode(hash_hmac('sha256', "$header.$body", JWT_SECRET, true));
    return "$header.$body.$sig";
}

/** Returns the claims, or null if the token is malformed, tampered, or expired. */
function jwt_decode(string $token): ?array
{
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return null;
    }

    [$header, $body, $sig] = $parts;
    $expected = base64url_encode(hash_hmac('sha256', "$header.$body", JWT_SECRET, true));
    if (!hash_equals($expected, $sig)) {
        return null;
    }

    $payload = json_decode(base64url_decode($body), true);
    if (!is_array($payload) || !isset($payload['exp']) || $payload['exp'] < time()) {
        return null;
    }

    return $payload;
}
