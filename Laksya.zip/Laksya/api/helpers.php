<?php
/**
 * Request/response helpers: CORS, JSON I/O, auth + role gates, validation,
 * money formatting, pagination.
 */

require_once __DIR__ . '/jwt.php';
require_once __DIR__ . '/db.php';

/** Raised by validation and business-rule helpers; carries an HTTP status. */
class ApiException extends RuntimeException
{
    public function __construct(string $message, public int $status = 400)
    {
        parent::__construct($message);
    }
}

// ------------------------------------------------------------------------ CORS
function handleCORS(): void
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '' && in_array($origin, CORS_ORIGINS, true)) {
        header("Access-Control-Allow-Origin: $origin");
        header('Vary: Origin');
    }
    header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Authorization, Content-Type');
    header('Content-Type: application/json; charset=utf-8');

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

// -------------------------------------------------------------------- JSON I/O
function getBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === '' || $raw === false) {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function respond(mixed $data, int $code = 200): never
{
    // Marks the request as successful so the shutdown handler commits the
    // transaction rather than rolling it back.
    $GLOBALS['__request_ok'] = true;
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function error(string $message, int $code = 400): never
{
    respond(['detail' => $message], $code);
}

// --------------------------------------------------------------- query params
function qp(string $key, mixed $default = null): mixed
{
    $v = $_GET[$key] ?? $default;
    return $v === '' ? $default : $v;
}

function qpInt(string $key, int $default = 0): int
{
    return isset($_GET[$key]) && $_GET[$key] !== '' ? (int) $_GET[$key] : $default;
}

function qpBool(string $key): ?bool
{
    if (!isset($_GET[$key]) || $_GET[$key] === '') {
        return null;
    }
    $v = strtolower((string) $_GET[$key]);
    return $v === '1' || $v === 'true' || $v === 'yes';
}

// ----------------------------------------------------------------------- money
/** Formats a numeric value as a fixed 2-decimal string, matching Decimal on wire. */
function money(int|float|string|null $value): string
{
    return number_format((float) ($value ?? 0), 2, '.', '');
}

// ------------------------------------------------------------------ validation
function validatePhone(?string $phone): string
{
    if (!is_string($phone) || !preg_match('/^[6-9]\d{9}$/', $phone)) {
        throw new ApiException('Enter a valid 10-digit Indian mobile number.', 422);
    }
    return $phone;
}

function validatePincode(?string $pincode): ?string
{
    if ($pincode === null || $pincode === '') {
        return null;
    }
    if (!preg_match('/^\d{6}$/', $pincode)) {
        throw new ApiException('Pincode must be 6 digits.', 422);
    }
    return $pincode;
}

function requireField(array $body, string $key): mixed
{
    if (!array_key_exists($key, $body) || $body[$key] === null || $body[$key] === '') {
        throw new ApiException("Field '$key' is required.", 422);
    }
    return $body[$key];
}

// -------------------------------------------------------------------- auth
/** Returns the authenticated agent row, or null. Re-checks active state per request. */
function getAuthAgent(): ?array
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (!str_starts_with($header, 'Bearer ')) {
        return null;
    }

    $claims = jwt_decode(substr($header, 7));
    if (!$claims || empty($claims['sub'])) {
        return null;
    }

    $agent = fetchOne(
        'SELECT * FROM agents WHERE id = ? AND is_active = 1 AND deleted_at IS NULL',
        [(int) $claims['sub']]
    );
    return $agent ?: null;
}

function requireAuth(): array
{
    $agent = getAuthAgent();
    if (!$agent) {
        error('Sign in required.', 401);
    }
    return $agent;
}

function requireAdmin(): array
{
    $agent = requireAuth();
    if (strtolower($agent['role']) !== 'admin') {
        error('Requires role: admin. You are ' . strtolower($agent['role']) . '.', 403);
    }
    return $agent;
}

function requireManager(): array
{
    $agent = requireAuth();
    $role = strtolower($agent['role']);
    if ($role !== 'admin' && $role !== 'manager') {
        error('Requires role: admin, manager. You are ' . $role . '.', 403);
    }
    return $agent;
}

/** Best-effort client address for the audit log. */
function clientIp(): ?string
{
    $forwarded = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
    if ($forwarded !== '') {
        return substr(trim(explode(',', $forwarded)[0]), 0, 64);
    }
    $remote = $_SERVER['REMOTE_ADDR'] ?? null;
    return $remote !== null ? substr($remote, 0, 64) : null;
}

// -------------------------------------------------------------------- paging
/** Parses ?page and ?page_size with the same bounds as the FastAPI dependency. */
function pageParams(): array
{
    $page = max(1, qpInt('page', 1));
    $pageSize = qpInt('page_size', 25);
    $pageSize = max(1, min(200, $pageSize));
    return [$page, $pageSize, ($page - 1) * $pageSize];
}

function pageEnvelope(array $items, int $total, int $page, int $pageSize): array
{
    $pages = max(1, (int) ceil($total / $pageSize));
    return [
        'items' => $items,
        'total' => $total,
        'page' => $page,
        'page_size' => $pageSize,
        'pages' => $pages,
    ];
}
