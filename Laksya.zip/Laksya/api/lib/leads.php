<?php
/**
 * Lead creation and conversion to a bill.
 */

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/pricing.php';
require_once __DIR__ . '/numbering.php';
require_once __DIR__ . '/customers.php';
require_once __DIR__ . '/orders.php';
require_once __DIR__ . '/audit.php';

function lead_require(int $leadId): array
{
    $lead = fetchOne('SELECT * FROM leads WHERE id = ? AND deleted_at IS NULL', [$leadId]);
    if ($lead === null) {
        throw new ApiException("Lead $leadId not found.", 404);
    }
    return $lead;
}

/**
 * Creates a lead from a public/staff payload. Returns the new lead id.
 * $payload: customer{}, items[], lead_type, source, agent_id, coupon_code, notes, campaign.
 */
function lead_create(array $payload, ?array $actor = null): int
{
    if (empty($payload['customer']) || !is_array($payload['customer'])) {
        throw new ApiException('A customer object is required.', 422);
    }
    $customerId = customer_get_or_create($payload['customer']);

    $lines = resolve_lines($payload['items'] ?? []);
    $totals = compute_totals($lines, 0.0, 0.0, $payload['coupon_code'] ?? null);

    $leadType = $payload['lead_type'] ?? 'estimate';
    if (!in_array($leadType, ['estimate', 'order'], true)) {
        throw new ApiException("lead_type must be 'estimate' or 'order'.", 422);
    }

    $reference = next_lead_reference();
    $leadId = insertId(
        'INSERT INTO leads
            (reference, customer_id, agent_id, lead_type, source, status,
             subtotal, total, item_count, coupon_code, notes, campaign)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
            $reference,
            $customerId,
            $payload['agent_id'] ?? null,
            $leadType,
            $payload['source'] ?? 'website',
            'new',
            money($totals['subtotal']),
            money($totals['total']),
            $totals['item_count'],
            $payload['coupon_code'] ?? null,
            $payload['notes'] ?? null,
            $payload['campaign'] ?? null,
        ]
    );

    foreach ($lines as $line) {
        $p = $line['product'];
        execute(
            'INSERT INTO lead_items (lead_id, product_id, product_code, name, unit, mrp, price, qty, line_total)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $leadId,
                (int) $p['id'],
                $p['product_code'],
                $p['name'],
                $p['unit'],
                $p['mrp'],
                $p['price'],
                (int) $line['qty'],
                money($line['line_total']),
            ]
        );
    }

    audit_log(
        'lead.create',
        'lead',
        $reference,
        ($payload['source'] ?? 'website') . ' · ' . $totals['item_count'] . ' pcs · ' . money($totals['total']),
        $actor
    );

    return $leadId;
}

/**
 * Turns a lead into a bill and marks it converted. Returns the new order id.
 * $payload: agent_id, discount_pct, packing_charges, delivery_address, delivery_pincode, notes, confirm.
 */
function lead_convert(array $lead, array $payload, ?array $actor): int
{
    if ($lead['status'] === 'converted') {
        $existing = fetchValue('SELECT bill_no FROM orders WHERE lead_id = ? LIMIT 1', [(int) $lead['id']]) ?? 'an existing bill';
        throw new ApiException("Lead {$lead['reference']} is already converted to $existing.", 409);
    }
    if ($lead['status'] === 'lost') {
        throw new ApiException("Lead {$lead['reference']} is marked lost. Reopen it before converting.", 409);
    }

    $customer = customer_require((int) $lead['customer_id']);
    $leadItems = fetchAll('SELECT * FROM lead_items WHERE lead_id = ? ORDER BY id', [(int) $lead['id']]);
    $items = array_map(
        fn($li) => ['product_id' => (int) $li['product_id'], 'qty' => (int) $li['qty']],
        $leadItems
    );

    $orderId = order_create([
        'customer_id' => (int) $lead['customer_id'],
        'agent_id' => $payload['agent_id'] ?? $lead['agent_id'],
        'items' => $items,
        'discount_pct' => (float) ($payload['discount_pct'] ?? 0),
        'packing_charges' => (float) ($payload['packing_charges'] ?? 0),
        'coupon_code' => $lead['coupon_code'],
        'delivery_address' => $payload['delivery_address'] ?? $customer['address'],
        'delivery_pincode' => $payload['delivery_pincode'] ?? $customer['pincode'],
        'notes' => $payload['notes'] ?? $lead['notes'],
        'confirm' => !empty($payload['confirm']),
        'lead_id' => (int) $lead['id'],
        'actor' => $actor,
    ]);

    execute("UPDATE leads SET status = 'converted' WHERE id = ?", [(int) $lead['id']]);

    $billNo = fetchValue('SELECT bill_no FROM orders WHERE id = ?', [$orderId]);
    audit_log('lead.convert', 'lead', $lead['reference'], "Converted to $billNo", $actor);

    return $orderId;
}

/** Builds the full LeadOut object for a given lead id. */
function lead_out(int $leadId): array
{
    $lead = fetchOne(
        'SELECT l.*, a.name AS agent_name,
                o.id AS order_id, o.bill_no AS order_bill_no
         FROM leads l
         LEFT JOIN agents a ON a.id = l.agent_id
         LEFT JOIN orders o ON o.lead_id = l.id
         WHERE l.id = ? AND l.deleted_at IS NULL',
        [$leadId]
    );
    if ($lead === null) {
        throw new ApiException("Lead $leadId not found.", 404);
    }

    $customer = fetchOne('SELECT * FROM customers WHERE id = ?', [(int) $lead['customer_id']]);
    $items = fetchAll('SELECT * FROM lead_items WHERE lead_id = ? ORDER BY id', [$leadId]);

    return [
        'id' => (int) $lead['id'],
        'reference' => $lead['reference'],
        'lead_type' => $lead['lead_type'] ?: 'estimate',
        'status' => $lead['status'],
        'source' => $lead['source'],
        'customer' => customer_out($customer),
        'agent_id' => $lead['agent_id'] !== null ? (int) $lead['agent_id'] : null,
        'agent_name' => $lead['agent_name'],
        'items' => array_map('line_item_out', $items),
        'subtotal' => money($lead['subtotal']),
        'total' => money($lead['total']),
        'item_count' => (int) $lead['item_count'],
        'coupon_code' => $lead['coupon_code'],
        'notes' => $lead['notes'],
        'campaign' => $lead['campaign'],
        'order_id' => $lead['order_id'] !== null ? (int) $lead['order_id'] : null,
        'order_bill_no' => $lead['order_bill_no'],
        'created_at' => $lead['created_at'],
        'updated_at' => $lead['updated_at'],
    ];
}
