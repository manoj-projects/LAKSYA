<?php
/**
 * Customer resolution. Phone is the natural key; the directory upserts on it.
 */

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

/** Fills empty fields only — never overwrites a curated name or address. */
function customer_fill_blanks(array $existing, array $payload): void
{
    $sets = [];
    $params = [];
    if ($existing['deleted_at'] !== null) {
        $sets[] = 'deleted_at = NULL';
    }
    foreach (['name', 'email', 'address', 'city', 'pincode'] as $field) {
        $incoming = $payload[$field] ?? null;
        if ($incoming !== null && $incoming !== '' && empty($existing[$field])) {
            $sets[] = "$field = ?";
            $params[] = $incoming;
        }
    }
    if ($sets) {
        $params[] = $existing['id'];
        execute('UPDATE customers SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
    }
}

/**
 * Finds a customer by phone (and name, when given), or creates one.
 *
 * The same phone number may belong to different people, so a distinct name under
 * the same number is treated as a separate customer — and therefore a separate
 * bill history. When no name is supplied (e.g. a bare website enquiry) we match on
 * the phone alone so anonymous repeat enquiries do not fragment.
 */
function customer_get_or_create(array $payload): int
{
    $phone = validatePhone($payload['phone'] ?? null);
    validatePincode($payload['pincode'] ?? null);
    $name = isset($payload['name']) ? trim((string) $payload['name']) : '';

    if ($name !== '') {
        $existing = fetchOne(
            'SELECT * FROM customers WHERE phone = ? AND name = ? AND deleted_at IS NULL ORDER BY id LIMIT 1',
            [$phone, $name]
        );
    } else {
        $existing = fetchOne(
            'SELECT * FROM customers WHERE phone = ? AND deleted_at IS NULL ORDER BY id LIMIT 1',
            [$phone]
        );
    }
    if ($existing !== null) {
        customer_fill_blanks($existing, $payload);
        return (int) $existing['id'];
    }

    return insertId(
        'INSERT INTO customers (phone, name, email, address, city, pincode, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?)',
        [
            $phone,
            $name !== '' ? $name : ($payload['name'] ?? null),
            $payload['email'] ?? null,
            $payload['address'] ?? null,
            $payload['city'] ?? null,
            $payload['pincode'] ?? null,
            $payload['notes'] ?? null,
        ]
    );
}

function customer_require(int $customerId): array
{
    $customer = fetchOne(
        'SELECT * FROM customers WHERE id = ? AND deleted_at IS NULL',
        [$customerId]
    );
    if ($customer === null) {
        throw new ApiException("Customer $customerId not found.", 404);
    }
    return $customer;
}

/** Shapes a customer row into the CustomerOut response object. */
function customer_out(array $c): array
{
    return [
        'id' => (int) $c['id'],
        'phone' => $c['phone'],
        'name' => $c['name'],
        'email' => $c['email'],
        'address' => $c['address'],
        'city' => $c['city'],
        'pincode' => $c['pincode'],
        'notes' => $c['notes'],
        'created_at' => $c['created_at'],
    ];
}
