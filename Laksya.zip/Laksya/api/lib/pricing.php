<?php
/**
 * Line-item resolution and money arithmetic.
 *
 * Every rate comes from the database. The client sends a product reference and a
 * quantity and nothing else — it can never name its own price.
 */

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Coupon codes live server-side. Promote to a table when date-bounded offers are
// needed.
const COUPONS = [
    'DIWALI10' => 10.0,
    'PATTASU10' => 10.0,
    'FESTIVAL10' => 10.0,
    'PADAKKU10' => 10.0,
];

/** Rounds to paise, half-up. Every stored amount goes through this. */
function money_round(float $value): float
{
    return round($value, 2, PHP_ROUND_HALF_UP);
}

function coupon_discount_pct(?string $code): float
{
    if (!$code) {
        return 0.0;
    }
    return COUPONS[strtoupper(trim($code))] ?? 0.0;
}

/**
 * Looks up each requested product and merges duplicate references.
 *
 * Each input item is ['product_id' => ?int, 'product_code' => ?string, 'qty' => int].
 * Returns a list of ['product' => row, 'qty' => int, 'line_total' => float],
 * preserving first-seen order. Throws 422 naming a missing/inactive reference.
 */
function resolve_lines(array $items): array
{
    if (!$items) {
        throw new ApiException('At least one line item is required.', 422);
    }

    $ids = [];
    $codes = [];
    foreach ($items as $item) {
        $qty = (int) ($item['qty'] ?? 0);
        if ($qty < 1 || $qty > 100000) {
            throw new ApiException('Each line quantity must be between 1 and 100000.', 422);
        }
        if (isset($item['product_id']) && $item['product_id'] !== null) {
            $ids[(int) $item['product_id']] = true;
        } elseif (!empty($item['product_code'])) {
            $codes[trim((string) $item['product_code'])] = true;
        } else {
            throw new ApiException('Provide either product_id or product_code.', 422);
        }
    }

    $conditions = [];
    $params = [];
    if ($ids) {
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $conditions[] = "id IN ($ph)";
        $params = array_merge($params, array_map('intval', array_keys($ids)));
    }
    if ($codes) {
        $ph = implode(',', array_fill(0, count($codes), '?'));
        $conditions[] = "product_code IN ($ph)";
        $params = array_merge($params, array_keys($codes));
    }

    $rows = fetchAll(
        'SELECT * FROM products WHERE (' . implode(' OR ', $conditions) . ')
         AND deleted_at IS NULL AND is_active = 1',
        $params
    );

    $byId = [];
    $byCode = [];
    foreach ($rows as $row) {
        $byId[(int) $row['id']] = $row;
        $byCode[$row['product_code']] = $row;
    }

    // Merge repeated references so the same product cannot appear twice.
    $merged = [];  // product_id => qty
    $orderList = []; // preserves first-seen order
    $products = [];  // product_id => row

    foreach ($items as $item) {
        if (isset($item['product_id']) && $item['product_id'] !== null) {
            $product = $byId[(int) $item['product_id']] ?? null;
            $ref = 'id=' . $item['product_id'];
        } else {
            $product = $byCode[trim((string) $item['product_code'])] ?? null;
            $ref = 'code=' . ($item['product_code'] ?? '');
        }
        if ($product === null) {
            throw new ApiException("Product not found, inactive, or removed: $ref", 422);
        }
        $pid = (int) $product['id'];
        if (!isset($merged[$pid])) {
            $merged[$pid] = 0;
            $orderList[] = $pid;
            $products[$pid] = $product;
        }
        $merged[$pid] += (int) ($item['qty']);
    }

    $lines = [];
    foreach ($orderList as $pid) {
        $product = $products[$pid];
        $qty = $merged[$pid];
        $lines[] = [
            'product' => $product,
            'qty' => $qty,
            'line_total' => money_round((float) $product['price'] * $qty),
        ];
    }
    return $lines;
}

/**
 * Subtotal, then discount, then packing. Never allowed below zero.
 *
 * Returns ['subtotal','discount_pct','discount_amount','packing_charges','total','item_count'].
 */
function compute_totals(
    array $lines,
    float $discountPct = 0.0,
    float $packingCharges = 0.0,
    ?string $couponCode = null
): array {
    $subtotal = 0.0;
    $itemCount = 0;
    foreach ($lines as $line) {
        $subtotal += (float) $line['line_total'];
        $itemCount += (int) $line['qty'];
    }
    $subtotal = money_round($subtotal);

    // An explicit discount_pct wins; otherwise fall back to the coupon.
    $effectivePct = $discountPct > 0 ? $discountPct : coupon_discount_pct($couponCode);
    $discountAmount = money_round($subtotal * $effectivePct / 100);
    $packing = money_round($packingCharges);
    $total = max(0.0, money_round($subtotal - $discountAmount + $packing));

    return [
        'subtotal' => $subtotal,
        'discount_pct' => $effectivePct,
        'discount_amount' => $discountAmount,
        'packing_charges' => $packing,
        'total' => $total,
        'item_count' => $itemCount,
    ];
}
