<?php
/**
 * Stock operations.
 *
 * Stock is opt-in: a product with no stock_items row is untracked and is skipped
 * by both alerts and order-driven movements. Every balance change writes a ledger
 * row in the same transaction.
 */

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/audit.php';

// Statuses that hold stock but have not yet shipped it.
const COMMITTING_STATUSES = ['confirmed', 'packed'];

function stock_get(int $productId): ?array
{
    return fetchOne('SELECT * FROM stock_items WHERE product_id = ?', [$productId]);
}

/** Units per product held by orders that are confirmed or packed. */
function stock_committed_map(): array
{
    $rows = fetchAll(
        "SELECT oi.product_id, SUM(oi.qty) AS qty
         FROM order_items oi
         JOIN orders o ON o.id = oi.order_id
         WHERE o.status IN ('confirmed','packed') AND o.deleted_at IS NULL
         GROUP BY oi.product_id"
    );
    $map = [];
    foreach ($rows as $r) {
        $map[(int) $r['product_id']] = (int) $r['qty'];
    }
    return $map;
}

function stock_state(bool $tracked, int $available, int $reorderLevel): string
{
    if (!$tracked) {
        return 'untracked';
    }
    if ($available <= 0) {
        return 'out';
    }
    if ($available <= $reorderLevel) {
        return 'low';
    }
    return 'ok';
}

/**
 * Moves the balance and records the ledger row. Floors at zero; the ledger records
 * the delta actually applied. Returns the refreshed stock row.
 */
function stock_apply_movement(
    int $productId,
    int $delta,
    string $reason,
    ?array $actor = null,
    ?string $reference = null,
    ?string $note = null,
    ?string $ipAddress = null,
    bool $writeAudit = true
): array {
    if ($delta === 0) {
        throw new ApiException('Adjustment delta must not be zero.', 422);
    }

    $stock = stock_get($productId);
    if ($stock === null) {
        throw new ApiException(
            'This product is not tracked. Set an opening count before adjusting stock.',
            409
        );
    }

    $before = (int) $stock['on_hand'];
    $after = max(0, $before + $delta);
    $applied = $after - $before;

    execute('UPDATE stock_items SET on_hand = ? WHERE product_id = ?', [$after, $productId]);
    execute(
        'INSERT INTO stock_movements (product_id, delta, on_hand_after, reason, reference, note, actor_id)
         VALUES (?, ?, ?, ?, ?, ?, ?)',
        [$productId, $applied, $after, $reason, $reference, $note, $actor['id'] ?? null]
    );

    if ($writeAudit) {
        $detail = sprintf('%+d → %d (%s)', $applied, $after, $reason)
            . ($reference ? " ref $reference" : '');
        audit_log('stock.adjust', 'product', $productId, $detail, $actor, $ipAddress);
    }

    return stock_get($productId);
}

/**
 * Draws stock at dispatch, or puts it back on cancellation. Untracked products are
 * skipped. Returns how many lines actually moved.
 */
function stock_apply_order(array $order, ?array $actor, bool $release): int
{
    $reason = $release ? 'order_cancelled' : 'order_dispatch';
    $moved = 0;

    $items = fetchAll('SELECT * FROM order_items WHERE order_id = ?', [(int) $order['id']]);
    foreach ($items as $item) {
        $productId = (int) $item['product_id'];
        if (stock_get($productId) === null) {
            continue;
        }
        $delta = $release ? (int) $item['qty'] : -(int) $item['qty'];
        stock_apply_movement(
            $productId,
            $delta,
            $reason,
            $actor,
            $order['bill_no'],
            null,
            null,
            false // one summary audit entry below
        );
        $moved++;
    }

    if ($moved) {
        $detail = ($release ? 'Returned' : 'Drew') . " stock for $moved tracked line(s)";
        audit_log('stock.order', 'order', $order['bill_no'], $detail, $actor);
    }

    return $moved;
}
