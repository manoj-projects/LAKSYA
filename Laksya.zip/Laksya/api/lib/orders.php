<?php
/**
 * Order (bill) lifecycle.
 *
 * Money is always recomputed from resolved line items. Status changes are
 * validated against ORDER_FLOW; an invalid jump returns 409 and each valid one
 * appends an immutable event. Stock is drawn at dispatch and returned on cancel,
 * guarded by stock_applied so neither happens twice.
 */

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/pricing.php';
require_once __DIR__ . '/numbering.php';
require_once __DIR__ . '/inventory.php';
require_once __DIR__ . '/customers.php';
require_once __DIR__ . '/audit.php';

// Allowed forward transitions.
const ORDER_FLOW = [
    'draft' => ['confirmed', 'cancelled'],
    'confirmed' => ['packed', 'cancelled'],
    'packed' => ['dispatched', 'cancelled'],
    'dispatched' => ['delivered', 'cancelled'],
    'delivered' => [],
    'cancelled' => [],
];

const REVENUE_STATUSES = ['confirmed', 'packed', 'dispatched', 'delivered'];

// Lines may only be edited while the bill is draft or confirmed.
const EDITABLE_STATUSES = ['draft', 'confirmed'];

function order_require(int $orderId, bool $includeDeleted = false): array
{
    $sql = 'SELECT * FROM orders WHERE id = ?';
    if (!$includeDeleted) {
        $sql .= ' AND deleted_at IS NULL';
    }
    $order = fetchOne($sql, [$orderId]);
    if ($order === null) {
        throw new ApiException("Order $orderId not found.", 404);
    }
    return $order;
}

function order_by_bill_no(string $billNo): array
{
    $order = fetchOne(
        'SELECT * FROM orders WHERE UPPER(bill_no) = ? AND deleted_at IS NULL',
        [strtoupper(trim($billNo))]
    );
    if ($order === null) {
        throw new ApiException("No order found for $billNo.", 404);
    }
    return $order;
}

// --------------------------------------------------------------------- helpers

function order_balance_due(array $order): float
{
    return max(0.0, money_round((float) $order['total'] - (float) $order['amount_paid']));
}

function order_commission_amount(array $order): float
{
    if ($order['agent_id'] === null) {
        return 0.0;
    }
    $pct = (float) fetchValue('SELECT commission_pct FROM agents WHERE id = ?', [(int) $order['agent_id']]);
    if ($pct <= 0) {
        return 0.0;
    }
    return money_round((float) $order['total'] * $pct / 100);
}

/** Recomputes derived payment_status from total and amount_paid. */
function order_payment_status(float $total, float $paid): string
{
    if ($paid <= 0) {
        return 'unpaid';
    }
    if ($paid >= $total) {
        return 'paid';
    }
    return 'partial';
}

function order_insert_items(int $orderId, array $lines): void
{
    foreach ($lines as $line) {
        $p = $line['product'];
        execute(
            'INSERT INTO order_items (order_id, product_id, product_code, name, unit, mrp, price, qty, line_total)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $orderId,
                (int) $p['id'],
                $p['product_code'],
                $p['name'],
                $p['unit'],
                $p['mrp'],
                $p['price'],
                (int) $line['qty'],
                money($line['line_total']),
            ]
        );
    }
}

function order_apply_totals(int $orderId, array $totals): void
{
    $order = fetchOne('SELECT total, amount_paid FROM orders WHERE id = ?', [$orderId]);
    $paid = (float) ($order['amount_paid'] ?? 0);
    $paymentStatus = order_payment_status($totals['total'], $paid);
    execute(
        'UPDATE orders SET subtotal = ?, discount_pct = ?, discount_amount = ?,
            packing_charges = ?, total = ?, item_count = ?, payment_status = ?
         WHERE id = ?',
        [
            money($totals['subtotal']),
            money($totals['discount_pct']),
            money($totals['discount_amount']),
            money($totals['packing_charges']),
            money($totals['total']),
            $totals['item_count'],
            $paymentStatus,
            $orderId,
        ]
    );
}

// ---------------------------------------------------------------------- create

/**
 * Creates a bill. Rates come from the catalogue; the client only sends quantities.
 * Returns the new order id.
 */
function order_create(array $args): int
{
    $lines = resolve_lines($args['items']);
    $totals = compute_totals(
        $lines,
        (float) ($args['discount_pct'] ?? 0),
        (float) ($args['packing_charges'] ?? 0),
        $args['coupon_code'] ?? null
    );

    $billNo = next_bill_no();
    $orderId = insertId(
        'INSERT INTO orders
            (bill_no, customer_id, agent_id, lead_id, status, payment_status,
             subtotal, discount_pct, discount_amount, packing_charges, total,
             amount_paid, item_count, coupon_code, delivery_address, delivery_pincode,
             notes, stock_applied)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, 0)',
        [
            $billNo,
            (int) $args['customer_id'],
            $args['agent_id'] ?? null,
            $args['lead_id'] ?? null,
            'draft',
            order_payment_status($totals['total'], 0),
            money($totals['subtotal']),
            money($totals['discount_pct']),
            money($totals['discount_amount']),
            money($totals['packing_charges']),
            money($totals['total']),
            $totals['item_count'],
            $args['coupon_code'] ?? null,
            $args['delivery_address'] ?? null,
            $args['delivery_pincode'] ?? null,
            $args['notes'] ?? null,
        ]
    );

    order_insert_items($orderId, $lines);

    execute(
        'INSERT INTO order_status_events (order_id, status, note, actor_id) VALUES (?, ?, ?, ?)',
        [$orderId, 'draft', 'Bill created', $args['actor']['id'] ?? null]
    );

    audit_log(
        'order.create',
        'order',
        $billNo,
        $totals['item_count'] . ' pcs · ' . money($totals['total']),
        $args['actor'] ?? null,
        $args['ip_address'] ?? null
    );

    if (!empty($args['confirm'])) {
        $order = order_require($orderId);
        order_change_status($order, 'confirmed', $args['actor'] ?? null, 'Confirmed on creation');
    }

    return $orderId;
}

// ---------------------------------------------------------------------- update

function order_update(array $order, array $args): void
{
    $items = $args['items'] ?? null;
    $discountPct = $args['discount_pct'] ?? null;
    $packingCharges = $args['packing_charges'] ?? null;

    if ($items !== null && !in_array($order['status'], EDITABLE_STATUSES, true)) {
        throw new ApiException(
            "Line items cannot be changed once the order is {$order['status']}. "
            . 'Cancel and raise a new bill instead.',
            409
        );
    }

    // Scalar field updates.
    $sets = [];
    $params = [];
    foreach (['delivery_address', 'delivery_pincode', 'transport_name', 'docket_no', 'notes'] as $field) {
        if (array_key_exists($field, $args) && $args[$field] !== null) {
            $sets[] = "$field = ?";
            $params[] = $args[$field];
        }
    }
    // agent_id is applied only when the caller explicitly sent it (flagged by the
    // route), and an explicit null is allowed so the mapping can be cleared.
    if (!empty($args['agent_id_present'])) {
        $sets[] = 'agent_id = ?';
        $params[] = $args['agent_id'];
    }
    if ($sets) {
        $params[] = (int) $order['id'];
        execute('UPDATE orders SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
    }

    // Keep the linked lead's agent in step with the bill's agent, so the
    // dashboard's agent ranking (which is lead-based) reflects a bill-side
    // mapping instead of silently diverging.
    if (!empty($args['agent_id_present']) && $order['lead_id'] !== null) {
        execute('UPDATE leads SET agent_id = ? WHERE id = ?', [$args['agent_id'], (int) $order['lead_id']]);
    }

    $moneyChanged = $items !== null || $discountPct !== null || $packingCharges !== null;
    if ($moneyChanged) {
        if ($items !== null) {
            $lines = resolve_lines($items);
            execute('DELETE FROM order_items WHERE order_id = ?', [(int) $order['id']]);
            order_insert_items((int) $order['id'], $lines);
            $totals = compute_totals(
                $lines,
                $discountPct !== null ? (float) $discountPct : (float) $order['discount_pct'],
                $packingCharges !== null ? (float) $packingCharges : (float) $order['packing_charges'],
                $order['coupon_code']
            );
        } else {
            // Re-price from the existing snapshot so a catalogue change does not
            // silently rewrite an issued bill.
            $existing = fetchAll('SELECT * FROM order_items WHERE order_id = ?', [(int) $order['id']]);
            $subtotal = 0.0;
            $itemCount = 0;
            foreach ($existing as $it) {
                $subtotal += (float) $it['line_total'];
                $itemCount += (int) $it['qty'];
            }
            $subtotal = money_round($subtotal);
            $dp = $discountPct !== null ? (float) $discountPct : (float) $order['discount_pct'];
            $pc = $packingCharges !== null ? (float) $packingCharges : (float) $order['packing_charges'];
            $effective = $dp > 0 ? $dp : coupon_discount_pct($order['coupon_code']);
            $discountAmount = money_round($subtotal * $effective / 100);
            $packing = money_round($pc);
            $total = max(0.0, money_round($subtotal - $discountAmount + $packing));
            $totals = [
                'subtotal' => $subtotal,
                'discount_pct' => $effective,
                'discount_amount' => $discountAmount,
                'packing_charges' => $packing,
                'total' => $total,
                'item_count' => $itemCount,
            ];
        }
        order_apply_totals((int) $order['id'], $totals);
    }

    audit_log(
        'order.update',
        'order',
        $order['bill_no'],
        $items !== null ? 'Line items replaced' : 'Details updated',
        $args['actor'] ?? null
    );
}

// --------------------------------------------------------------- change status

function order_change_status(array $order, string $newStatus, ?array $actor, ?string $note = null): void
{
    if ($newStatus === $order['status']) {
        throw new ApiException("Order is already {$newStatus}.", 409);
    }

    $allowed = ORDER_FLOW[$order['status']] ?? [];
    if (!in_array($newStatus, $allowed, true)) {
        $options = $allowed ? implode(', ', $allowed) : 'nothing (final state)';
        throw new ApiException(
            "Cannot move from {$order['status']} to {$newStatus}. Allowed: {$options}.",
            409
        );
    }

    $previous = $order['status'];
    $sets = ['status = ?'];
    $params = [$newStatus];

    $stockApplied = (bool) $order['stock_applied'];
    if ($newStatus === 'dispatched' && !$stockApplied) {
        stock_apply_order($order, $actor, false);
        $sets[] = 'stock_applied = 1';
        $sets[] = 'dispatched_at = NOW()';
    } elseif ($newStatus === 'cancelled' && $stockApplied) {
        stock_apply_order($order, $actor, true);
        $sets[] = 'stock_applied = 0';
    } elseif ($newStatus === 'delivered') {
        $sets[] = 'delivered_at = NOW()';
    }

    $params[] = (int) $order['id'];
    execute('UPDATE orders SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);

    execute(
        'INSERT INTO order_status_events (order_id, status, note, actor_id) VALUES (?, ?, ?, ?)',
        [(int) $order['id'], $newStatus, $note, $actor['id'] ?? null]
    );

    audit_log(
        'order.status',
        'order',
        $order['bill_no'],
        "$previous → $newStatus" . ($note ? " · $note" : ''),
        $actor
    );
}

// -------------------------------------------------------------------- payments

function order_add_payment(array $order, array $payload, ?array $actor): int
{
    if ($order['status'] === 'cancelled') {
        throw new ApiException('Cannot record a payment against a cancelled order.', 409);
    }

    $amount = money_round((float) requireField($payload, 'amount'));
    if ($amount <= 0) {
        throw new ApiException('Payment amount must be greater than zero.', 422);
    }

    $balance = order_balance_due($order);
    if ($amount > $balance) {
        throw new ApiException(
            "Payment of " . money($amount) . " exceeds the outstanding balance of " . money($balance) . '.',
            422
        );
    }

    $mode = $payload['mode'] ?? 'cash';
    $paymentId = insertId(
        'INSERT INTO payments (order_id, amount, mode, reference, note, actor_id)
         VALUES (?, ?, ?, ?, ?, ?)',
        [
            (int) $order['id'],
            money($amount),
            $mode,
            $payload['reference'] ?? null,
            $payload['note'] ?? null,
            $actor['id'] ?? null,
        ]
    );

    $newPaid = money_round((float) $order['amount_paid'] + $amount);
    $paymentStatus = order_payment_status((float) $order['total'], $newPaid);
    execute(
        'UPDATE orders SET amount_paid = ?, payment_status = ? WHERE id = ?',
        [money($newPaid), $paymentStatus, (int) $order['id']]
    );

    audit_log(
        'order.payment',
        'order',
        $order['bill_no'],
        '+' . money($amount) . " via $mode · paid " . money($newPaid) . ' of ' . money($order['total']),
        $actor
    );

    return $paymentId;
}

// ----------------------------------------------------------- soft delete/restore

function order_soft_delete(array $order, ?array $actor): void
{
    if ($order['deleted_at'] !== null) {
        return;
    }
    if ((bool) $order['stock_applied']) {
        stock_apply_order($order, $actor, true);
        execute('UPDATE orders SET stock_applied = 0 WHERE id = ?', [(int) $order['id']]);
    }
    execute('UPDATE orders SET deleted_at = NOW() WHERE id = ?', [(int) $order['id']]);
    audit_log('order.delete', 'order', $order['bill_no'], 'Moved to trash', $actor);
}

function order_restore(array $order, ?array $actor): void
{
    if ($order['deleted_at'] === null) {
        return;
    }
    execute('UPDATE orders SET deleted_at = NULL WHERE id = ?', [(int) $order['id']]);
    audit_log('order.restore', 'order', $order['bill_no'], 'Restored from trash', $actor);
}

// ------------------------------------------------------------- response shaping

function line_item_out(array $i): array
{
    return [
        'id' => (int) $i['id'],
        'product_id' => (int) $i['product_id'],
        'product_code' => $i['product_code'],
        'name' => $i['name'],
        'unit' => $i['unit'],
        'mrp' => money($i['mrp']),
        'price' => money($i['price']),
        'qty' => (int) $i['qty'],
        'line_total' => money($i['line_total']),
    ];
}

function status_event_out(array $e): array
{
    return [
        'id' => (int) $e['id'],
        'status' => $e['status'],
        'note' => $e['note'],
        'actor_label' => $e['actor_label'] ?? null,
        'created_at' => $e['created_at'],
    ];
}

function payment_out(array $p): array
{
    return [
        'id' => (int) $p['id'],
        'amount' => money($p['amount']),
        'mode' => $p['mode'],
        'reference' => $p['reference'],
        'note' => $p['note'],
        'actor_label' => $p['actor_label'] ?? null,
        'received_at' => $p['received_at'],
    ];
}

/** Builds the full OrderOut object for a given order id. */
function order_out(int $orderId, bool $includeDeleted = false): array
{
    $order = order_require($orderId, $includeDeleted);

    $customer = fetchOne('SELECT * FROM customers WHERE id = ?', [(int) $order['customer_id']]);

    $agentName = null;
    if ($order['agent_id'] !== null) {
        $agentName = fetchValue('SELECT name FROM agents WHERE id = ?', [(int) $order['agent_id']]);
    }

    $leadReference = null;
    if ($order['lead_id'] !== null) {
        $leadReference = fetchValue('SELECT reference FROM leads WHERE id = ?', [(int) $order['lead_id']]);
    }

    $items = fetchAll('SELECT * FROM order_items WHERE order_id = ? ORDER BY id', [$orderId]);
    $events = fetchAll(
        'SELECT e.*, a.name AS actor_name, a.code AS actor_code
         FROM order_status_events e LEFT JOIN agents a ON a.id = e.actor_id
         WHERE e.order_id = ? ORDER BY e.id',
        [$orderId]
    );
    $payments = fetchAll(
        'SELECT p.*, a.name AS actor_name FROM payments p
         LEFT JOIN agents a ON a.id = p.actor_id
         WHERE p.order_id = ? ORDER BY p.id',
        [$orderId]
    );

    return [
        'id' => (int) $order['id'],
        'bill_no' => $order['bill_no'],
        'status' => $order['status'],
        'payment_status' => $order['payment_status'],
        'customer' => customer_out($customer),
        'agent_id' => $order['agent_id'] !== null ? (int) $order['agent_id'] : null,
        'agent_name' => $agentName,
        'lead_id' => $order['lead_id'] !== null ? (int) $order['lead_id'] : null,
        'lead_reference' => $leadReference,
        'items' => array_map('line_item_out', $items),
        'events' => array_map(function ($e) {
            $e['actor_label'] = $e['actor_name'] ? ($e['actor_name'] . ' (' . $e['actor_code'] . ')') : null;
            return status_event_out($e);
        }, $events),
        'payments' => array_map(function ($p) {
            $p['actor_label'] = $p['actor_name'] ?? null;
            return payment_out($p);
        }, $payments),
        'subtotal' => money($order['subtotal']),
        'discount_pct' => money($order['discount_pct']),
        'discount_amount' => money($order['discount_amount']),
        'packing_charges' => money($order['packing_charges']),
        'total' => money($order['total']),
        'amount_paid' => money($order['amount_paid']),
        'balance_due' => money(order_balance_due($order)),
        'commission_amount' => money(order_commission_amount($order)),
        'item_count' => (int) $order['item_count'],
        'coupon_code' => $order['coupon_code'],
        'delivery_address' => $order['delivery_address'],
        'delivery_pincode' => $order['delivery_pincode'],
        'transport_name' => $order['transport_name'],
        'docket_no' => $order['docket_no'],
        'dispatched_at' => $order['dispatched_at'],
        'delivered_at' => $order['delivered_at'],
        'notes' => $order['notes'],
        'created_at' => $order['created_at'],
        'updated_at' => $order['updated_at'],
        'deleted_at' => $order['deleted_at'],
    ];
}
