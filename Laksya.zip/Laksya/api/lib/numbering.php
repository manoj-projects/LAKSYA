<?php
/**
 * Server-side sequence allocation for bill and lead references.
 *
 * The increment is a single atomic INSERT ... ON DUPLICATE KEY UPDATE against a
 * dedicated row. InnoDB holds the exclusive row lock until the surrounding
 * transaction commits, so concurrent requests queue rather than collide.
 */

require_once __DIR__ . '/../db.php';

const BILL_PREFIX = 'PP-MGMK';
const LEAD_PREFIX = 'PP-LEAD';

function next_counter_value(string $prefix): int
{
    execute(
        'INSERT INTO bill_counters (prefix, counter_value) VALUES (?, 1)
         ON DUPLICATE KEY UPDATE counter_value = counter_value + 1',
        [$prefix]
    );
    $value = fetchValue('SELECT counter_value FROM bill_counters WHERE prefix = ?', [$prefix]);
    if ($value === null) {
        throw new RuntimeException("Counter $prefix vanished mid-transaction");
    }
    return (int) $value;
}

/** e.g. PP-MGMK-0007 */
function next_bill_no(): string
{
    return BILL_PREFIX . '-' . str_pad((string) next_counter_value(BILL_PREFIX), 4, '0', STR_PAD_LEFT);
}

/** e.g. PP-LEAD-0042 */
function next_lead_reference(): string
{
    return LEAD_PREFIX . '-' . str_pad((string) next_counter_value(LEAD_PREFIX), 4, '0', STR_PAD_LEFT);
}
