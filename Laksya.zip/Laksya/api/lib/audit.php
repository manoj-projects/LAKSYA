<?php
/**
 * Audit writer.
 *
 * Inserts within the request's transaction. The caller's transaction decides
 * whether it survives, keeping the log consistent with the data.
 */

require_once __DIR__ . '/../db.php';

function audit_log(
    string $action,
    string $entity,
    string|int $entityId,
    ?string $detail = null,
    ?array $actor = null,
    ?string $ipAddress = null
): void {
    $label = $actor ? ($actor['name'] . ' (' . $actor['code'] . ')') : 'system';
    execute(
        'INSERT INTO audit_logs (actor_id, actor_label, action, entity, entity_id, detail, ip_address)
         VALUES (?, ?, ?, ?, ?, ?, ?)',
        [
            $actor['id'] ?? null,
            $label,
            $action,
            $entity,
            (string) $entityId,
            $detail,
            $ipAddress,
        ]
    );
}
