<?php
// Router for `php -S` that mimics the .htaccess rewrite for local development.
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$file = __DIR__ . $path;
if ($path !== '/' && is_file($file)) {
    return false; // serve real static files (e.g. setup.php) directly
}
require __DIR__ . '/index.php';
