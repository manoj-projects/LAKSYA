<?php
/**
 * Configuration, sourced from the environment with sensible local defaults.
 *
 * Mirrors backend/app/core/config.py. Values can be set as real environment
 * variables (recommended on shared hosting via .htaccess SetEnv or the panel) or
 * left at the defaults below for local development.
 */

// Load an optional api/.env file (KEY=VALUE per line) into the environment.
(function (): void {
    $envFile = __DIR__ . '/.env';
    if (!is_file($envFile)) {
        return;
    }
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        // Strip a single layer of surrounding quotes.
        if (strlen($value) >= 2 && ($value[0] === '"' || $value[0] === "'")) {
            $value = substr($value, 1, -1);
        }
        if (getenv($key) === false) {
            putenv("$key=$value");
            $_ENV[$key] = $value;
        }
    }
})();

function env(string $key, ?string $default = null): ?string
{
    $value = getenv($key);
    return $value === false ? $default : $value;
}

// ------------------------------------------------------------------- database
define('DB_HOST', env('MYSQL_HOST', 'localhost'));
define('DB_PORT', (int) env('MYSQL_PORT', '3306'));
define('DB_NAME', env('MYSQL_DATABASE', 'padakku_pattasu'));
define('DB_USER', env('MYSQL_USER', 'root'));
define('DB_PASS', env('MYSQL_PASSWORD', ''));
define('DB_CHARSET', 'utf8mb4');

// ----------------------------------------------------------------------- auth
// Must be at least 32 characters in production. The default is fine for local
// development only — override MYSQL_* and JWT_SECRET before going live.
define('JWT_SECRET', env('JWT_SECRET', 'local-dev-secret-change-me-32-characters'));
define('JWT_ALGO', 'HS256');
define('ACCESS_TOKEN_MINUTES', (int) env('ACCESS_TOKEN_MINUTES', '480'));

// bcrypt silently truncates at 72 bytes; reject anything longer up front.
define('MAX_PASSWORD_BYTES', 72);

// ----------------------------------------------------------------------- cors
// Comma-separated exact origins. Never "*": the admin is authenticated.
define('CORS_ORIGINS', array_values(array_filter(array_map(
    'trim',
    explode(',', env('CORS_ORIGINS', 'http://localhost:5173,http://127.0.0.1:5173'))
))));

// ----------------------------------------------------- bootstrap first admin
define('BOOTSTRAP_ADMIN_PHONE', env('BOOTSTRAP_ADMIN_PHONE', '9994033148'));
define('BOOTSTRAP_ADMIN_NAME', env('BOOTSTRAP_ADMIN_NAME', 'Owner'));
define('BOOTSTRAP_ADMIN_PASSWORD', env('BOOTSTRAP_ADMIN_PASSWORD', 'change-me-now'));

define('APP_ENVIRONMENT', env('ENVIRONMENT', 'development'));
