# Padakku Pattasu — Admin API (PHP)

A faithful PHP port of the FastAPI backend in `../backend`. Same API contract,
same URL paths (`/api/v1/...`), same JSON shapes, same business rules — built for
plain PHP 8 + MySQL shared hosting with no framework or Composer dependencies.

## Stack

| Concern | Choice |
|---|---|
| Runtime | PHP 8.1+ (tested on 8.4), PDO MySQL |
| Database | MySQL 8 / MariaDB, utf8mb4 |
| Auth | JWT bearer (HS256), bcrypt password hashes |
| Money | `DECIMAL` in MySQL, formatted as JSON strings on the wire |
| Routing | Single front controller (`index.php`) + `.htaccess` rewrite |

## Layout

```
api/
  index.php          Front controller: routing + one transaction per request
  config.php         Env-driven settings (reads api/.env or real env vars)
  db.php             PDO connection + query/transaction helpers
  jwt.php            HS256 encode/decode (sub, role, iat, exp)
  helpers.php        CORS, JSON I/O, auth + role gates, validation, money(), paging
  setup.php          One-shot: create schema, seed catalogue, bootstrap admin
  lib/               Service layer (business logic)
    audit.php  pricing.php  numbering.php  customers.php
    inventory.php  orders.php  leads.php
  routes/            One file per resource group
    auth  agents  products  customers  leads  orders  inventory  reports
```

## Setup

1. Create a MySQL database and user.
2. Copy `api/.env.example` to `api/.env` and fill in the DB credentials, a
   32+ character `JWT_SECRET` (`openssl rand -hex 32`), and
   `BOOTSTRAP_ADMIN_PASSWORD`. On shared hosting you can instead set these as
   real environment variables.
3. Run the setup script once:
   ```bash
   php api/setup.php            # CLI
   # or visit  https://your-host/api/setup.php  once, then remove it
   ```
   It creates all tables, upserts the catalogue from
   `../backend/seed/catalogue.json` if present (258 products), and creates the
   first admin when the agents table is empty.
4. Point the frontend at the API: set `VITE_API_BASE_URL` to
   `https://your-host/api/v1`.

## Design notes (unchanged from the reference backend)

- **Enums are stored lowercase VARCHAR** (`draft`, `admin`, `website`, …).
- **All prices come from the database.** Requests send a product reference and a
  quantity; the client can never name its own rate. Coupons live in
  `lib/pricing.php` (`DIWALI10`/`PATTASU10`/`FESTIVAL10` = 10%).
- **Bill / lead numbers** come from `bill_counters` via a single atomic
  `INSERT … ON DUPLICATE KEY UPDATE`, so InnoDB's row lock serialises concurrent
  callers (`PP-MGMK-0001`, `PP-LEAD-0001`).
- **Order pipeline** `draft → confirmed → packed → dispatched → delivered`, with
  `cancelled` reachable from any live state. Invalid jumps return `409`.
- **Stock is opt-in** (no `stock_items` row = untracked). Tracked stock is drawn
  at `dispatched` and returned on `cancelled`/trash, guarded by
  `orders.stock_applied` so neither happens twice. Every change writes a ledger row.
- **`payment_status` is derived** from `total` and `amount_paid`; overpayment is
  rejected.
- **Every mutation runs in one DB transaction** and writes an `audit_logs` row in
  the same transaction, so a rollback leaves no misleading log entry.
- **Role gates:** `admin` (agents, passwords), `manager` (bills, stock, reports),
  `agent` (own + unassigned bills/leads only). Agent state is re-checked on every
  request.

## Endpoints

Same surface as the FastAPI app, all under `/api/v1`:

| Group | Routes |
|---|---|
| Public | `POST /leads/public`, `GET /orders/track/{bill_no}`, `GET /categories`, `GET /products`, `GET /storefront-data`, `GET /video-links`, `GET /gift-boxes`, `GET /combo-packs`, `POST /pricelist-download`, `GET /pricelist-downloads` |
| Auth | `POST /auth/login`, `GET /auth/me`, `POST /auth/change-password` |
| Agents | `GET/POST /agents`, `GET/PATCH/DELETE /agents/{id}`, `POST /agents/{id}/password`, `GET /agents/performance` |
| Catalogue | `POST /products`, `GET/PATCH/DELETE /products/{id}`, `POST /products/{id}/restore`, `POST /products/{id}/toggle-stock`, `POST /products/bulk-margin`, gift-boxes + combo-packs CRUD |
| Customers | `GET/POST /customers`, `GET/PATCH/DELETE /customers/{id}` |
| Leads | `GET /leads`, `GET /leads/counts`, `GET/PATCH/DELETE /leads/{id}`, `POST /leads/{id}/convert` |
| Orders | `GET/POST /orders`, `GET/PATCH/DELETE /orders/{id}`, `POST /orders/{id}/status`, `POST /orders/{id}/payments`, `POST /orders/{id}/restore` |
| Inventory | `GET /inventory`, `GET /inventory/alerts`, `GET /inventory/movements`, `POST /inventory/{id}/track`, `PATCH /inventory/{id}`, `POST /inventory/{id}/adjust`, `DELETE /inventory/{id}/track` |
| Reports | `GET /reports/summary`, `/reports/status-breakdown`, `/reports/leads-by-agent`, `/reports/sales-daily`, `/reports/top-products`, `GET /audit` |

Every list endpoint is paginated: `{ items, total, page, page_size, pages }`.

## Security note

`POST /leads/public` is open by design and has no rate limiting. Put a limit in
front of it at the web server before exposing it publicly. Delete `setup.php`
after the first run on a public host.
