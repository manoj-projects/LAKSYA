<?php
/**
 * One-shot database setup: creates every table, seeds the catalogue from
 * backend/seed/catalogue.json (if present), and bootstraps the first admin.
 *
 * Run once from the browser or CLI:  php api/setup.php   (or visit /api/setup.php)
 *
 * Idempotent: safe to re-run. Tables use CREATE TABLE IF NOT EXISTS, the
 * catalogue upserts by natural key (slug, product_code), and the admin is only
 * created when the agents table is empty.
 *
 * Enums are stored as lowercase VARCHAR to match the reference spec.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

$isCli = PHP_SAPI === 'cli';
$nl = $isCli ? "\n" : '<br>';
if (!$isCli) {
    header('Content-Type: text/plain; charset=utf-8');
}

$pdo = getDB();

$schema = <<<'SQL'
CREATE TABLE IF NOT EXISTS agents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(16) UNIQUE NOT NULL,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(160) UNIQUE DEFAULT NULL,
    area VARCHAR(120) DEFAULT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'agent',
    password_hash VARCHAR(255) DEFAULT NULL,
    password_plain VARCHAR(255) DEFAULT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    commission_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
    notes VARCHAR(500) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME DEFAULT NULL,
    INDEX idx_agents_phone (phone),
    INDEX idx_agents_role (role),
    INDEX idx_agents_active (is_active),
    INDEX idx_agents_deleted (deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(80) UNIQUE NOT NULL,
    name VARCHAR(160) NOT NULL,
    blurb VARCHAR(300) DEFAULT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_code VARCHAR(32) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    name_tamil VARCHAR(300) DEFAULT NULL,
    category_id INT NOT NULL,
    unit VARCHAR(24) NOT NULL DEFAULT '1Box',
    mrp DECIMAL(10,2) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    description TEXT DEFAULT NULL,
    video_url VARCHAR(500) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME DEFAULT NULL,
    INDEX idx_products_code (product_code),
    INDEX idx_products_name (name),
    INDEX idx_products_category (category_id),
    INDEX idx_products_active (is_active),
    INDEX idx_products_deleted (deleted_at),
    CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    -- Phone is NOT unique: the same number may belong to different names, each
    -- kept as a separate customer (and therefore a separate bill history).
    phone VARCHAR(20) NOT NULL,
    name VARCHAR(160) DEFAULT NULL,
    email VARCHAR(160) DEFAULT NULL,
    address TEXT DEFAULT NULL,
    city VARCHAR(120) DEFAULT NULL,
    pincode VARCHAR(10) DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME DEFAULT NULL,
    INDEX idx_customers_phone (phone),
    INDEX idx_customers_name (name),
    INDEX idx_customers_pincode (pincode),
    INDEX idx_customers_deleted (deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS leads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reference VARCHAR(32) UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    agent_id INT DEFAULT NULL,
    lead_type VARCHAR(20) NOT NULL DEFAULT 'estimate',
    status VARCHAR(20) NOT NULL DEFAULT 'new',
    source VARCHAR(20) NOT NULL DEFAULT 'website',
    subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
    total DECIMAL(12,2) NOT NULL DEFAULT 0,
    item_count INT NOT NULL DEFAULT 0,
    coupon_code VARCHAR(32) DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    campaign VARCHAR(120) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME DEFAULT NULL,
    INDEX idx_leads_ref (reference),
    INDEX idx_leads_type (lead_type),
    INDEX idx_leads_status (status),
    INDEX idx_leads_source (source),
    INDEX idx_leads_customer (customer_id),
    INDEX idx_leads_agent (agent_id),
    INDEX idx_leads_deleted (deleted_at),
    CONSTRAINT fk_leads_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE RESTRICT,
    CONSTRAINT fk_leads_agent FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lead_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lead_id INT NOT NULL,
    product_id INT NOT NULL,
    product_code VARCHAR(32) NOT NULL,
    name VARCHAR(200) NOT NULL,
    unit VARCHAR(24) NOT NULL,
    mrp DECIMAL(10,2) NOT NULL DEFAULT 0,
    price DECIMAL(10,2) NOT NULL,
    qty INT NOT NULL,
    line_total DECIMAL(12,2) NOT NULL,
    INDEX idx_lead_items_lead (lead_id),
    INDEX idx_lead_items_product (product_id),
    CONSTRAINT fk_lead_items_lead FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE,
    CONSTRAINT fk_lead_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bill_no VARCHAR(32) UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    agent_id INT DEFAULT NULL,
    lead_id INT DEFAULT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    payment_status VARCHAR(20) NOT NULL DEFAULT 'unpaid',
    subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
    discount_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    packing_charges DECIMAL(12,2) NOT NULL DEFAULT 0,
    total DECIMAL(12,2) NOT NULL DEFAULT 0,
    amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0,
    item_count INT NOT NULL DEFAULT 0,
    coupon_code VARCHAR(32) DEFAULT NULL,
    delivery_address TEXT DEFAULT NULL,
    delivery_pincode VARCHAR(10) DEFAULT NULL,
    transport_name VARCHAR(160) DEFAULT NULL,
    docket_no VARCHAR(80) DEFAULT NULL,
    dispatched_at DATETIME DEFAULT NULL,
    delivered_at DATETIME DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    stock_applied TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME DEFAULT NULL,
    INDEX idx_orders_billno (bill_no),
    INDEX idx_orders_status (status),
    INDEX idx_orders_payment (payment_status),
    INDEX idx_orders_customer (customer_id),
    INDEX idx_orders_agent (agent_id),
    INDEX idx_orders_deleted (deleted_at),
    CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE RESTRICT,
    CONSTRAINT fk_orders_agent FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE SET NULL,
    CONSTRAINT fk_orders_lead FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_code VARCHAR(32) NOT NULL,
    name VARCHAR(200) NOT NULL,
    unit VARCHAR(24) NOT NULL,
    mrp DECIMAL(10,2) NOT NULL DEFAULT 0,
    price DECIMAL(10,2) NOT NULL,
    qty INT NOT NULL,
    line_total DECIMAL(12,2) NOT NULL,
    INDEX idx_order_items_order (order_id),
    INDEX idx_order_items_product (product_id),
    CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_status_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    status VARCHAR(20) NOT NULL,
    note VARCHAR(500) DEFAULT NULL,
    actor_id INT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status_events_order (order_id),
    CONSTRAINT fk_status_events_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_status_events_actor FOREIGN KEY (actor_id) REFERENCES agents(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    mode VARCHAR(20) NOT NULL DEFAULT 'cash',
    reference VARCHAR(120) DEFAULT NULL,
    note VARCHAR(300) DEFAULT NULL,
    actor_id INT DEFAULT NULL,
    received_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_payments_order (order_id),
    CONSTRAINT fk_payments_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_payments_actor FOREIGN KEY (actor_id) REFERENCES agents(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stock_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT UNIQUE NOT NULL,
    on_hand INT NOT NULL DEFAULT 0,
    reorder_level INT NOT NULL DEFAULT 0,
    location VARCHAR(80) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_stock_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stock_movements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    delta INT NOT NULL,
    on_hand_after INT NOT NULL,
    reason VARCHAR(24) NOT NULL,
    reference VARCHAR(32) DEFAULT NULL,
    note VARCHAR(300) DEFAULT NULL,
    actor_id INT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_movements_product (product_id),
    INDEX idx_movements_reason (reason),
    INDEX idx_movements_reference (reference),
    INDEX idx_movements_created (created_at),
    CONSTRAINT fk_movements_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    CONSTRAINT fk_movements_actor FOREIGN KEY (actor_id) REFERENCES agents(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS bill_counters (
    prefix VARCHAR(16) PRIMARY KEY,
    counter_value INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    actor_id INT DEFAULT NULL,
    actor_label VARCHAR(120) NOT NULL DEFAULT 'system',
    action VARCHAR(60) NOT NULL,
    entity VARCHAR(40) NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    detail TEXT DEFAULT NULL,
    ip_address VARCHAR(64) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_action (action),
    INDEX idx_audit_entity (entity),
    INDEX idx_audit_actor (actor_id),
    INDEX idx_audit_created (created_at),
    CONSTRAINT fk_audit_actor FOREIGN KEY (actor_id) REFERENCES agents(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS gift_boxes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_code VARCHAR(32) NOT NULL,
    label VARCHAR(200) NOT NULL,
    image_url VARCHAR(500) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_giftbox_code (product_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS combo_packs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_code VARCHAR(32) NOT NULL,
    label VARCHAR(200) NOT NULL,
    image_url VARCHAR(500) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_combo_code (product_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    spent_on DATE NOT NULL,
    category VARCHAR(60) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    note VARCHAR(300) DEFAULT NULL,
    actor_id INT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_expenses_date (spent_on),
    INDEX idx_expenses_category (category),
    CONSTRAINT fk_expenses_actor FOREIGN KEY (actor_id) REFERENCES agents(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS commission_payouts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    agent_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    paid_on DATE NOT NULL,
    note VARCHAR(300) DEFAULT NULL,
    actor_id INT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_payouts_agent (agent_id),
    INDEX idx_payouts_date (paid_on),
    CONSTRAINT fk_payouts_agent FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE,
    CONSTRAINT fk_payouts_actor FOREIGN KEY (actor_id) REFERENCES agents(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;

foreach (array_filter(array_map('trim', explode(';', $schema))) as $stmt) {
    if ($stmt !== '') {
        $pdo->exec($stmt);
    }
}

// Drop the legacy UNIQUE index on customers.phone so the same number can be
// reused under different names (each a separate customer/bill).
$phoneUnique = (int) fetchValue(
    "SELECT COUNT(*) FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'customers'
       AND INDEX_NAME = 'phone' AND NON_UNIQUE = 0"
);
if ($phoneUnique > 0) {
    // Ensure a non-unique lookup index exists before dropping the unique one.
    $hasIdx = (int) fetchValue(
        "SELECT COUNT(*) FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'customers' AND INDEX_NAME = 'idx_customers_phone'"
    );
    if ($hasIdx === 0) {
        $pdo->exec('ALTER TABLE customers ADD INDEX idx_customers_phone (phone)');
    }
    $pdo->exec('ALTER TABLE customers DROP INDEX phone');
    echo "Dropped UNIQUE constraint on customers.phone (multiple names per number allowed).$nl";
}

// Backfill the agents.password_plain column (admin-visible credential) for
// databases created before this change.
$hasPwPlain = (int) fetchValue(
    "SELECT COUNT(*) FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'agents' AND COLUMN_NAME = 'password_plain'"
);
if ($hasPwPlain === 0) {
    $pdo->exec('ALTER TABLE agents ADD COLUMN password_plain VARCHAR(255) DEFAULT NULL AFTER password_hash');
    echo "Added agents.password_plain column.$nl";
}

// Drop legacy supplier cost columns (cost = JM, cost_ak = AK) on databases
// created before supplier costing was removed.
foreach (['cost', 'cost_ak'] as $legacyCol) {
    $hasLegacy = (int) fetchValue(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products' AND COLUMN_NAME = ?",
        [$legacyCol]
    );
    if ($hasLegacy > 0) {
        $pdo->exec("ALTER TABLE products DROP COLUMN $legacyCol");
        echo "Dropped legacy products.$legacyCol column.$nl";
    }
}

echo "Schema ready — all tables created.$nl";

// -------------------------------------------------- catalogue seed (optional)
$catalogueFile = __DIR__ . '/../backend/seed/catalogue.json';
if (is_file($catalogueFile)) {
    $payload = json_decode(file_get_contents($catalogueFile), true);
    $created = 0;
    $updated = 0;

    foreach ($payload['categories'] as $c) {
        $existing = fetchOne('SELECT id FROM categories WHERE slug = ?', [$c['slug']]);
        if ($existing) {
            execute(
                'UPDATE categories SET name = ?, blurb = ?, sort_order = ? WHERE id = ?',
                [$c['name'], $c['blurb'] ?? null, $c['sort_order'] ?? 0, $existing['id']]
            );
        } else {
            insertId(
                'INSERT INTO categories (slug, name, blurb, sort_order) VALUES (?, ?, ?, ?)',
                [$c['slug'], $c['name'], $c['blurb'] ?? null, $c['sort_order'] ?? 0]
            );
        }
    }

    $categoryIds = [];
    foreach (fetchAll('SELECT id, slug FROM categories') as $row) {
        $categoryIds[$row['slug']] = (int) $row['id'];
    }

    foreach ($payload['products'] as $pr) {
        $categoryId = $categoryIds[$pr['category_slug']] ?? null;
        if ($categoryId === null) {
            continue;
        }
        $existing = fetchOne('SELECT id, video_url FROM products WHERE product_code = ?', [$pr['product_code']]);
        if ($existing) {
            // Only backfill the video link so an admin-set value is not clobbered.
            $video = ($existing['video_url'] === null && !empty($pr['video_url'])) ? $pr['video_url'] : $existing['video_url'];
            execute(
                'UPDATE products SET name = ?, category_id = ?, unit = ?, mrp = ?, price = ?, video_url = ? WHERE id = ?',
                [$pr['name'], $categoryId, $pr['unit'], $pr['mrp'], $pr['price'], $video, $existing['id']]
            );
            $updated++;
        } else {
            insertId(
                'INSERT INTO products (product_code, name, category_id, unit, mrp, price, video_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$pr['product_code'], $pr['name'], $categoryId, $pr['unit'], $pr['mrp'], $pr['price'], $pr['video_url'] ?? null]
            );
            $created++;
        }
    }
    echo "Catalogue: $created products created, $updated updated.$nl";
} else {
    echo "No catalogue.json found at backend/seed/catalogue.json — skipped catalogue seed.$nl";
}

// --------------------------------------- gift boxes & combo packs
// The gift_boxes and combo_packs tables are admin-managed. The 2026 price list
// has no default gift-box/combo products, so no defaults are seeded here — the
// admin adds them from the dashboard (pointing at real catalogue product codes).

// ----------------------------------------------------------- bootstrap admin
$agentCount = (int) fetchValue('SELECT COUNT(*) FROM agents');
if ($agentCount === 0) {
    if (BOOTSTRAP_ADMIN_PASSWORD === '' || BOOTSTRAP_ADMIN_PASSWORD === 'change-me-now') {
        echo "WARNING: refusing to create an admin with the placeholder password.$nl";
        echo "Set BOOTSTRAP_ADMIN_PASSWORD in api/.env (or the environment) and re-run.$nl";
    } else {
        insertId(
            "INSERT INTO agents (code, name, phone, role, password_hash, password_plain, commission_pct, notes)
             VALUES ('ADMIN', ?, ?, 'admin', ?, ?, 0, 'Bootstrap account. Change the password after first sign-in.')",
            [BOOTSTRAP_ADMIN_NAME, BOOTSTRAP_ADMIN_PHONE, password_hash(BOOTSTRAP_ADMIN_PASSWORD, PASSWORD_BCRYPT), BOOTSTRAP_ADMIN_PASSWORD]
        );
        echo 'Bootstrap admin created (phone ' . BOOTSTRAP_ADMIN_PHONE . "). Change the password after signing in.$nl";
    }
} else {
    echo "Agents already exist — skipped admin bootstrap.$nl";
}

// Rename the default bootstrap account from "Owner" to "Admin" on databases
// created before this label change. Only touches the ADMIN code still named Owner.
$renamed = execute("UPDATE agents SET name = 'Admin' WHERE code = 'ADMIN' AND name = 'Owner'");
if ($renamed > 0) {
    echo "Renamed bootstrap admin 'Owner' to 'Admin'.$nl";
}

echo "Setup complete.$nl";
